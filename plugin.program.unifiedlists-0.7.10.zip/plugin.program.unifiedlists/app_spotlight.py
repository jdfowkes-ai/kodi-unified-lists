"""Per-app Arctic Fuse spotlight feeds from installed Kodi video add-ons."""
import json
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin


def _video_directory(path):
    """Read an add-on video directory through Kodi JSON-RPC."""
    request = {
        'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
        'params': {
            'directory': str(path or ''),
            'media': 'video',
            # These are valid List.Fields.Files properties in Kodi Omega's
            # JSON-RPC API. Requesting an unsupported field makes the entire
            # Files.GetDirectory call fail with Invalid params.
            'properties': ['title', 'plot', 'year', 'season', 'episode',
                           'showtitle', 'genre', 'runtime', 'duration', 'mpaa',
                           'premiered', 'thumbnail', 'fanart', 'art', 'uniqueid',
                           'file'],
        },
    }
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if response.get('error'):
        raise RuntimeError(response['error'].get('message', 'Kodi could not open this video folder.'))
    files = response.get('result', {}).get('files', [])
    if not isinstance(files, list):
        raise RuntimeError('Kodi did not return a folder listing.')
    return files


def _path_url(base, action, app_id, path):
    return base + '?' + urlencode({'action': action, 'app': app_id, 'path': path})


def _video_addons():
    request = {
        'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddons',
        'params': {
            'type': 'xbmc.python.pluginsource', 'content': 'video',
            'enabled': True, 'installed': True,
            'properties': ['name', 'thumbnail', 'fanart', 'summary', 'version'],
        },
    }
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if response.get('error'):
        raise RuntimeError(response['error'].get('message', 'Kodi could not list video add-ons.'))
    result = response.get('result', {})
    addons = result.get('addons', []) if isinstance(result, dict) else []
    if not isinstance(addons, list):
        raise RuntimeError('Kodi did not return a video add-on list.')
    return [entry for entry in addons if isinstance(entry, dict) and entry.get('addonid')]


def render_addon_picker(handle, base, app):
    """List enabled installed video add-ons for this app's source."""
    xbmcplugin.setPluginCategory(handle, 'Choose video add-on · %s' % app['label'])
    xbmcplugin.setContent(handle, 'files')
    try:
        addons = _video_addons()
    except Exception as exc:
        xbmcgui.Dialog().notification('Spotlight source', 'Could not list video add-ons: %s' % exc,
                                      xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    if not addons:
        li = xbmcgui.ListItem(label='No enabled video add-ons were found')
        xbmcplugin.addDirectoryItem(handle, '', li, False)
    for entry in sorted(addons, key=lambda item: str(item.get('name') or item['addonid']).casefold()):
        addon_id = str(entry['addonid'])
        label = str(entry.get('name') or addon_id)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': entry.get('thumbnail', ''), 'thumb': entry.get('thumbnail', ''),
                   'fanart': entry.get('fanart', ''), 'landscape': entry.get('fanart', '')})
        li.setProperty('IsFolder', 'true')
        root_path = 'plugin://%s/' % addon_id
        xbmcplugin.addDirectoryItem(
            handle, _path_url(base, 'spotlight_source_browser', app['id'], root_path), li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def render_source_picker(addon, handle, base, app, path):
    """Browse a selected video add-on and save one folder as this app's feed."""
    path = str(path or '')
    xbmcplugin.setPluginCategory(handle, 'Choose video source · %s' % app['label'])
    xbmcplugin.setContent(handle, 'files')
    choose = xbmcgui.ListItem(label='Use this folder for %s' % app['label'])
    choose.setProperty('IsPlayable', 'false')
    target = base + '?' + urlencode({'action': 'set_spotlight_source',
                                     'app': app['id'], 'path': path})
    xbmcplugin.addDirectoryItem(handle, target, choose, False)
    try:
        entries = _video_directory(path)
    except Exception as exc:
        xbmcgui.Dialog().notification('Spotlight source', 'Could not browse this add-on: %s' % exc,
                                      xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    for entry in entries:
        file_path = str(entry.get('file') or '')
        is_folder = (entry.get('filetype') == 'directory' or
                     str(entry.get('filetype') or '').lower() == 'directory')
        label = str(entry.get('label') or entry.get('title') or 'Untitled')
        if is_folder and file_path:
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': entry.get('thumbnail', ''), 'thumb': entry.get('thumbnail', ''),
                       'fanart': entry.get('fanart', ''), 'landscape': entry.get('fanart', '')})
            xbmcplugin.addDirectoryItem(
                handle, _path_url(base, 'spotlight_source_browser', app['id'], file_path), li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _info_item(handle, label):
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle, '', li, False)


def _render_selected_source(handle, app):
    source = str(app.get('spotlight_source') or '').strip()
    if not source:
        _info_item(handle, 'Choose an add-on folder from Manage Apps → Choose spotlight source.')
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    for entry in _video_directory(source):
        file_path = str(entry.get('file') or '')
        if not file_path:
            continue
        label = str(entry.get('label') or entry.get('title') or 'Untitled')
        is_folder = str(entry.get('filetype') or '').lower() == 'directory'
        media = str(entry.get('mediatype') or '')
        if not media:
            if entry.get('showtitle'):
                media = 'episode'
            elif is_folder:
                media = 'tvshow'
            else:
                media = 'movie'

        li = xbmcgui.ListItem(label=label)
        art = entry.get('art') if isinstance(entry.get('art'), dict) else {}
        thumb = entry.get('thumbnail') or art.get('thumb') or ''
        fanart = entry.get('fanart') or art.get('fanart') or ''
        li.setArt({key: value for key, value in {
            'thumb': thumb, 'poster': art.get('poster') or thumb,
            'landscape': art.get('landscape') or fanart or thumb,
            'fanart': fanart or thumb, 'icon': art.get('icon') or thumb,
        }.items() if value})
        tag = li.getVideoInfoTag()
        tag.setTitle(str(entry.get('title') or label))
        plot = entry.get('plot') or entry.get('overview') or ''
        if plot:
            tag.setPlot(str(plot))
        try:
            tag.setMediaType(media)
        except (AttributeError, TypeError, ValueError):
            pass
        if entry.get('year'):
            try:
                tag.setYear(int(entry['year']))
            except (TypeError, ValueError):
                pass
        if entry.get('showtitle'):
            tag.setTvShowTitle(str(entry['showtitle']))
        for key, setter in (('season', 'setSeason'), ('episode', 'setEpisode')):
            if entry.get(key) is not None:
                try:
                    getattr(tag, setter)(int(entry[key]))
                except (AttributeError, TypeError, ValueError):
                    pass
        premiered = entry.get('premiered') or entry.get('firstaired') or ''
        if premiered:
            try:
                tag.setPremiered(str(premiered))
            except (AttributeError, TypeError, ValueError):
                pass
        certificate = entry.get('mpaa') or ''
        if certificate:
            try:
                tag.setMpaa(str(certificate))
            except (AttributeError, TypeError, ValueError):
                pass
        runtime = entry.get('runtime') or entry.get('duration')
        if runtime:
            try:
                runtime = int(float(runtime))
                # Kodi's VideoInfoTag duration and JSON-RPC runtime are seconds.
                tag.setDuration(runtime)
            except (AttributeError, TypeError, ValueError):
                pass
        genres = entry.get('genre') or entry.get('genreid') or []
        if isinstance(genres, str):
            genres = [genres]
        if isinstance(genres, list) and genres:
            try:
                tag.setGenres([str(value) for value in genres])
            except (AttributeError, TypeError, ValueError):
                pass
        unique_ids = entry.get('uniqueid') or {}
        if isinstance(unique_ids, dict):
            for key, value in unique_ids.items():
                try:
                    tag.setUniqueID(str(value), str(key))
                except (AttributeError, TypeError, ValueError):
                    pass
        li.setProperty('IsPlayable', 'false' if is_folder else 'true')
        xbmcplugin.addDirectoryItem(handle, file_path, li, is_folder)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def render_spotlight(addon, handle, base, addon_root, app):
    """Render the selected add-on folder for this app's Arctic Fuse widget."""
    xbmcplugin.setPluginCategory(handle, '%s · Spotlight' % app['label'])
    xbmcplugin.setContent(handle, 'videos')
    try:
        _render_selected_source(handle, app)
    except Exception as exc:
        xbmcgui.Dialog().notification('App spotlight', 'Could not load video source: %s' % exc,
                                      xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


