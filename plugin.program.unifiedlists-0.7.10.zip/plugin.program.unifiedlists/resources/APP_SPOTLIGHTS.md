# App spotlights

Each app can use a folder from an installed video add-on as the media source for Arctic Fuse 3's Home spotlight. With the matching skin change installed, focus an app in the existing Unified Lists Apps row; the large Home spotlight follows that app and cycles through its selected folder. Pressing OK on the app tile still launches the Android app.

The standalone per-app feed remains available for people who want to add it as a separate widget:

`plugin://plugin.program.unifiedlists/?action=app_spotlight&app=disney-plus`

Choose the content source from Unified Lists → **Manage Apps** → **Choose spotlight source**. Pick the app, pick an enabled video add-on, browse to the folder whose titles should feed its spotlight, then select **Use this folder**. Each app saves its own folder. The feed reads that directory through Kodi's `Files.GetDirectory` API, so the selected add-on supplies the items, artwork, metadata, and paths. Set the widget cycling interval in Arctic Fuse 3; the skin rotates through the returned items.

The picker discovers enabled, installed Kodi video plugin add-ons. Folder contents and spotlight playback depend on the selected add-on returning video items through Kodi.

The Apps directory remains the app launcher and supports add/remove, filtering, and most-recently-used ordering. The Watch Later list remains available.
