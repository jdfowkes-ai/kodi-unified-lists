"""Curated studio/network tiles that hand movie and TV browsing to Umbrella."""
import json
import os
from urllib.parse import urlencode

import xbmcplugin
import xbmcgui


# The source ids are TMDb company ids except National Geographic's TV network.
# Movie and TV lists remain separate so Umbrella owns the title pages and playback.
STUDIOS = (
    {'id': 'disney', 'label': 'Disney', 'company': '2', 'tv_filter': 'company', 'tv_id': '2'},
    {'id': 'pixar', 'label': 'Pixar', 'company': '3', 'tv_filter': 'company', 'tv_id': '3'},
    {'id': 'marvel', 'label': 'Marvel', 'company': '420', 'tv_filter': 'company', 'tv_id': '420'},
    {'id': 'national-geographic', 'label': 'National Geographic', 'company': '7521',
     'tv_filter': 'network', 'tv_id': '43'},
)


def _plugin_url(base, **params):
    return base + '?' + urlencode(params)


def _umbrella_url(studio, media):
    if media == 'movie':
        endpoint = 'movie'
        action = 'tmdbmovies'
        filter_name, filter_id = 'with_companies', studio['company']
        suffix = 'Movies'
    else:
        endpoint = 'tv'
        action = 'tmdbTvshows'
        filter_name = 'with_networks' if studio['tv_filter'] == 'network' else 'with_companies'
        filter_id = studio['tv_id']
        suffix = 'TV Shows'
    tmdb_url = ('https://api.themoviedb.org/3/discover/%s?api_key=%%s&%s=%s'
                '&sort_by=popularity.desc&page=1' % (endpoint, filter_name, filter_id))
    return 'plugin://plugin.video.umbrella/?' + urlencode({
        'action': action,
        'url': tmdb_url,
        'folderName': '%s %s' % (studio['label'], suffix),
    })


def render_catalogue(handle, base, addon_root):
    """Return the studio row. Focus properties drive the existing skin hero."""
    art_root = os.path.join(addon_root, 'resources', 'studio_art')
    xbmcplugin.setPluginCategory(handle, 'Studios & Networks')
    xbmcplugin.setContent(handle, 'videos')
    for studio in STUDIOS:
        wordmark = os.path.join(art_root, studio['id'] + '-wordmark.png')
        collage = os.path.join(art_root, studio['id'] + '-collage.jpg')
        li = xbmcgui.ListItem(label=studio['label'])
        li.setArt({'icon': wordmark, 'thumb': wordmark, 'poster': wordmark,
                   'landscape': wordmark, 'fanart': collage})
        li.setProperty('IsFolder', 'true')
        # Arctic Fuse reads these on focus and keeps the blurred image scoped to
        # the app/studio spotlight layer. This doesn't change regular widget art.
        li.setProperty('app_spotlight_logo', wordmark)
        li.setProperty('app_spotlight_blur', collage)
        li.setProperty('app_spotlight_label', studio['label'])
        li.setProperty('app_spotlight_path',
                       _plugin_url(base, action='studio_feeds', studio=studio['id']))
        li.setProperty('app_spotlight_reload', studio['id'])
        target = _plugin_url(base, action='studio_feeds', studio=studio['id'])
        xbmcplugin.addDirectoryItem(handle, target, li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def render_feeds(handle, studio_id, addon_root):
    """Expose native Umbrella movie and TV directories for one studio."""
    studio = next((entry for entry in STUDIOS if entry['id'] == studio_id), None)
    if studio is None:
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    art_root = os.path.join(addon_root, 'resources', 'studio_art')
    wordmark = os.path.join(art_root, studio['id'] + '-wordmark.png')
    collage = os.path.join(art_root, studio['id'] + '-collage.jpg')
    xbmcplugin.setPluginCategory(handle, studio['label'])
    xbmcplugin.setContent(handle, 'videos')
    for media, label in (('movie', 'Movies'), ('tv', 'TV Shows')):
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': wordmark, 'thumb': wordmark, 'poster': wordmark,
                   'fanart': collage, 'landscape': collage})
        li.setProperty('IsFolder', 'true')
        xbmcplugin.addDirectoryItem(handle, _umbrella_url(studio, media), li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
