"""Build one mixed Continue Watching directory from Umbrella's local cache.

Playback remains owned by Umbrella. Selecting an entry first opens the compact
action menu so the remote's OK button has the same two-step resume flow as the
reference screen.
"""
import ast
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


UMBRELLA = 'plugin://plugin.video.umbrella/'


def _profile_file(name):
    profile = Path(xbmcvfs.translatePath(
        xbmcaddon.Addon('plugin.video.umbrella').getAddonInfo('profile')))
    return profile / name


def _open_readonly(path):
    return sqlite3.connect('file:%s?mode=ro' % path.as_posix(), uri=True, timeout=3)


def _read_progress():
    path = _profile_file('watched.db')
    if not path.is_file():
        return []
    try:
        with _open_readonly(path) as con:
            rows = con.execute(
                "SELECT media_type, imdb_id, tmdb_id, season, episode, title, "
                "resume_point, curr_time, last_played FROM progress "
                "WHERE media_type IN ('movie','episode') "
                "ORDER BY CAST(last_played AS INTEGER) DESC").fetchall()
        return rows
    except (sqlite3.Error, OSError):
        return []


def _meta_lookup(imdb, tmdb):
    path = _profile_file('metadata.db')
    if not path.is_file():
        return {}
    try:
        with _open_readonly(path) as con:
            row = con.execute(
                "SELECT item FROM meta WHERE "
                "(? != '' AND imdb=?) OR (? != '' AND tmdb=?) "
                "ORDER BY CAST(time AS INTEGER) DESC LIMIT 1",
                (imdb, imdb, tmdb, tmdb)).fetchone()
        if row and row[0]:
            value = ast.literal_eval(row[0])
            return value if isinstance(value, dict) else {}
    except (sqlite3.Error, OSError, ValueError, SyntaxError, TypeError):
        pass
    return {}


def _payload(row):
    media, imdb, tmdb, season, episode, title, percent, position, last_played = row
    metadata = _meta_lookup(str(imdb or ''), str(tmdb or ''))
    metadata = dict(metadata)
    media = str(media)
    title = str(title or metadata.get('title') or metadata.get('name') or 'Untitled')
    season, episode = int(season or 0), int(episode or 0)
    try:
        percent = max(0.0, min(100.0, float(percent or 0)))
    except (TypeError, ValueError):
        percent = 0.0
    try:
        position = max(0.0, float(position or 0))
    except (TypeError, ValueError):
        position = 0.0

    ids = metadata.get('ids') or metadata.get('uniqueid') or {}
    ids = ids if isinstance(ids, dict) else {}
    imdb = str(imdb or metadata.get('imdb') or ids.get('imdb') or '')
    tmdb = str(tmdb or metadata.get('tmdb') or ids.get('tmdb') or '')
    tvdb = str(metadata.get('tvdb') or ids.get('tvdb') or '')
    metadata['uniqueid'] = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}
    show = (metadata.get('tvshowtitle') or metadata.get('showtitle') or
            metadata.get('name') or metadata.get('title') or '')
    year = metadata.get('year') or ''
    if media == 'movie':
        metadata.update({'title': title, 'mediatype': 'movie', 'imdb': imdb,
                         'tmdb': tmdb, 'year': year})
        label = title
    else:
        metadata.update({'title': title, 'name': title, 'mediatype': 'episode',
                         'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb,
                         'tvshowtitle': show, 'showtitle': show,
                         'season': season, 'episode': episode, 'year': year})
        label = '%s · S%02d E%02d · %s' % (show or title, season, episode, title)
    metadata['progress'] = percent
    metadata['resume_position'] = position
    return {
        'media': media, 'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb,
        'season': season, 'episode': episode, 'title': title,
        'show': show, 'year': year, 'percent': percent,
        'position': position, 'last_played': str(last_played or ''),
        'label': label, 'metadata': metadata,
    }


def _umbrella_play_url(data):
    meta = dict(data['metadata'])
    # Umbrella's item links use action=play_Item with its native identifying
    # fields and serialized metadata. This retains its source selection,
    # resume and playback behavior.
    params = {
        'action': 'play_Item', 'title': data['title'], 'year': data['year'],
        'imdb': data['imdb'], 'tmdb': data['tmdb'], 'tvdb': data['tvdb'],
        'meta': json.dumps(meta, ensure_ascii=False, separators=(',', ':')),
    }
    if data['media'] == 'episode':
        params.update({'season': data['season'], 'episode': data['episode'],
                       'tvshowtitle': data['show'],
                       'premiered': meta.get('premiered', '')})
    return UMBRELLA + '?' + urlencode(params)


def _addon_url(action, payload):
    import sys
    encoded = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
    return sys.argv[0] + '?' + urlencode({'action': action, 'data': encoded})


def _listitem(data):
    li = xbmcgui.ListItem(label=data['label'])
    meta = data['metadata']
    art = meta.get('art') if isinstance(meta.get('art'), dict) else {}
    art = dict(art)
    for target, keys in {
        'poster': ('poster', 'thumb'), 'thumb': ('thumb', 'poster'),
        'landscape': ('landscape', 'fanart', 'thumb', 'poster'),
        'fanart': ('fanart', 'landscape'), 'icon': ('icon', 'poster', 'thumb'),
    }.items():
        if not art.get(target):
            art[target] = next((meta.get(k) for k in keys if meta.get(k)), '')
    li.setArt({k: v for k, v in art.items() if v})
    tag = li.getVideoInfoTag()
    tag.setMediaType(data['media'])
    tag.setTitle(data['title'])
    tag.setPlot(meta.get('plot') or meta.get('overview') or '')
    try:
        if data['year']:
            tag.setYear(int(data['year']))
    except (TypeError, ValueError):
        pass
    if data['media'] == 'episode':
        tag.setTvShowTitle(data['show'])
        tag.setSeason(data['season'])
        tag.setEpisode(data['episode'])
    li.setProperty('WatchedProgress', str(round(data['percent'])))
    li.setProperty('PercentPlayed', str(round(data['percent'])))
    payload_url = lambda action: _addon_url(action, data)
    play_url = _umbrella_play_url(data)
    seconds = int(data['position'])
    hh, rem = divmod(seconds, 3600)
    mm, ss = divmod(rem, 60)
    resume_label = 'Resume from %02d:%02d:%02d' % (hh, mm, ss)
    menu = [
        (resume_label, 'PlayMedia(%s)' % play_url),
        ('Play from beginning', 'RunPlugin(%s)' % payload_url('continue_beginning')),
    ]
    if data['media'] == 'movie':
        menu.append(('Play Trailer', 'RunPlugin(%s)' % payload_url('continue_trailer')))
    menu.extend([
        ('Movie Information' if data['media'] == 'movie' else 'Episode Information', 'Action(Info)'),
        ('Watch Later', 'RunPlugin(%s)' % payload_url('continue_watch_later')),
        ('Add to Favourites', 'RunPlugin(%s)' % payload_url('continue_favourite')),
    ])
    # Replace the skin/Kodi defaults for these items with the short set the
    # user approved. OK opens the exact item's native skin context panel.
    li.addContextMenuItems(menu, replaceItems=True)
    return li


def _run_action(action, data):
    play_url = _umbrella_play_url(data)
    if action == 'continue_actions':
        xbmc.executebuiltin('Action(ContextMenu)')
    elif action == 'continue_beginning':
        from umbrella_local import clear_bookmark
        clear_bookmark(data['media'], data['metadata'])
        xbmc.executebuiltin('PlayMedia(%s)' % play_url)
    elif action == 'continue_trailer':
        # One trailer choice only. Umbrella resolves a trailer if no cached
        # trailer URL is present, using its native selection route.
        if data['metadata'].get('trailer'):
            params = {'action': 'play_Trailer_Context', 'type': 'movie',
                      'name': data['title'], 'year': data['year'],
                      'imdb': data['imdb'], 'url': data['metadata']['trailer']}
        else:
            params = {'action': 'play_Trailer_Select', 'type': 'movie',
                      'name': data['title'], 'year': data['year']}
        xbmc.executebuiltin('RunPlugin(%s?%s)' % (UMBRELLA, urlencode(params)))
    elif action == 'continue_information':
        xbmc.executebuiltin('Action(Info)')
    elif action == 'continue_watch_later':
        _save_watch_later(data)
    elif action == 'continue_favourite':
        params = {'action': ('add_favorite' if data['media'] == 'movie'
                             else 'add_favorite_episode'),
                  'meta': json.dumps(data['metadata'], ensure_ascii=False,
                                     separators=(',', ':')),
                  'content': ('movies' if data['media'] == 'movie' else 'episode')}
        xbmc.executebuiltin('RunPlugin(%s?%s)' % (UMBRELLA, urlencode(params)))


def _save_watch_later(data):
    import sys
    import sqlite3
    from pathlib import Path
    import xbmcaddon
    import xbmcvfs
    from identity import stable_identity
    from default import DB_PATH
    media = data['media']
    play_url = _umbrella_play_url(data)
    mid, _identity = stable_identity(media, data['metadata'], play_url)
    con = sqlite3.connect(str(DB_PATH))
    try:
        con.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?)',
                    ('Watch Later', media, mid, data['title']))
        action_url = _addon_url('continue_actions', data)
        con.execute('INSERT OR REPLACE INTO external_list_items '
                    '(media_type,kodi_id,path,is_folder,metadata_json) VALUES (?,?,?,?,?)',
                    (media, mid, action_url, 0,
                     json.dumps(data['metadata'], ensure_ascii=False)))
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'Added to Watch Later',
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def run_listing(handle):
    xbmcplugin.setContent(handle, 'videos')
    rows = _read_progress()
    for row in rows:
        data = _payload(row)
        if not data['imdb'] and not data['tmdb']:
            continue
        target = _addon_url('continue_actions', data)
        xbmcplugin.addDirectoryItem(handle, target, _listitem(data), False)


def run_action():
    import sys
    from urllib.parse import parse_qs
    from urllib.parse import unquote
    params = parse_qs(sys.argv[2][1:])
    action = params.get('action', ['continue_actions'])[0]
    raw = params.get('data', ['{}'])[0]
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return
    if not isinstance(data, dict) or data.get('media') not in ('movie', 'episode'):
        return
    _run_action(action, data)
