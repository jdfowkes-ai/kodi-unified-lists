"""Local Continue Watching with one resumable or next episode per series."""
import datetime
import json
import xbmc


def episodes(show_id):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': 'VideoLibrary.GetEpisodes',
               'params': {'tvshowid': int(show_id), 'properties':
                          ['title', 'showtitle', 'season', 'episode', 'tvshowid',
                           'playcount', 'firstaired', 'plot', 'art',
                           'thumbnail', 'fanart', 'runtime']}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {}).get('episodes', [])
    except (ValueError, TypeError):
        return []


def episode_file(episode_id):
    """Look up a playable path separately; Kodi rejects `file` in GetEpisodes here."""
    request = {'jsonrpc': '2.0', 'id': 1, 'method': 'VideoLibrary.GetEpisodeDetails',
               'params': {'episodeid': int(episode_id), 'properties': ['file']}}
    try:
        result = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})
        return result.get('episodedetails', {}).get('file', '')
    except (ValueError, TypeError):
        return ''


def episode_order(details):
    return (int(details.get('season', -1)), int(details.get('episode', -1)))


def choose_next(previous, candidates, local_progress, today=None, get_file=episode_file):
    """Skip specials, watched entries and future episodes; never wrap to episode 1."""
    today = today or datetime.date.today().isoformat()
    previous_order = episode_order(previous)
    for candidate in sorted(candidates, key=episode_order):
        if candidate.get('season', 0) <= 0 or episode_order(candidate) <= previous_order:
            continue
        firstaired = candidate.get('firstaired', '')
        if firstaired and len(firstaired) >= 10 and firstaired[:10] > today:
            continue
        local = local_progress.get(('episode', candidate.get('episodeid')))
        if local:
            # Local playback wins over a Kodi watched flag for an explicit rewatch.
            if local['completed']:
                continue
        elif candidate.get('playcount', 0) > 0:
            continue
        # GetEpisodes is returning the episode metadata, but its `file` field
        # is rejected by this Kodi build. Fetch the file via GetEpisodeDetails.
        path = candidate.get('file') or get_file(candidate.get('episodeid'))
        if not path:
            continue
        return dict(candidate, file=path)
    return None


def directory_rows(rows, display, get_episodes=episodes):
    """rows contain retained local history, including completed episodes."""
    local = {(r['media_type'], r['kodi_id']): r for r in rows}
    result = []
    series = {}
    for row in rows:
        media, mid = row['media_type'], row['kodi_id']
        if media == 'movie':
            if not row['completed'] and row['position'] >= 30:
                result.append(dict(row, next_episode=False))
            continue
        details = display.details('episode', mid)
        show_id = details.get('tvshowid', -1)
        if show_id < 0:
            if not row['completed'] and row['position'] >= 30:
                result.append(dict(row, next_episode=False))
            continue
        series.setdefault(show_id, []).append((row, details))
    for show_id, history in series.items():
        history.sort(key=lambda pair: (pair[0]['updated_at'], pair[0]['kodi_id']), reverse=True)
        unfinished = next((r for r, _ in history if not r['completed'] and r['position'] >= 30), None)
        if unfinished:
            result.append(dict(unfinished, next_episode=False))
            continue
        previous_row, previous_details = history[0]
        if not previous_row['completed']:
            continue
        candidate = choose_next(previous_details, get_episodes(show_id), local)
        if not candidate:
            continue
        mid = candidate['episodeid']
        display.cache[('episode', mid)] = candidate
        progress = local.get(('episode', mid))
        result.append({'media_type': 'episode', 'kodi_id': mid,
                       'title': candidate.get('title') or candidate.get('label') or 'Next episode',
                       'file_path': candidate['file'],
                       'position': progress['position'] if progress and progress['position'] >= 30 else 0,
                       'duration': progress['duration'] if progress else candidate.get('runtime', 0),
                       'completed': 0, 'updated_at': previous_row['updated_at'],
                       'next_episode': True})
    return sorted(result, key=lambda r: (r['updated_at'], r['kodi_id']), reverse=True)
