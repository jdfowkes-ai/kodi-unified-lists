"""One pending resume, applied by the service after matching AV playback."""
import sqlite3
import time
import uuid


def connect(path):
    con = sqlite3.connect(str(path), timeout=10)
    con.execute('CREATE TABLE IF NOT EXISTS pending_resume (slot INTEGER PRIMARY KEY, request_id TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, position REAL NOT NULL, expires REAL NOT NULL, file_path TEXT NOT NULL DEFAULT \'\')')
    columns = {row[1] for row in con.execute('PRAGMA table_info(pending_resume)')}
    if 'file_path' not in columns:
        con.execute("ALTER TABLE pending_resume ADD COLUMN file_path TEXT NOT NULL DEFAULT ''")
    return con


def queue(path, media, mid, position, file_path=''):
    request_id = uuid.uuid4().hex
    with connect(path) as con:
        con.execute('INSERT OR REPLACE INTO pending_resume (slot,request_id,media_type,kodi_id,position,expires,file_path) VALUES (1,?,?,?,?,?,?)', (request_id, media, mid, position, time.time() + 600, str(file_path or '')))
    con.close()
    return request_id


def clear(path, request_id):
    with connect(path) as con:
        con.execute('DELETE FROM pending_resume WHERE request_id=?', (request_id,))
    con.close()


class ResumeController:
    def __init__(self, path, notify):
        self.path = path
        self.notify = notify
        self.reset()

    def reset(self):
        self.request_id = None
        self.attempts = 0
        self.last_seek = None
        self.failed = False

    def stop(self):
        if self.request_id:
            clear(self.path, self.request_id)
        self.reset()

    def tick(self, player, item, position, duration):
        """Return True while resume is unsettled: do not overwrite saved progress."""
        if self.failed:
            return True
        con = connect(self.path)
        row = con.execute('SELECT request_id,media_type,kodi_id,position,expires,file_path FROM pending_resume WHERE slot=1').fetchone()
        con.close()
        if not row:
            return False
        request_id, media, mid, target, expires, file_path = row
        if time.time() > expires:
            clear(self.path, request_id)
            return False
        same_identity = (item[0], item[1]) == (media, mid)
        same_path = bool(file_path and len(item) > 3 and str(item[3] or '') == file_path)
        if not same_identity and not same_path:
            # An unrelated video must never receive another item's resume position.
            clear(self.path, request_id)
            return False
        if self.request_id != request_id:
            self.reset()
            self.request_id = request_id
        if duration <= 0:
            return True
        if abs(position - target) <= 8:
            clear(self.path, request_id)
            self.reset()
            return False
        now = time.monotonic()
        if self.last_seek is not None and now - self.last_seek < 3:
            return True
        if self.attempts >= 3 or target >= duration:
            clear(self.path, request_id)
            self.failed = True
            self.notify()
            return True
        self.attempts += 1
        self.last_seek = now
        try:
            player.seekTime(float(target))
        except Exception:
            pass  # bounded retry; position must confirm success
        return True
