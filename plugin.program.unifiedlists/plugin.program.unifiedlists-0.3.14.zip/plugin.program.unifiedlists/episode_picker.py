"""A read-only season/episode picker; playback is launched by the caller."""
def choose(dialog, episodes, progress):
    # File paths are fetched by GetEpisodeDetails only after the user selects
    # an episode; this Kodi build rejects `file` in GetEpisodes properties.
    available = [e for e in episodes if e.get('episodeid') is not None and e.get('season', -1) >= 0]
    seasons = sorted({int(e['season']) for e in available})
    if not seasons:
        dialog.ok('Choose season / episode', 'No playable episodes are available for this show in your Kodi library.')
        return None
    index = dialog.select('Choose season', ['Specials' if s == 0 else 'Season %s' % s for s in seasons])
    if index < 0 or index >= len(seasons):
        return None
    season = seasons[index]
    choices = sorted([e for e in available if int(e['season']) == season], key=lambda e: (int(e.get('episode', 0)), e['episodeid']))
    labels = []
    for entry in choices:
        label = 'E%02d · %s' % (entry.get('episode', 0), entry.get('title') or entry.get('label') or 'Episode')
        local = progress.get(entry['episodeid'])
        if local and not local['completed'] and local['position'] >= 30:
            if local['duration'] > 0:
                label += ' · %s%% watched' % min(100, max(0, round(100 * local['position'] / local['duration'])))
            else:
                label += ' · In progress'
        elif (local and local['completed']) or (not local and entry.get('playcount', 0) > 0):
            label += ' · Watched'
        labels.append(label)
    index = dialog.select('Choose episode — ' + ('Specials' if season == 0 else 'Season %s' % season), labels)
    if index < 0 or index >= len(choices):
        return None
    return choices[index]['episodeid']
