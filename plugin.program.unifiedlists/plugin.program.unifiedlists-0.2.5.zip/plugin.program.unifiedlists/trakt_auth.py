"""Optional Trakt device connection; never reads or writes local lists."""
import json
import os
import time
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import xbmc
import xbmcgui
import xbmcvfs

API = 'https://api.trakt.tv'


def token_path(addon):
    return Path(xbmcvfs.translatePath(addon.getAddonInfo('profile'))) / 'trakt_tokens.json'


def connected(addon):
    try:
        data = json.loads(token_path(addon).read_text(encoding='utf-8'))
        return bool(data.get('access_token') and data.get('client_id') == addon.getSetting('trakt_client_id').strip())
    except (OSError, ValueError):
        return False


def post(endpoint, payload, client_id):
    req = Request(API + endpoint, data=json.dumps(payload).encode('utf-8'), headers={
        'Content-Type': 'application/json', 'trakt-api-version': '2',
        'trakt-api-key': client_id, 'User-Agent': 'Kodi-Unified-Lists/0.2.5'}, method='POST')
    try:
        with urlopen(req, timeout=15) as response:
            return response.status, json.loads(response.read().decode('utf-8')), 0
    except HTTPError as error:
        try:
            retry = max(0, int(error.headers.get('Retry-After', '0')))
        except ValueError:
            retry = 0
        return error.code, {}, retry


def save_tokens(addon, data, client_id):
    if not data.get('access_token') or not data.get('refresh_token'):
        raise ValueError('Incomplete token response')
    path = token_path(addon)
    path.parent.mkdir(parents=True, exist_ok=True)
    stored = dict(data, client_id=client_id)
    temp = path.with_suffix('.tmp')
    try:
        fd = os.open(str(temp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        os.chmod(str(temp), 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as output:
            json.dump(stored, output)
            output.flush()
            os.fsync(output.fileno())
        os.replace(str(temp), str(path))
    finally:
        if temp.exists():
            temp.unlink()


def authorise(addon):
    dialog = xbmcgui.Dialog()
    client_id = addon.getSetting('trakt_client_id').strip()
    if not client_id:
        dialog.ok('Trakt', 'Enter your Trakt Client ID in the add-on settings first.')
        addon.openSettings()
        return
    if connected(addon) and not dialog.yesno('Trakt', 'Trakt is already connected. Authorise again?'):
        return
    progress = None
    try:
        status, codes, _ = post('/oauth/device/code', {'client_id': client_id}, client_id)
        if status != 200:
            dialog.ok('Trakt', 'Unable to request an activation code (HTTP %s). Check your Client ID and try again.' % status)
            return
        device_code, user_code = codes['device_code'], codes['user_code']
        expires = max(1, int(codes['expires_in']))
        interval = max(1, int(codes['interval']))
        # Display a trusted URL rather than opening an arbitrary API-provided address.
        message = 'On your phone, open https://trakt.tv/activate\nEnter code: %s\nWaiting for your approval. Cancel to stop.' % user_code
        progress = xbmcgui.DialogProgress()
        progress.create('Authorise Trakt', message)
        monitor = xbmc.Monitor()
        deadline = time.monotonic() + expires
        next_poll = time.monotonic() + interval
        while time.monotonic() < deadline:
            if progress.iscanceled() or monitor.abortRequested():
                return
            progress.update(min(99, int(100 * (1 - (deadline - time.monotonic()) / expires))), message)
            if monitor.waitForAbort(min(.2, max(0, next_poll - time.monotonic()))):
                return
            if time.monotonic() < next_poll:
                continue
            status, data, retry = post('/oauth/device/token', {'code': device_code, 'client_id': client_id}, client_id)
            if progress.iscanceled() or monitor.abortRequested():
                return
            if status == 200:
                save_tokens(addon, data, client_id)
                progress.close()
                progress = None
                dialog.ok('Trakt connected', 'Authorisation saved on this device.\nYour local lists remain primary. Trakt sync is not enabled in this version.')
                xbmc.executebuiltin('Container.Refresh')
                return
            if status == 429:
                interval = max(interval + 5, retry)
            elif status != 400:
                messages = {404: 'The activation code is invalid.', 409: 'This code has already been used.', 410: 'The activation code expired.', 418: 'Authorisation was declined.'}
                progress.close()
                progress = None
                dialog.ok('Trakt', messages.get(status, 'Authorisation failed (HTTP %s).' % status) + '\nSelect Authorise Trakt to try again.')
                return
            next_poll = time.monotonic() + interval
        progress.close()
        progress = None
        dialog.ok('Trakt', 'The activation code expired. Select Authorise Trakt to get a new code.')
    except Exception:
        if progress is not None:
            progress.close()
            progress = None
        # Never log API bodies, device codes, credentials or tokens.
        dialog.ok('Trakt', 'Could not complete authorisation. Check your connection and try again. Any previous connection has been kept.')
    finally:
        if progress is not None:
            progress.close()


def disconnect(addon):
    if xbmcgui.Dialog().yesno('Disconnect Trakt', 'Remove the saved Trakt connection from this device? Your local lists will be kept.'):
        try:
            path = token_path(addon)
            if path.exists():
                path.unlink()
            xbmc.executebuiltin('Container.Refresh')
        except OSError:
            xbmcgui.Dialog().ok('Trakt', 'Unable to remove the saved connection.')
