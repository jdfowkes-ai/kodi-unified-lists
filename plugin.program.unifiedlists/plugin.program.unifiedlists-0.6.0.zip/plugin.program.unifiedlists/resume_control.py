"""One pending resume, applied by the service after matching AV playback."""
import sqlite3
import time
import uuid
import json
import re


def connect(path):
    con = sqlite3.connect(str(path), timeout=10)
    con.execute('CREATE TABLE IF NOT EXISTS pending_resume (slot INTEGER PRIMARY KEY, request_id TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, position REAL NOT NULL, expires REAL NOT NULL, file_path TEXT NOT NULL DEFAULT \'\', source_metadata TEXT NOT NULL DEFAULT \'{}\')')
    columns = {row[1] for row in con.execute('PRAGMA table_info(pending_resume)')}
    if 'file_path' not in columns:
        con.execute("ALTER TABLE pending_resume ADD COLUMN file_path TEXT NOT NULL DEFAULT ''")
    if 'source_metadata' not in columns:
        con.execute("ALTER TABLE pending_resume ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
    return con


def queue(path, media, mid, position, file_path='', metadata=None):
    request_id = uuid.uuid4().hex
    with connect(path) as con:
        con.execute('INSERT OR REPLACE INTO pending_resume (slot,request_id,media_type,kodi_id,position,expires,file_path,source_metadata) VALUES (1,?,?,?,?,?,?,?)',
                    (request_id, media, mid, position, time.time() + 600, str(file_path or ''),
                     json.dumps(metadata or {}, ensure_ascii=False)))
    con.close()
    return request_id


def clear(path, request_id):
    with connect(path) as con:
        con.execute('DELETE FROM pending_resume WHERE request_id=?', (request_id,))
    con.close()


def clear_pending(path):
    """Drop the queued seek when the user stops or the attempt expires."""
    with connect(path) as con:
        con.execute('DELETE FROM pending_resume WHERE slot=1')
    con.close()


class ResumeController:
    def __init__(self, path, notify):
        self.path = path
        self.notify = notify
        self.reset()

    def reset(self):
        self.request_id = None
        self.attempts = 0
        self.last_seek = None
        self.failed = False

    def stop(self):
        if self.request_id:
            clear(self.path, self.request_id)
        self.reset()

    def tick(self, player, item, position, duration):
        """Return True while resume is unsettled: do not overwrite saved progress."""
        if self.failed:
            return True
        con = connect(self.path)
        row = con.execute('SELECT request_id,media_type,kodi_id,position,expires,file_path,source_metadata FROM pending_resume WHERE slot=1').fetchone()
        con.close()
        if not row:
            return False
        request_id, media, mid, target, expires, file_path, source_metadata = row
        if time.time() > expires:
            clear(self.path, request_id)
            return False
        try:
            expected = json.loads(source_metadata or '{}')
        except (ValueError, TypeError):
            expected = {}
        same_identity = (item[0], item[1]) == (media, mid)
        actual = item[4] if len(item) > 4 else {}
        actual_title = item[2] if len(item) > 2 else ''
        actual_path = item[3] if len(item) > 3 else ''
        same_metadata = _same_media(media, expected, actual,
                                    actual_title, actual_path)
        same_path = bool(file_path and len(item) > 3 and str(item[3] or '') == file_path)
        if not same_identity and not same_path and not same_metadata:
            # Kodi can report provisional metadata while Umbrella is resolving
            # a stream. Keep the short-lived request pending until the selected
            # item is identifiable or playback is stopped.
            return True
        if self.request_id != request_id:
            self.reset()
            self.request_id = request_id
        if duration <= 0:
            return True
        if abs(position - target) <= 8:
            clear(self.path, request_id)
            self.reset()
            return False
        now = time.monotonic()
        if self.last_seek is not None and now - self.last_seek < 3:
            return True
        if self.attempts >= 3 or target >= duration:
            clear(self.path, request_id)
            self.failed = True
            self.notify()
            return True
        self.attempts += 1
        self.last_seek = now
        try:
            player.seekTime(float(target))
        except Exception:
            pass  # bounded retry; position must confirm success
        return True


def _norm(value):
    return re.sub(r'[^a-z0-9]+', '', str(value or '').casefold())


def _same_media(media, expected, actual, actual_title='', actual_path=''):
    """Match the queued item after Umbrella resolves it to a stream URL."""
    if not isinstance(expected, dict) or not isinstance(actual, dict):
        return False
    if media == 'episode':
        eseason, eepisode = _episode_numbers(expected, expected.get('title', ''))
        aseason, aepisode = _episode_numbers(actual, actual_title or actual.get('title', ''),
                                             actual_path or actual.get('file', ''))
        if not eseason or not eepisode or not aseason or not aepisode:
            return False
        if (eseason, eepisode) != (aseason, aepisode):
            return False
    expected_ids = expected.get('uniqueid') or {}
    actual_ids = actual.get('uniqueid') or {}
    if isinstance(expected_ids, dict) and isinstance(actual_ids, dict):
        comparable = set(expected_ids).intersection(actual_ids)
        for key in comparable:
            left, right = str(expected_ids.get(key) or ''), str(actual_ids.get(key) or '')
            if left and right:
                if left == right:
                    return True
    if media == 'episode':
        eshow = _norm(expected.get('showtitle') or expected.get('tvshowtitle') or
                      _show_from_episode(expected.get('title', '')))
        ashow = _norm(actual.get('showtitle') or actual.get('tvshowtitle') or
                      _show_from_episode(actual_title or actual.get('title', '') or actual_path))
        return bool(eshow and ashow and eshow == ashow and eseason > 0 and eepisode > 0
                    and (eseason, eepisode) == (aseason, aepisode))
    expected_titles = _movie_titles(expected.get('title') or expected.get('label'),
                                    expected.get('originaltitle'))
    actual_titles = _movie_titles(actual.get('title') or actual.get('label') or actual_title,
                                  actual.get('originaltitle'), actual_path or actual.get('file'))
    if not expected_titles.intersection(actual_titles):
        return False
    eyear, ayear = str(expected.get('year') or ''), str(actual.get('year') or '')
    return not (eyear and ayear and eyear != ayear)


def _episode_numbers(item, title='', path=''):
    try:
        season = int(item.get('season') or 0)
        episode = int(item.get('episode') or 0)
    except (TypeError, ValueError, AttributeError):
        season, episode = 0, 0
    if season > 0 and episode > 0:
        return season, episode
    text = '%s %s' % (title or '', path or '')
    match = re.search(r'(?i)(?:s\s*(\d{1,2})[ ._-]*e\s*(\d{1,3})|(\d{1,2})\s*x\s*(\d{1,3}))', text)
    if not match:
        return 0, 0
    return (int(match.group(1) or match.group(3)),
            int(match.group(2) or match.group(4)))


def _show_from_episode(value):
    text = str(value or '')
    match = re.search(r'(?i)(?:s\s*\d{1,2}[ ._-]*e\s*\d{1,3}|\d{1,2}\s*x\s*\d{1,3})', text)
    if match:
        return text[:match.start()].strip(' ._-')
    return ''


def _movie_titles(*values):
    """Return normalized title forms from metadata or a resolved release path."""
    from urllib.parse import unquote, urlsplit
    titles = set()
    for value in values:
        text = str(value or '').strip()
        if not text:
            continue
        if '://' in text:
            text = unquote(urlsplit(text).path.rsplit('/', 1)[-1])
        text = re.sub(r'\.(mkv|mp4|avi|mov|m4v|strm)$', '', text, flags=re.I)
        normalized = _norm(text)
        if normalized:
            titles.add(normalized)
        # Release names often begin with Title.Year followed by source/codec
        # tags, while Umbrella metadata carries Title (Year).
        without_year_tail = re.sub(r'[ ._\-]*\(?((?:19|20)\d{2})\)?(?:\b.*)?$', '', text).strip(' ._-')
        normalized = _norm(without_year_tail)
        if normalized:
            titles.add(normalized)
        without_paren_year = re.sub(r'\s*\((?:19|20)\d{2}\)\s*$', '', text).strip()
        normalized = _norm(without_paren_year)
        if normalized:
            titles.add(normalized)
    return titles
