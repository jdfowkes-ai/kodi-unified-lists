"""TMDb/JustWatch app catalogue discovery with Umbrella native playback."""
import json
import os
import time
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


API = 'https://api.themoviedb.org/3/'
IMAGE = 'https://image.tmdb.org/t/p/'
UMBRELLA = 'plugin://plugin.video.umbrella/'
PROVIDER_TTL = 7 * 24 * 60 * 60
RESULT_TTL = 6 * 60 * 60
MONETIZATION = 'flatrate|free|ads'


class AppSpotlight:
    def __init__(self, addon=None, opener=None, now=None):
        self.addon = addon or xbmcaddon.Addon()
        self.opener = opener or urlopen
        self.now = now or time.time
        profile = Path(xbmcvfs.translatePath(self.addon.getAddonInfo('profile')))
        profile.mkdir(parents=True, exist_ok=True)
        self.cache_path = profile / 'app_spotlight_cache.json'
        self.cache = self._load_cache()

    def _load_cache(self):
        try:
            with self.cache_path.open('r', encoding='utf-8') as source:
                value = json.load(source)
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    def _save_cache(self):
        temp = self.cache_path.with_name(self.cache_path.name + '.tmp')
        try:
            with temp.open('w', encoding='utf-8') as output:
                json.dump(self.cache, output, ensure_ascii=False)
                output.flush()
                os.fsync(output.fileno())
            os.replace(str(temp), str(self.cache_path))
        finally:
            if temp.exists():
                temp.unlink()

    def _request(self, endpoint, params=None):
        api_key = (self.addon.getSetting('tmdb_api_key') or '').strip()
        if not api_key:
            raise ValueError('Add your TMDb API key in Unified Lists settings first.')
        query = {'api_key': api_key, 'language': 'en-GB'}
        query.update(params or {})
        request = Request(API + endpoint.lstrip('/') + '?' + urlencode(query),
                          headers={'Accept': 'application/json',
                                   'User-Agent': 'UnifiedLists-Kodi-Omega'})
        with self.opener(request, timeout=8) as response:
            raw = response.read(2 * 1024 * 1024)
        data = json.loads(raw.decode('utf-8'))
        return data if isinstance(data, dict) else {}

    def providers(self):
        cached = self.cache.get('providers', {})
        if (isinstance(cached, dict) and cached.get('fetched_at') and
                self.now() - float(cached.get('fetched_at')) < PROVIDER_TTL):
            return cached.get('items', [])
        data = self._request('watch/providers/movie', {'watch_region': 'GB'})
        items = data.get('results', [])
        self.cache['providers'] = {'fetched_at': self.now(), 'items': items}
        self._save_cache()
        return items

    @staticmethod
    def _normal(value):
        return ''.join(char.casefold() for char in str(value or '') if char.isalnum())

    def provider_id(self, names):
        providers = self.providers()
        by_name = {self._normal(item.get('provider_name')): item.get('provider_id')
                   for item in providers if item.get('provider_name') and item.get('provider_id')}
        for name in names:
            value = by_name.get(self._normal(name))
            if value:
                return int(value)
        return 0

    def discover(self, app, media):
        provider = self.provider_id(app.get('provider_names') or [app.get('label', '')])
        if not provider:
            return []
        cache_key = 'discover:%s:%s:%s' % (app['id'], media, provider)
        cached = self.cache.get(cache_key, {})
        if (isinstance(cached, dict) and cached.get('fetched_at') and
                self.now() - float(cached.get('fetched_at')) < RESULT_TTL):
            return cached.get('items', [])
        endpoint = 'discover/movie' if media == 'movie' else 'discover/tv'
        data = self._request(endpoint, {
            'watch_region': 'GB',
            'with_watch_providers': str(provider),
            'with_watch_monetization_types': MONETIZATION,
            'sort_by': 'popularity.desc',
            'page': 1,
        })
        items = data.get('results', [])
        self.cache[cache_key] = {'fetched_at': self.now(), 'items': items}
        self._save_cache()
        return items

    def details(self, show_id):
        return self._request('tv/%s' % int(show_id))

    def season(self, show_id, season_number):
        return self._request('tv/%s/season/%s' % (int(show_id), int(season_number)))


def _years(item, media):
    date = item.get('release_date' if media == 'movie' else 'first_air_date') or ''
    return date[:4] if len(date) >= 4 else ''


def _art(item):
    poster = IMAGE + 'w500' + item.get('poster_path', '') if item.get('poster_path') else 'DefaultVideo.png'
    fanart = IMAGE + 'w1280' + item.get('backdrop_path', '') if item.get('backdrop_path') else poster
    return {'poster': poster, 'thumb': poster, 'icon': poster,
            'fanart': fanart, 'landscape': fanart}


def _umbrella_url(media, metadata):
    from umbrella_playback import build
    return build(metadata)


def _video_item(handle, label, metadata, target, folder=False, popularity=0):
    li = xbmcgui.ListItem(label=label)
    li.setArt(metadata.get('art') or {})
    tag = li.getVideoInfoTag()
    tag.setMediaType(metadata.get('mediatype', 'movie'))
    tag.setTitle(metadata.get('title', label))
    tag.setPlot(metadata.get('plot', ''))
    if metadata.get('year'):
        try:
            tag.setYear(int(metadata['year']))
        except (TypeError, ValueError):
            pass
    ids = metadata.get('uniqueid') or {}
    for key, value in ids.items():
        try:
            tag.setUniqueID(str(value), str(key))
        except Exception:
            pass
    if metadata.get('tvshowtitle'):
        tag.setTvShowTitle(metadata['tvshowtitle'])
        tag.setSeason(int(metadata.get('season', 0)))
        tag.setEpisode(int(metadata.get('episode', 0)))
    if popularity:
        li.setProperty('UnifiedLists.Popularity', str(popularity))
    if not folder:
        li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle, target, li, folder)


def _info_item(handle, text):
    li = xbmcgui.ListItem(label=text)
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle, '', li, False)


def _addon_app(addon_root, app_id, fallback):
    path = os.path.join(addon_root, 'resources', 'app_art', app_id, 'icon-v121.png')
    return path if os.path.isfile(path) else fallback


def render_spotlight(addon, handle, base, addon_root, app):
    spotlight = AppSpotlight(addon)
    fallback = os.path.join(addon_root, 'resources', 'icons', 'navigation',
                            'colour-icon-only', 'apps.png')
    xbmcplugin.setPluginCategory(handle, '%s · Availability: JustWatch via TMDb' % app['label'])
    xbmcplugin.setContent(handle, 'videos')
    all_items = []
    try:
        for media in ('movie', 'tv'):
            for item in spotlight.discover(app, media):
                all_items.append((float(item.get('popularity') or 0), media, item))
    except ValueError as exc:
        xbmcgui.Dialog().ok('App spotlight', str(exc))
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    except Exception as exc:
        xbmcgui.Dialog().notification('App spotlight', 'Could not load %s: %s' % (app['label'], exc),
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    if not all_items:
        _info_item(handle, 'No UK streaming availability data found for %s.' % app['label'])
    all_items.sort(key=lambda entry: entry[0], reverse=True)
    for popularity, media, item in all_items:
        tmdb_id = int(item.get('id') or 0)
        title = str((item.get('title') if media == 'movie' else item.get('name')) or 'Untitled')
        year = _years(item, media)
        metadata = {
            'title': title, 'year': year, 'plot': item.get('overview') or '',
            'mediatype': 'movie' if media == 'movie' else 'tvshow',
            'tvshowtitle': title if media == 'tv' else '',
            'showtitle': title if media == 'tv' else '',
            'uniqueid': {'tmdb': str(tmdb_id)}, 'tmdb': str(tmdb_id),
            'art': _art(item),
        }
        label = '%s (%s)' % (title, year) if year else title
        if media == 'movie':
            _video_item(handle, label, metadata, _umbrella_url(media, metadata), popularity=popularity)
        else:
            target = base + '?' + urlencode({'action': 'app_show', 'app': app['id'],
                                               'tmdb': tmdb_id, 'title': title})
            _video_item(handle, label, metadata, target, folder=True, popularity=popularity)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=True)


def render_show(addon, handle, base, app_id, show_id, title):
    spotlight = AppSpotlight(addon)
    try:
        show = spotlight.details(show_id)
    except Exception as exc:
        xbmcgui.Dialog().notification('App spotlight', 'Could not load seasons: %s' % exc,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(handle, title)
    xbmcplugin.setContent(handle, 'seasons')
    art = _art(show)
    for season in show.get('seasons', []):
        number = int(season.get('season_number') or 0)
        if number <= 0:
            continue
        metadata = {'title': season.get('name') or ('Season %s' % number),
                    'tvshowtitle': title, 'season': number, 'mediatype': 'season', 'art': art,
                    'uniqueid': {'tmdb': str(show_id)}}
        target = base + '?' + urlencode({'action': 'app_episodes', 'app': app_id,
                                           'tmdb': show_id, 'title': title,
                                           'season': number})
        _video_item(handle, metadata['title'], metadata, target, folder=True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=True)


def render_episodes(addon, handle, app_id, show_id, title, season_number):
    spotlight = AppSpotlight(addon)
    try:
        data = spotlight.season(show_id, season_number)
    except Exception as exc:
        xbmcgui.Dialog().notification('App spotlight', 'Could not load episodes: %s' % exc,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(handle, '%s · Season %s' % (title, season_number))
    xbmcplugin.setContent(handle, 'episodes')
    year = str((data.get('air_date') or '')[:4])
    for episode_data in data.get('episodes', []):
        number = int(episode_data.get('episode_number') or 0)
        episode_title = str(episode_data.get('name') or 'Episode %02d' % number)
        art_path = episode_data.get('still_path')
        still = IMAGE + 'w500' + art_path if art_path else ''
        art = {'poster': still, 'thumb': still, 'landscape': still,
               'fanart': still, 'icon': still} if still else {}
        metadata = {
            'title': episode_title, 'year': year, 'plot': episode_data.get('overview') or '',
            'mediatype': 'episode', 'tvshowtitle': title, 'showtitle': title,
            'season': int(season_number), 'episode': number,
            'premiered': episode_data.get('air_date') or '',
            'uniqueid': {'tmdb': str(show_id)}, 'tmdb': str(show_id), 'art': art,
        }
        label = 'S%02dE%02d · %s' % (int(season_number), number, episode_title)
        _video_item(handle, label, metadata, _umbrella_url('episode', metadata))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=True)
