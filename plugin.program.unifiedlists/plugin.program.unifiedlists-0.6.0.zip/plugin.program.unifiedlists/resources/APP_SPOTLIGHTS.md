# Apps and icon library

Unified Lists exposes three Kodi directory paths for Arctic Fuse 3:

- App shortcuts: `plugin://plugin.program.unifiedlists/?action=apps`
- App spotlight directory: `plugin://plugin.program.unifiedlists/?action=app_spotlights`
- Icon library: `plugin://plugin.program.unifiedlists/?action=icon_library`

Each individual spotlight uses `action=app_spotlight` with one of the active app
IDs below. For example:

`plugin://plugin.program.unifiedlists/?action=app_spotlight&app=netflix`

| App | ID |
| --- | --- |
| BBC iPlayer | `bbc-iplayer` |
| ITVX | `itvx` |
| Channel 4 | `channel-4` |
| Netflix | `netflix` |
| Prime Video | `prime-video` |
| Apple TV | `apple-tv` |
| Disney+ | `disney-plus` |
| YouTube | `youtube` |
| Paramount+ | `paramount-plus` |
| HBO Max | `hbo-max` |

The app catalogue can be changed from `action=manage_apps`. Removed bundled apps
are hidden in the local profile database and can be restored. Custom apps are
stored there as well; the package ID is used only when launching the Android
activity. The database used by Watch Later and playback progress remains intact.

Spotlight availability uses the configured TMDb API key and the GB watch region.
Movie items route directly to Umbrella's `play_Item` action. TV show items open
season and episode directories; selecting an episode then routes to Umbrella's
native source selection. Availability is supplied by JustWatch through TMDb and
is cached locally for up to six hours.

Navigation icon styles are `colour-icon-only`, `colour-titled`,
`white-icon-only`, and `white-titled`. The current setting can be changed under
Unified Lists settings → Icon library.
