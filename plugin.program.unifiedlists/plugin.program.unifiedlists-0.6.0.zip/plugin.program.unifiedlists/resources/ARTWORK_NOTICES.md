# Artwork notes

## Arctic Fuse navigation icons

The source navigation set contains 92 individual 1024×1024 PNG files in four
styles. This Kodi build scales the bundled navigation copies to 512×512 for
menu and widget display. The source README describes the art as fictional cinematic fan art,
with embedded logos removed. Original approved logos were extracted as
transparent clearlogos; the Netflix N and Disney castle symbols were generated
and cleaned, and other symbols were extracted from approved logos. Service
marks belong to their owners; no endorsement is implied.

## App artwork

The bundled app icon, landscape and fanart files come from the Shield Apps artwork set. Unused clearlogo and symbol variants are not included. Its artwork note
describes fictional cinematic fan art edited to remove embedded logos and
transparent clearlogos extracted from approved logos. It says the Netflix N
and Disney castle symbols were generated and cleaned, while other symbols were
extracted from approved logos. Service marks belong to their owners; no
endorsement is implied.

These notes preserve the descriptions shipped with the available source
archives. They do not grant rights to third-party service marks or artwork.
