"""Track Watch Later playback until Kodi confirms saved progress."""
import json
import sqlite3
import time

from resume_control import _same_media


def _connect(path):
    con = sqlite3.connect(str(path), timeout=10)
    con.execute("""CREATE TABLE IF NOT EXISTS pending_watch_later (
        slot INTEGER PRIMARY KEY, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL,
        title TEXT NOT NULL, source_metadata TEXT NOT NULL DEFAULT '{}',
        expires REAL NOT NULL, removed INTEGER NOT NULL DEFAULT 0)""")
    return con


def queue(path, media, mid, title, metadata):
    with _connect(path) as con:
        con.execute('INSERT OR REPLACE INTO pending_watch_later '
                    '(slot,media_type,kodi_id,title,source_metadata,expires,removed) '
                    'VALUES (1,?,?,?,?,?,0)',
                    (media, int(mid), str(title or ''),
                     json.dumps(metadata or {}, ensure_ascii=False), time.time() + 6 * 3600))


def clear(path):
    with _connect(path) as con:
        con.execute('DELETE FROM pending_watch_later WHERE slot=1')


def tick(path, item, position, duration):
    """Persist matching playback; remove Watch Later only after >=30s is saved."""
    if not item or duration <= 0:
        return False
    con = _connect(path)
    try:
        row = con.execute('SELECT media_type,kodi_id,title,source_metadata,expires,removed '
                          'FROM pending_watch_later WHERE slot=1').fetchone()
        if not row:
            return False
        media, mid, title, source_json, expires, removed = row
        if time.time() > expires:
            con.execute('DELETE FROM pending_watch_later WHERE slot=1')
            return False
        try:
            expected = json.loads(source_json or '{}')
        except (ValueError, TypeError):
            expected = {}
        actual_media, actual_id = item[0], item[1]
        actual = item[4] if len(item) > 4 else {}
        actual_title = item[2] if len(item) > 2 else ''
        actual_path = item[3] if len(item) > 3 else ''
        matched = ((actual_media, actual_id) == (media, mid) or
                   _same_media(media, expected, actual, actual_title, actual_path))
        if not matched:
            return False
        if float(position) < 30:
            return False
        con.execute('''CREATE TABLE IF NOT EXISTS playback_progress (
            media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL,
            file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL,
            completed INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            source_metadata TEXT NOT NULL DEFAULT '{}',
            PRIMARY KEY(media_type,kodi_id))''')
        columns = {r[1] for r in con.execute('PRAGMA table_info(playback_progress)')}
        if 'source_metadata' not in columns:
            con.execute("ALTER TABLE playback_progress ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
        con.execute('''INSERT OR REPLACE INTO playback_progress
            (media_type,kodi_id,title,file_path,position,duration,completed,updated_at,source_metadata)
            VALUES (?,?,?,?,?,?,0,CURRENT_TIMESTAMP,?)''',
            (media, mid, title or actual_title, actual_path, float(position), float(duration), source_json))
        if not removed:
            con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                        ('Watch Later', media, mid))
            con.execute('DELETE FROM external_list_items WHERE media_type=? AND kodi_id=? '
                        'AND NOT EXISTS (SELECT 1 FROM entries WHERE media_type=? AND kodi_id=?)',
                        (media, mid, media, mid))
            con.execute('UPDATE pending_watch_later SET removed=1 WHERE slot=1')
        con.commit()
        return True
    finally:
        con.close()
