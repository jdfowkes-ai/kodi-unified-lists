"""Mirror local progress into Umbrella's local indicator stores.

Umbrella reads these private per-addon databases to render WatchedProgress in
its own directories. This module never adds Kodi VideoLibrary entries and
gracefully does nothing if Umbrella is absent or its data store is unavailable.
"""
import hashlib
import sqlite3
import time
from pathlib import Path

import xbmcaddon
import xbmcvfs


def _db_paths():
    addon = xbmcaddon.Addon('plugin.video.umbrella')
    profile = Path(xbmcvfs.translatePath(addon.getAddonInfo('profile')))
    return profile / 'bookmarks.db', profile / 'watched.db'


def _year(metadata):
    value = metadata.get('year') or 0
    try:
        return str(int(value))
    except (TypeError, ValueError):
        return '0'


def _bookmark_name(media, metadata):
    # Match resources.lib.modules.player.Player.play_source() in Umbrella.
    # Its local bookmark lookup uses the playback title, not the TV show title.
    title = metadata.get('title') or 'Untitled'
    if media == 'episode':
        try:
            season, episode = int(metadata.get('season') or 0), int(metadata.get('episode') or 0)
        except (TypeError, ValueError):
            season, episode = 0, 0
        return '%s S%02dE%02d' % (title, season, episode)
    year = _year(metadata)
    return '%s (%s)' % (title, year)


def _id_file(name, year):
    return hashlib.md5((str(name) + str(year)).encode('utf-8')).hexdigest()


def _write_bookmark(path, name, year, position, completed):
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(path), timeout=10)
    try:
        con.execute('CREATE TABLE IF NOT EXISTS bookmark '
                    '(idFile TEXT, timeInSeconds TEXT, Name TEXT, year TEXT, UNIQUE(idFile))')
        years = [year]
        try:
            years.extend((str(int(year) + 1), str(int(year) - 1)))
        except (TypeError, ValueError):
            pass
        marks = ','.join('?' for _ in years)
        con.execute('DELETE FROM bookmark WHERE Name=? AND year IN (%s)' % marks, [name] + years)
        if not completed and float(position or 0) >= 30:
            con.execute('INSERT OR REPLACE INTO bookmark VALUES (?,?,?,?)',
                        (_id_file(name, year), str(float(position)), name, year))
        con.commit()
    finally:
        con.close()


def clear_bookmark(media, metadata):
    """Remove Umbrella's matching bookmark before an explicit restart."""
    try:
        bookmark_db, _watched_db = _db_paths()
        if not bookmark_db.exists():
            return
        name = _bookmark_name(media, metadata)
        year = _year(metadata)
        years = [year]
        try:
            years.extend((str(int(year) + 1), str(int(year) - 1)))
        except (TypeError, ValueError):
            pass
        marks = ','.join('?' for _ in years)
        con = sqlite3.connect(str(bookmark_db), timeout=10)
        try:
            con.execute('DELETE FROM bookmark WHERE Name=? AND year IN (%s)' % marks,
                        [name] + years)
            con.commit()
        finally:
            con.close()
    except Exception:
        return


def set_resume_bookmark(media, metadata, position):
    """Seed Umbrella's own bookmark table before its native Resume playback."""
    try:
        bookmark_db, _watched_db = _db_paths()
        _write_bookmark(bookmark_db, _bookmark_name(media, metadata),
                        _year(metadata), max(0.0, float(position or 0)), False)
    except Exception:
        return


def _write_watched(path, media, metadata, completed):
    if not completed:
        return
    ids = metadata.get('uniqueid') or {}
    ids = ids if isinstance(ids, dict) else {}
    imdb = str(ids.get('imdb') or metadata.get('imdbnumber') or '')
    tmdb = str(ids.get('tmdb') or ids.get('themoviedb') or '')
    if not imdb and not tmdb:
        return
    try:
        season = int(metadata.get('season') or 0) if media == 'episode' else 0
        episode = int(metadata.get('episode') or 0) if media == 'episode' else 0
    except (TypeError, ValueError):
        season, episode = 0, 0
    title = metadata.get('showtitle') or metadata.get('tvshowtitle') or metadata.get('title') or ''
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(path), timeout=10)
    try:
        con.execute('CREATE TABLE IF NOT EXISTS watched '
                    '(media_type TEXT, imdb_id TEXT, tmdb_id TEXT, season INTEGER, episode INTEGER, '
                    'title TEXT, last_played TEXT, overlay INTEGER, '
                    'UNIQUE(imdb_id, tmdb_id, season, episode))')
        if media == 'movie':
            con.execute("""DELETE FROM watched WHERE media_type=? AND
                        ((? != '' AND imdb_id=?) OR (? = '' AND tmdb_id=?))""",
                        (media, imdb, imdb, imdb, tmdb))
        else:
            con.execute("""DELETE FROM watched WHERE media_type=? AND season=? AND episode=? AND
                        ((? != '' AND imdb_id=?) OR (? = '' AND tmdb_id=?))""",
                        (media, season, episode, imdb, imdb, imdb, tmdb))
        con.execute('INSERT OR REPLACE INTO watched VALUES (?,?,?,?,?,?,?,?)',
                    (media, imdb, tmdb, season, episode, title, str(int(time.time())), 5))
        con.commit()
    finally:
        con.close()


def sync(media, metadata, position, completed=False):
    """Update Umbrella's local resume marker and watched overlay, if possible."""
    try:
        bookmark_db, watched_db = _db_paths()
        name = _bookmark_name(media, metadata)
        year = _year(metadata)
        _write_bookmark(bookmark_db, name, year, position, completed)
        _write_watched(watched_db, media, metadata, completed)
        return True
    except Exception:
        # Keep the independent Continue Watching database authoritative.
        return False
