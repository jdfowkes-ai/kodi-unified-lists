"""Create local STRM launch files for Umbrella plugin URLs."""
import hashlib
import os
import re

import xbmcaddon
import xbmcvfs


def create(media, kodi_id, plugin_url):
    """Return a stable local .strm path containing the Umbrella URL."""
    addon = xbmcaddon.Addon()
    base = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    directory = os.path.join(base, 'strm')
    xbmcvfs.mkdirs(directory)
    identity = '%s:%s' % (media, kodi_id)
    digest = hashlib.sha256(identity.encode('utf-8')).hexdigest()[:20]
    safe_media = re.sub(r'[^a-z0-9_-]', '_', str(media).lower()) or 'video'
    path = os.path.join(directory, '%s_%s.strm' % (safe_media, digest))
    handle = xbmcvfs.File(path, 'w')
    try:
        handle.write(str(plugin_url).strip())
    finally:
        handle.close()
    return path
