"""Apply one queued resume seek after Umbrella starts the matching stream."""
import json
import re
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcvfs

from identity import stable_identity
from resume_control import ResumeController
from watch_later_playback import tick as watch_later_tick, clear as clear_watch_later


PROFILE = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')))
DB_PATH = PROFILE / 'lists.db'


def _rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})
    except (ValueError, TypeError):
        return {}


def _current_item():
    active = _rpc('Player.GetActivePlayers')
    player = next((p for p in active if p.get('type') == 'video'), None)
    if not player:
        return None
    properties = ['file', 'type', 'title', 'showtitle', 'tvshowtitle', 'uniqueid',
                  'year', 'season', 'episode', 'imdbnumber']
    item = _rpc('Player.GetItem', {
        'playerid': player['playerid'], 'properties': properties
    }).get('item', {})
    path = item.get('file') or ''
    if not path:
        return None
    title = item.get('title') or item.get('label') or 'Untitled'
    is_episode = item.get('type') == 'episode' or bool(
        item.get('showtitle') or item.get('tvshowtitle'))
    try:
        is_episode = is_episode or int(item.get('episode') or 0) > 0
    except (TypeError, ValueError):
        pass
    is_episode = is_episode or bool(re.match(r'^\s*\d+\s*[x×]', title, re.I))
    media = 'episode' if is_episode else 'movie'
    mid, _identity = stable_identity(media, item, path)
    return media, mid, title, path, item


class ResumeMonitor(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.pending = ResumeController(DB_PATH, lambda: xbmc.log(
            'Unified Lists could not confirm the requested resume seek', xbmc.LOGWARNING))
        self.active = False

    def onAVStarted(self):
        self.active = True

    def onPlayBackStopped(self):
        self.active = False
        self.pending.stop()
        clear_watch_later(DB_PATH)

    def onPlayBackEnded(self):
        self.active = False
        self.pending.stop()
        clear_watch_later(DB_PATH)

    def tick(self):
        if not self.active or not self.isPlayingVideo():
            return
        item = _current_item()
        if item is None:
            return
        try:
            position, duration = float(self.getTime()), float(self.getTotalTime())
        except Exception:
            return
        self.pending.tick(self, item, position, duration)
        watch_later_tick(DB_PATH, item, position, duration)


monitor = xbmc.Monitor()
player = ResumeMonitor()
while not monitor.abortRequested():
    try:
        player.tick()
    except Exception as exc:
        xbmc.log('Unified Lists resume monitor: ' + str(exc), xbmc.LOGERROR)
    monitor.waitForAbort(1)
