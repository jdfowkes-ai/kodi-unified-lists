"""Expose bundled app and Arctic Fuse navigation artwork as Kodi directories."""
import json
import os
import re
from urllib.parse import urlencode

import xbmcgui
import xbmcplugin
import xbmcvfs


ICON_STYLES = {
    'Colour icons': 'colour-icon-only',
    'Colour with labels': 'colour-titled',
    'White icons': 'white-icon-only',
    'White with labels': 'white-titled',
}


def _slug_title(value):
    return ' '.join(part.capitalize() for part in value.replace('_', '-').split('-'))


def _item(handle, target, label, art, folder=False):
    item = xbmcgui.ListItem(label=label)
    item.setArt({'icon': art, 'thumb': art, 'poster': art})
    item.setProperty('IsPlayable', 'false')
    item.setInfo('pictures', {'title': label})
    xbmcplugin.addDirectoryItem(handle, target, item, folder)


def _plugin_url(base, **params):
    return base + '?' + urlencode(params)


def _addon_root(addon):
    return xbmcvfs.translatePath(addon.getAddonInfo('path'))


def _load_apps(root):
    path = os.path.join(root, 'resources', 'apps.json')
    with open(path, 'r', encoding='utf-8') as stream:
        apps = json.load(stream)
    return [app for app in apps if isinstance(app, dict) and app.get('id') and app.get('label')]


def _style(addon, requested):
    if requested in ICON_STYLES.values():
        return requested
    setting = addon.getSetting('icon_style') or 'Colour icons'
    return ICON_STYLES.get(setting, 'colour-icon-only')


def _navigation(handle, base, root, style):
    directory = os.path.join(root, 'resources', 'icons', 'navigation', style)
    if not os.path.isdir(directory):
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    entries = []
    for filename in sorted(os.listdir(directory)):
        stem, extension = os.path.splitext(filename)
        if extension.lower() != '.png':
            continue
        image = os.path.join(directory, filename)
        entries.append((_slug_title(stem), image))
    for label, image in entries:
        _item(handle, image, label, image)
    xbmcplugin.setPluginCategory(handle, 'Navigation icons')
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _apps(handle, base, root):
    try:
        apps = _load_apps(root)
    except (OSError, ValueError, TypeError):
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    for app in apps:
        app_id = re.sub(r'[^a-z0-9-]', '', str(app['id']).lower())
        folder = os.path.join(root, 'resources', 'app_art', app_id)
        icon = os.path.join(folder, 'icon-v121.png')
        landscape = os.path.join(folder, 'landscape-v121.png')
        if not os.path.isfile(icon):
            continue
        _item(handle, icon, app['label'], landscape if os.path.isfile(landscape) else icon)
    xbmcplugin.setPluginCategory(handle, 'App icons')
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def run(addon, handle, base, params):
    """Render the icon extension's root or one of its icon directories."""
    root = _addon_root(addon)
    view = params.get('view', '')
    if view == 'navigation':
        _navigation(handle, base, root, _style(addon, params.get('style', '')))
        return
    if view == 'apps':
        _apps(handle, base, root)
        return

    xbmcplugin.setPluginCategory(handle, 'Icon library')
    xbmcplugin.setContent(handle, 'files')
    art_root = os.path.join(root, 'resources', 'icons', 'navigation', 'colour-icon-only')
    for label, view_name, art_name in (
        ('App icons', 'apps', 'apps.png'),
        ('Navigation icons', 'navigation', 'library.png'),
    ):
        target = _plugin_url(base, action='icon_library', view=view_name)
        _item(handle, target, label, os.path.join(art_root, art_name), folder=True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
