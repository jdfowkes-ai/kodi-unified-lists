"""Build Umbrella's native play_Item URL from Kodi playback metadata."""
import json
from urllib.parse import urlencode


UMBRELLA = 'plugin://plugin.video.umbrella/'


def _ids(metadata):
    ids = metadata.get('uniqueid') or {}
    if not isinstance(ids, dict):
        ids = {}
    # Kodi may expose these identifiers as top-level fields instead.
    for key in ('imdb', 'tmdb', 'tvdb'):
        value = metadata.get(key) or metadata.get(key + '_id')
        if value and not ids.get(key):
            ids[key] = value
    if not ids.get('imdb') and metadata.get('imdbnumber'):
        ids['imdb'] = metadata['imdbnumber']
    return ids


def build(metadata, saved_path=''):
    """Reuse an Umbrella list-item route when available, otherwise rebuild it."""
    saved_path = str(saved_path or '')
    if saved_path.startswith(UMBRELLA) and 'action=play_Item' in saved_path:
        return saved_path

    title = metadata.get('title') or metadata.get('label') or ''
    show = metadata.get('showtitle') or metadata.get('tvshowtitle') or ''
    ids = _ids(metadata)
    meta = dict(metadata)
    meta.update({key: value for key, value in (
        ('imdb', ids.get('imdb')), ('tmdb', ids.get('tmdb')),
        ('tvdb', ids.get('tvdb')), ('tvshowtitle', show)) if value not in (None, '')})
    params = {
        'action': 'play_Item',
        'title': title,
        'year': str(metadata.get('year') or ''),
        'meta': json.dumps(meta, ensure_ascii=False, separators=(',', ':')),
    }
    for key, value in (('imdb', ids.get('imdb')), ('tmdb', ids.get('tmdb')),
                       ('tvdb', ids.get('tvdb'))):
        if value not in (None, ''):
            params[key] = str(value)
    if show:
        params.update({
            'tvshowtitle': show,
            'season': str(metadata.get('season') or 0),
            'episode': str(metadata.get('episode') or 0),
            'premiered': str(metadata.get('premiered') or metadata.get('firstaired') or ''),
        })
    return UMBRELLA + '?' + urlencode(params)
