"""Optional TMDb artwork and GB certification lookup for Kodi library items."""
import json
import os
import re
import time
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmcaddon
import xbmcvfs


class TMDbMetadata:
    CACHE_TTL = 30 * 24 * 60 * 60
    IMAGE_BASE = 'https://image.tmdb.org/t/p/'

    def __init__(self, addon=None, opener=None, now=None):
        self.addon = addon or xbmcaddon.Addon()
        self.opener = opener or urlopen
        self.now = now or time.time
        profile = Path(xbmcvfs.translatePath(self.addon.getAddonInfo('profile')))
        profile.mkdir(parents=True, exist_ok=True)
        self.cache_path = profile / 'tmdb_metadata.json'
        self.cache = self._load_cache()

    def _load_cache(self):
        try:
            with self.cache_path.open('r', encoding='utf-8') as source:
                data = json.load(source)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    def _save_cache(self):
        temp = self.cache_path.with_name(self.cache_path.name + '.tmp')
        try:
            with temp.open('w', encoding='utf-8') as output:
                json.dump(self.cache, output, ensure_ascii=False)
                output.flush()
                os.fsync(output.fileno())
            os.replace(str(temp), str(self.cache_path))
        finally:
            if temp.exists():
                temp.unlink()

    @staticmethod
    def tmdb_id(uniqueid):
        if isinstance(uniqueid, dict):
            value = uniqueid.get('tmdb') or uniqueid.get('themoviedb')
        else:
            value = uniqueid
        value = str(value or '').strip()
        return value if value.isdigit() else ''

    @staticmethod
    def clean_movie_title(value, year=None):
        """Remove release filename tags so movie filenames can be searched."""
        title = str(value or '').strip()
        title = re.sub(r'\.[^.]+$', '', title)
        marker = re.search(
            r'(?i)[._\s]+((?:19|20)\d{2})(?=[._\s]+(?:2160p|1080p|720p|480p|blu.?ray|web|hdr|remux|multi))',
            title)
        if marker:
            year = year or int(marker.group(1))
            title = title[:marker.start()]
        title = re.split(
            r'(?i)[._\s]+(?:2160p|1080p|720p|480p|blu.?ray|web.?dl|web.?rip|remux|hdr|multi)\b',
            title, maxsplit=1)[0]
        title = re.sub(r'[._]+', ' ', title)
        return title.strip(' [](){}-'), year

    def _request(self, endpoint, api_key, extra_params=None):
        params = {'api_key': api_key, 'language': 'en-GB'}
        params.update(extra_params or {})
        url = 'https://api.themoviedb.org/3/%s?%s' % (
            endpoint.lstrip('/'), urlencode(params))
        request = Request(url, headers={'Accept': 'application/json', 'User-Agent': 'UnifiedLocalListManager/0.3.2'})
        with self.opener(request, timeout=4) as response:
            raw = response.read(1024 * 1024)
        data = json.loads(raw.decode('utf-8'))
        return data if isinstance(data, dict) else {}

    @staticmethod
    def _gb_certification(media, response):
        if media == 'movie':
            regions = response.get('results', [])
            gb = next((region for region in regions if region.get('iso_3166_1') == 'GB'), {})
            releases = [item for item in gb.get('release_dates', []) if item.get('certification')]
            priority = {3: 0, 4: 1, 5: 2, 6: 3, 2: 4, 1: 5}
            releases.sort(key=lambda item: (priority.get(item.get('type'), 9), item.get('release_date', '')))
            return next((item.get('certification', '').strip() for item in releases
                         if item.get('certification', '').strip()), '')
        ratings = response.get('results', [])
        gb = next((item for item in ratings if item.get('iso_3166_1') == 'GB'), {})
        return (gb.get('rating') or '').strip()

    def lookup(self, media, uniqueid, need_art=False, need_cert=True, title='', year=None):
        """Return TMDb metadata, resolving a missing TMDb ID from title/year."""
        api_key = (self.addon.getSetting('tmdb_api_key') or '').strip()
        if not api_key or media not in ('movie', 'tv'):
            return {}

        tmdb = self.tmdb_id(uniqueid)
        if media == 'movie':
            title, year = self.clean_movie_title(title, year)
        if not tmdb and title:
            alias = 'search:%s:%s:%s' % (media, title.strip().casefold(), year or '')
            alias_row = self.cache.get(alias, {})
            alias_fresh = isinstance(alias_row, dict) and self.now() - alias_row.get('fetched_at', 0) < self.CACHE_TTL
            tmdb = str(alias_row.get('tmdb_id', '')) if alias_fresh else ''
            if not tmdb:
                params = {'query': title}
                if year:
                    params['year' if media == 'movie' else 'first_air_date_year'] = int(year)
                search = self._request('search/%s' % media, api_key, params)
                candidates = search.get('results', [])
                if year and candidates:
                    date_key = 'release_date' if media == 'movie' else 'first_air_date'
                    exact = [entry for entry in candidates if str(entry.get(date_key, '')).startswith(str(year))]
                    if exact:
                        candidates = exact
                tmdb = str(candidates[0].get('id', '')) if candidates else ''
                if tmdb.isdigit():
                    self.cache[alias] = {'tmdb_id': tmdb, 'fetched_at': self.now()}
        if not tmdb.isdigit():
            return {}

        key = '%s:%s' % (media, tmdb)
        cached = self.cache.get(key, {})
        fresh = isinstance(cached, dict) and self.now() - cached.get('fetched_at', 0) < self.CACHE_TTL
        if fresh and (not need_cert or cached.get('cert_checked')) and \
                (not need_art or cached.get('art_checked')) and cached.get('details_checked'):
            return {k: v for k, v in cached.items() if k != 'fetched_at'}

        result = dict(cached) if isinstance(cached, dict) else {}
        path = 'movie' if media == 'movie' else 'tv'
        try:
            if not fresh or not result.get('details_checked'):
                details = self._request('%s/%s' % (path, tmdb), api_key)
                result['title'] = details.get('title') or details.get('name') or ''
                result['plot'] = details.get('overview') or ''
                date_value = details.get('release_date') or details.get('first_air_date') or ''
                result['year'] = int(date_value[:4]) if len(date_value) >= 4 and date_value[:4].isdigit() else 0
                runtimes = details.get('episode_run_time') or []
                runtime_minutes = details.get('runtime') or (runtimes[0] if runtimes else 0) or 0
                result['runtime'] = int(runtime_minutes) * 60 if str(runtime_minutes).isdigit() else 0
                result['details_checked'] = True
            if need_cert and (not fresh or not result.get('cert_checked')):
                endpoint = ('movie/%s/release_dates' if media == 'movie' else
                            'tv/%s/content_ratings') % tmdb
                result['mpaa'] = self._gb_certification(media, self._request(endpoint, api_key))
                result['cert_checked'] = True
            if need_art and (not fresh or not result.get('art_checked')):
                details = self._request('%s/%s' % (path, tmdb), api_key)
                poster = details.get('poster_path') or ''
                backdrop = details.get('backdrop_path') or ''
                if poster:
                    result['poster'] = self.IMAGE_BASE + 'w500' + poster
                if backdrop:
                    result['fanart'] = self.IMAGE_BASE + 'w1280' + backdrop
                result['art_checked'] = True
            result['fetched_at'] = self.now()
            self.cache[key] = result
            self._save_cache()
        except Exception:
            # Keep Kodi's own values available if TMDb is unavailable.
            pass
        return {k: v for k, v in result.items() if k != 'fetched_at'}
