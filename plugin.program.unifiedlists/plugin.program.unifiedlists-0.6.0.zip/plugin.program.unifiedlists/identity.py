"""Stable local identities for movies and episodes outside Kodi's library."""
import hashlib
import re


def _normal(value):
    return re.sub(r'[^a-z0-9]+', '', str(value or '').casefold())


def stable_identity(media, item, path=''):
    ids = item.get('uniqueid') or {}
    if not isinstance(ids, dict):
        ids = {'tmdb': str(ids)} if str(ids).isdigit() else {}
    title = item.get('title') or item.get('label') or ''
    year = item.get('year') or 0
    if media == 'episode':
        try:
            season, episode = int(item.get('season') or 0), int(item.get('episode') or 0)
        except (TypeError, ValueError):
            season, episode = 0, 0
        show = item.get('showtitle') or item.get('tvshowtitle') or ''
        show_id = ids.get('tvdb') or ids.get('tvdb_id') or ids.get('tmdb')
        if season > 0 and episode > 0 and (show_id or show):
            identity = 'episode:%s:%s:%s' % (show_id or _normal(show), season, episode)
        else:
            identity = 'episode:%s:%s:%s:%s' % (
                show_id or _normal(show), season, episode, _normal(title) or path)
    elif ids.get('tmdb') or ids.get('themoviedb'):
        identity = 'movie:tmdb:%s' % (ids.get('tmdb') or ids.get('themoviedb'))
    elif ids.get('imdb') or item.get('imdbnumber'):
        identity = 'movie:imdb:%s' % (ids.get('imdb') or item.get('imdbnumber'))
    elif title:
        identity = 'movie:%s:%s' % (_normal(title), year)
    else:
        identity = 'movie:path:%s' % path
    digest = int(hashlib.sha256(identity.encode('utf-8')).hexdigest()[:15], 16)
    return -(digest or 1), identity
