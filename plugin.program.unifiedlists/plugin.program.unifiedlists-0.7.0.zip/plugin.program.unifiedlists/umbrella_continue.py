"""Build one mixed Continue Watching directory from Umbrella's local cache.

Playback remains owned by Umbrella. The item mirrors Umbrella's playable
ListItem metadata so Kodi can show its native resume prompt on OK.
"""
import ast
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlencode, urlparse, parse_qs

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


UMBRELLA = 'plugin://plugin.video.umbrella/'
UK_CERTIFICATES = {'u', 'pg', '12', '12a', '15', '18', 'r18', 'uc', 'a', 'aa', 'x'}


def _is_uk_certificate(value):
    import re
    value = str(value or '').strip().lower()
    value = re.sub(r'^(?:united kingdom|bbfc|uk|gb)\s*:?\s*', '', value)
    value = re.sub(r'^rated\s+', '', value)
    return value in UK_CERTIFICATES


def _profile_file(name):
    profile = Path(xbmcvfs.translatePath(
        xbmcaddon.Addon('plugin.video.umbrella').getAddonInfo('profile')))
    return profile / name


def _open_readonly(path):
    return sqlite3.connect('file:%s?mode=ro' % path.as_posix(), uri=True, timeout=3)


def _read_progress():
    path = _profile_file('watched.db')
    if not path.is_file():
        return []
    try:
        with _open_readonly(path) as con:
            rows = con.execute(
                "SELECT media_type, imdb_id, tmdb_id, season, episode, title, "
                "resume_point, curr_time, last_played FROM progress "
                "WHERE media_type IN ('movie','episode') "
                "ORDER BY CAST(last_played AS INTEGER) DESC").fetchall()
        return rows
    except (sqlite3.Error, OSError):
        return []



def _read_watched_episodes():
    """Return Umbrella's locally watched episodes grouped by series ID."""
    path = _profile_file('watched.db')
    if not path.is_file():
        return {}
    try:
        with _open_readonly(path) as con:
            # Match Umbrella's own local progress and next-up lists: only
            # overlay=5 rows are watched. Overlay=4 rows are explicitly
            # unwatched and must not advance a show's next episode.
            rows = con.execute(
                "SELECT imdb_id, tmdb_id, season, episode, title, last_played "
                "FROM watched WHERE media_type='episode' AND overlay=5 "
                "ORDER BY CAST(last_played AS INTEGER) DESC").fetchall()
    except (sqlite3.Error, OSError):
        return {}
    shows = {}
    for imdb, tmdb, season, episode, title, last_played in rows:
        tmdb = str(tmdb or '').strip()
        imdb = str(imdb or '').strip()
        if not tmdb.isdigit() and not imdb:
            continue
        try:
            season, episode = int(season or 0), int(episode or 0)
        except (TypeError, ValueError):
            continue
        if season <= 0 or episode <= 0:
            continue
        # Umbrella groups its native local in-progress show list by IMDb ID;
        # prefer that key and use TMDb only when IMDb is absent.
        key = 'imdb:' + imdb if imdb else tmdb
        entry = shows.setdefault(key, {
            'imdb': imdb, 'tmdb': tmdb if tmdb.isdigit() else '',
            'title': str(title or ''),
            'last_played': str(last_played or ''), 'latest': None, 'watched': set(),
        })
        if tmdb.isdigit() and not entry.get('tmdb'):
            entry['tmdb'] = tmdb
        entry['watched'].add((season, episode))
        if entry['latest'] is None:
            entry['latest'] = (season, episode)
            entry['imdb'] = str(imdb or entry['imdb'])
            entry['title'] = str(title or entry['title'])
            entry['last_played'] = str(last_played or '')
    return shows




def _meta_lookup(imdb, tmdb):
    path = _profile_file('metadata.db')
    if not path.is_file():
        return {}
    try:
        with _open_readonly(path) as con:
            row = con.execute(
                "SELECT item FROM meta WHERE "
                "(? != '' AND imdb=?) OR (? != '' AND tmdb=?) "
                "ORDER BY CAST(time AS INTEGER) DESC LIMIT 1",
                (imdb, imdb, tmdb, tmdb)).fetchone()
        if row and row[0]:
            value = ast.literal_eval(row[0])
            return value if isinstance(value, dict) else {}
    except (sqlite3.Error, OSError, ValueError, SyntaxError, TypeError):
        pass
    return {}


def _payload(row):
    media, imdb, tmdb, season, episode, title, percent, position, last_played = row
    metadata = _meta_lookup(str(imdb or ''), str(tmdb or ''))
    metadata = dict(metadata)
    media = str(media)
    title = str(title or metadata.get('title') or metadata.get('name') or 'Untitled')
    season, episode = int(season or 0), int(episode or 0)
    try:
        percent = max(0.0, min(100.0, float(percent or 0)))
    except (TypeError, ValueError):
        percent = 0.0
    try:
        position = max(0.0, float(position or 0))
    except (TypeError, ValueError):
        position = 0.0

    ids = metadata.get('ids') or metadata.get('uniqueid') or {}
    ids = ids if isinstance(ids, dict) else {}
    imdb = str(imdb or metadata.get('imdb') or ids.get('imdb') or '')
    tmdb = str(tmdb or metadata.get('tmdb') or ids.get('tmdb') or '')
    tvdb = str(metadata.get('tvdb') or ids.get('tvdb') or '')
    metadata['uniqueid'] = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}
    show = (metadata.get('tvshowtitle') or metadata.get('showtitle') or
            metadata.get('name') or metadata.get('title') or '')
    year = metadata.get('year') or ''
    if media == 'movie':
        metadata.update({'title': title, 'mediatype': 'movie', 'imdb': imdb,
                         'tmdb': tmdb, 'year': year})
        label = title
    else:
        metadata.update({'title': title, 'name': title, 'mediatype': 'episode',
                         'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb,
                         'tvshowtitle': show, 'showtitle': show,
                         'season': season, 'episode': episode, 'year': year})
        label = '%s · S%02d E%02d · %s' % (show or title, season, episode, title)
    metadata['progress'] = percent
    metadata['resume_position'] = position
    # The Umbrella cache may contain the full scraper metadata; otherwise use
    # the add-on's existing TMDb cache/client when the user configured a key.
    # For episodes, lookup the series title so we never search by episode name.
    premiere = (metadata.get('premiered') or metadata.get('firstaired') or
                metadata.get('first_aired') or metadata.get('release_date') or '')
    if premiere:
        metadata['premiered'] = str(premiere)[:10]
    tmdb_client = None
    if ((not metadata.get('genre') and not metadata.get('genres')) or
            (not metadata.get('runtime') and not metadata.get('duration')) or
            not _is_uk_certificate(metadata.get('mpaa') or metadata.get('certification')) or
            not metadata.get('year') or
            (media == 'movie' and not metadata.get('premiered'))):
        try:
            from tmdb_metadata import TMDbMetadata
            tmdb_client = TMDbMetadata()
            remote = tmdb_client.lookup(
                'tv' if media == 'episode' else 'movie',
                {'tmdb': tmdb}, need_art=False, need_cert=True,
                title=show if media == 'episode' else title, year=year)
            for key in ('genre', 'genres', 'runtime', 'mpaa', 'rating', 'votes', 'year'):
                if remote.get(key) and (not metadata.get(key) or
                                        key == 'mpaa' and not _is_uk_certificate(metadata.get(key))):
                    metadata[key] = remote[key]
            if media == 'movie' and remote.get('premiered') and not metadata.get('premiered'):
                metadata['premiered'] = remote['premiered']
            if remote.get('runtime') and media == 'episode':
                metadata.setdefault('duration', remote['runtime'])
        except Exception:
            pass
    episode_duration = 0.0
    if media == 'episode' and (not metadata.get('premiered') or
                               not metadata.get('duration') or
                               not (metadata.get('plot') or metadata.get('overview'))):
        try:
            if tmdb_client is None:
                from tmdb_metadata import TMDbMetadata
                tmdb_client = TMDbMetadata()
            remote_episode = tmdb_client.episode_details(tmdb, season, episode)
            for key in ('premiered', 'rating', 'votes'):
                if remote_episode.get(key) and not metadata.get(key):
                    metadata[key] = remote_episode[key]
            # Keep the episode-specific duration for Kodi's information view,
            # but do not replace Umbrella's cached playback metadata. Umbrella
            # owns its resume calculation and may interpret duration using its
            # own metadata conventions.
            try:
                episode_duration = float(remote_episode.get('duration') or 0)
            except (TypeError, ValueError):
                episode_duration = 0.0
            if remote_episode.get('plot') and not (metadata.get('plot') or metadata.get('overview')):
                metadata['plot'] = remote_episode['plot']
            if remote_episode.get('still_path') and not metadata.get('thumb'):
                metadata['thumb'] = tmdb_client.IMAGE_BASE + 'w500' + remote_episode['still_path']
        except Exception:
            pass
    # Umbrella's local bookmark lookup requires a non-empty year. For episodes,
    # this is the series premiere year (as used by Umbrella), not the episode's
    # air year. Preserve the cached value where available and otherwise use the
    # series year returned by TMDb.
    # Keep the play_Item year identical to umbrella_local._year(). When both
    # cached metadata and TMDb lack a year, Umbrella still accepts '0' and uses
    # it to match the local bookmark; an empty query value makes it return 0.
    year = metadata.get('year') or year or '0'
    metadata['year'] = year
    if not year and media == 'movie' and premiere[:4].isdigit():
        year = int(premiere[:4])
        metadata['year'] = year
    return {
        'media': media, 'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb,
        'season': season, 'episode': episode, 'title': title,
        'show': show, 'year': year, 'percent': percent,
        'position': position, 'last_played': str(last_played or ''),
        'label': label, 'metadata': metadata,
        'episode_duration': episode_duration,
    }



def _next_episode_payload(tmdb, watched, tmdb_client, after=None):
    """Build a normal Umbrella-playable row for the next aired episode."""
    imdb = watched.get('imdb', '')
    tmdb = str(tmdb or watched.get('tmdb') or '').strip()
    if not tmdb.isdigit() and imdb:
        tmdb = tmdb_client.resolve_tv_tmdb_id(imdb)
    if not tmdb.isdigit():
        return None
    # Umbrella's local next-up list walks watched episodes in season/episode
    # order. Include an unfinished episode as the anchor so its next episode
    # can appear alongside the separate Finish Watching/resume entry.
    anchor = after or watched.get('latest') or (0, 0)
    watched_episodes = set(watched.get('watched', set()))
    # The current partial episode belongs in Umbrella's Finish Watching feed.
    # Treat it as the anchor when calculating the separate next-up episode.
    if anchor and tuple(anchor) > (0, 0):
        watched_episodes.add(tuple(anchor))
    episode = tmdb_client.next_available_episode(tmdb, 0, 0, watched_episodes)
    if not episode:
        return None
    show_meta = tmdb_client.lookup('tv', {'tmdb': tmdb}, need_art=True,
                                   need_cert=True, title=watched.get('title', ''))
    if not show_meta:
        return None
    show = show_meta.get('title') or show_meta.get('name') or watched.get('title', '')
    title = str(episode.get('name') or '').strip()
    try:
        season = int(episode.get('season_number') or 0)
        number = int(episode.get('episode_number') or 0)
    except (TypeError, ValueError):
        return None
    if not show or not title or season <= 0 or number <= 0:
        return None
    still = str(episode.get('still_path') or '')
    image_base = tmdb_client.IMAGE_BASE
    episode_still = image_base + 'w500' + still if still.startswith('/') else ''
    metadata = dict(show_meta)
    metadata.update({
        'title': title, 'name': title, 'mediatype': 'episode',
        'imdb': imdb, 'tmdb': str(tmdb),
        'tvshowtitle': show, 'showtitle': show,
        'season': season, 'episode': number,
        'premiered': str(episode.get('air_date') or ''),
        'plot': episode.get('overview') or '',
        'rating': episode.get('vote_average') or show_meta.get('rating') or 0,
        'votes': episode.get('vote_count') or show_meta.get('votes') or 0,
        'uniqueid': {'imdb': imdb, 'tmdb': str(tmdb)},
        'art': {
            'poster': show_meta.get('poster') or '',
            'fanart': show_meta.get('fanart') or '',
            'thumb': episode_still or show_meta.get('poster') or '',
            'landscape': episode_still or show_meta.get('fanart') or '',
        },
    })
    try:
        runtime = int(episode.get('runtime') or 0)
        # TMDb reports episode runtime in minutes.
        metadata['duration'] = runtime * 60 if runtime < 1000 else runtime
    except (TypeError, ValueError):
        metadata['duration'] = 0
    return {
        'media': 'episode', 'imdb': imdb,
        'tmdb': str(tmdb), 'tvdb': str(show_meta.get('tvdb') or ''),
        'season': season, 'episode': number, 'title': title,
        'show': show, 'year': show_meta.get('year') or '',
        'percent': 0.0, 'position': 0.0,
        'last_played': watched.get('last_played', ''),
        'label': '%s · S%02d E%02d · %s' % (show, season, number, title),
        'metadata': metadata,
    }




def _umbrella_play_url(data):
    meta = dict(data['metadata'])
    # Umbrella's item links use action=play_Item with its native identifying
    # fields and serialized metadata. This retains its source selection,
    # resume and playback behavior.
    params = {
        'action': 'play_Item', 'title': data['title'], 'year': data['year'],
        'imdb': data['imdb'], 'tmdb': data['tmdb'], 'tvdb': data['tvdb'],
        'meta': json.dumps(meta, ensure_ascii=False, separators=(',', ':')),
    }
    if data['media'] == 'episode':
        params.update({'season': data['season'], 'episode': data['episode'],
                       'tvshowtitle': data['show'],
                       'premiered': meta.get('premiered', '')})
    return UMBRELLA + '?' + urlencode(params)


def _addon_url(action, payload):
    import sys
    encoded = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
    return sys.argv[0] + '?' + urlencode({'action': action, 'data': encoded})


def _dedupe_items(items):
    """Collapse repeated media cards while preserving the resumable payload."""
    unique = []
    aliases = {}
    for data in items:
        media = data.get('media')
        if media == 'episode':
            suffix = (int(data.get('season') or 0), int(data.get('episode') or 0))
            ids = {str(data.get(name) or '').strip().casefold()
                   for name in ('tmdb', 'imdb', 'tvdb')}
            ids.discard('')
            show = str(data.get('show') or '').strip().casefold()
            if show:
                ids.add('title:' + show)
            keys = {(media, value) + suffix for value in ids}
        else:
            ids = {str(data.get(name) or '').strip().casefold()
                   for name in ('tmdb', 'imdb')}
            ids.discard('')
            title = str(data.get('title') or '').strip().casefold()
            if title:
                ids.add('title:' + title)
            keys = {(media, value) for value in ids}
        matches = {aliases[key] for key in keys if key in aliases}
        if matches:
            index = min(matches)
            previous = unique[index]
            if float(data.get('position') or 0) > float(previous.get('position') or 0):
                unique[index] = data
            # Register every identifier seen for this item so IMDb-only,
            # TMDb-only, and fully identified rows collapse together.
            for key in keys:
                aliases[key] = index
        else:
            index = len(unique)
            unique.append(data)
            for key in keys:
                aliases[key] = index
    return unique


def _listitem(data):
    li = xbmcgui.ListItem(label=data['label'])
    meta = data['metadata']
    art = meta.get('art') if isinstance(meta.get('art'), dict) else {}
    art = dict(art)
    for target, keys in {
        'poster': ('poster', 'thumb'), 'thumb': ('thumb', 'poster'),
        'landscape': ('landscape', 'fanart', 'thumb', 'poster'),
        'fanart': ('fanart', 'landscape'), 'icon': ('icon', 'poster', 'thumb'),
    }.items():
        if not art.get(target):
            art[target] = next((meta.get(k) for k in keys if meta.get(k)), '')
    li.setArt({k: str(v).replace(' ', '%20') for k, v in art.items() if v})
    tag = li.getVideoInfoTag()
    tag.setMediaType(data['media'])
    tag.setTitle(data['title'])
    tag.setPlot(meta.get('plot') or meta.get('overview') or '')
    genres = meta.get('genres') or meta.get('genre') or []
    if isinstance(genres, str):
        genres = [part.strip() for part in genres.replace('|', ',').split(',') if part.strip()]
    elif isinstance(genres, dict):
        genres = [str(value) for value in genres.values() if value]
    elif not isinstance(genres, (list, tuple)):
        genres = []
    else:
        genres = [str(value.get('name') if isinstance(value, dict) else value)
                  for value in genres if value]
    if genres:
        try:
            tag.setGenres(genres)
        except (AttributeError, TypeError, ValueError):
            pass
    certificate = (meta.get('mpaa') or meta.get('certification') or
                   meta.get('content_rating') or meta.get('rating_certification'))
    if certificate:
        try:
            tag.setMpaa(str(certificate))
        except (AttributeError, TypeError, ValueError):
            pass
    try:
        if meta.get('rating'):
            tag.setRating(float(meta['rating']), int(meta.get('votes') or 0), 'imdb')
    except (AttributeError, TypeError, ValueError):
        pass
    ids = {key: value for key, value in {
        'imdb': data.get('imdb'), 'tmdb': data.get('tmdb'),
        'tvdb': data.get('tvdb')}.items() if value}
    try:
        if ids:
            tag.setUniqueIDs(ids)
    except (AttributeError, TypeError, ValueError):
        pass
    try:
        if data['year']:
            tag.setYear(int(data['year']))
    except (TypeError, ValueError):
        pass
    if data['media'] == 'episode':
        tag.setTvShowTitle(data['show'])
        tag.setSeason(data['season'])
        tag.setEpisode(data['episode'])
    premiered = (meta.get('premiered') or meta.get('firstaired') or
                 meta.get('first_aired') or meta.get('release_date') or '')
    premiered = str(premiered)[:10]
    if premiered:
        try:
            tag.setPremiered(premiered)
        except (AttributeError, TypeError, ValueError):
            pass
        if data['media'] == 'episode':
            try:
                tag.setFirstAired(premiered)
            except (AttributeError, TypeError, ValueError):
                pass
    try:
        duration = float(data.get('episode_duration') or meta.get('duration') or
                         meta.get('runtime') or 0)
    except (TypeError, ValueError):
        duration = 0.0
    if duration <= data['position'] and data['percent'] > 0:
        duration = data['position'] * 100.0 / data['percent']
    if duration <= data['position']:
        duration = data['position'] + max(60.0, data['position'] * 0.2)
    try:
        tag.setDuration(float(duration))
    except (AttributeError, TypeError, ValueError):
        pass
    if data['position'] >= 30:
        # Umbrella's own widgets use VideoInfoTag.setResumePoint plus
        # IsPlayable; Kodi then passes resume:true/false to Umbrella.
        try:
            tag.setResumePoint(float(data['position']), float(duration))
        except (AttributeError, TypeError, ValueError):
            pass
    if data['media'] == 'episode':
        li.setProperty('tvshow.tmdb_id', str(data.get('tmdb') or ''))
        li.setProperty('episode_type', str(meta.get('episode_type') or ''))
    li.setProperty('IsPlayable', 'true')
    li.setProperty('WatchedProgress', str(round(data['percent'])))
    li.setProperty('PercentPlayed', str(round(data['percent'])))
    # Do not set isUmbrella_widget: Umbrella gates its extra context commands
    # on that marker. Kodi still gets the native resume point and Umbrella URL.
    return li


def _run_action(action, data):
    play_url = _umbrella_play_url(data)
    if action == 'continue_actions':
        xbmc.executebuiltin('Action(ContextMenu)')
    elif action == 'continue_resume':
        # Keep Umbrella's native bookmark available, then request a confirmed
        # post-start seek so resume works even if Umbrella's bookmark lookup
        # does not recognize this cached progress record.
        from umbrella_local import set_resume_bookmark
        set_resume_bookmark(data['media'], data['metadata'], data['position'])
        from identity import stable_identity
        from resume_control import queue
        from default import DB_PATH
        mid, _identity = stable_identity(data['media'], data['metadata'], play_url)
        queue(DB_PATH, data['media'], mid, data['position'], play_url, data['metadata'])
        _queue_watch_later(data, mid)
        xbmc.executebuiltin('PlayMedia(%s)' % play_url)
    elif action == 'continue_beginning':
        from umbrella_local import clear_bookmark
        clear_bookmark(data['media'], data['metadata'])
        from identity import stable_identity
        from default import DB_PATH
        mid, _identity = stable_identity(data['media'], data['metadata'], play_url)
        _queue_watch_later(data, mid)
        xbmc.executebuiltin('PlayMedia(%s)' % play_url)
    elif action == 'continue_trailer':
        # One trailer choice only. Umbrella resolves a trailer if no cached
        # trailer URL is present, using its native selection route.
        if data['metadata'].get('trailer'):
            params = {'action': 'play_Trailer_Context', 'type': 'movie',
                      'name': data['title'], 'year': data['year'],
                      'imdb': data['imdb'], 'url': data['metadata']['trailer']}
        else:
            params = {'action': 'play_Trailer_Select', 'type': 'movie',
                      'name': data['title'], 'year': data['year']}
        xbmc.executebuiltin('RunPlugin(%s?%s)' % (UMBRELLA, urlencode(params)))
    elif action == 'continue_information':
        xbmc.executebuiltin('Action(Info)')
    elif action == 'continue_watch_later':
        if data.get('source_list') == 'Watch Later':
            _remove_watch_later(data)
        else:
            _save_watch_later(data)
    elif action == 'continue_favourite':
        params = {'action': ('add_favorite' if data['media'] == 'movie'
                             else 'add_favorite_episode'),
                  'meta': json.dumps(data['metadata'], ensure_ascii=False,
                                     separators=(',', ':')),
                  'content': ('movies' if data['media'] == 'movie' else 'episode')}
        xbmc.executebuiltin('RunPlugin(%s?%s)' % (UMBRELLA, urlencode(params)))


def _save_watch_later(data):
    import sys
    import sqlite3
    from pathlib import Path
    import xbmcaddon
    import xbmcvfs
    from identity import stable_identity
    from default import DB_PATH
    media = data['media']
    play_url = _umbrella_play_url(data)
    mid, _identity = stable_identity(media, data['metadata'], play_url)
    con = sqlite3.connect(str(DB_PATH))
    try:
        con.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?)',
                    ('Watch Later', media, mid, data['title']))
        action_url = _addon_url('continue_actions', data)
        con.execute('INSERT OR REPLACE INTO external_list_items '
                    '(media_type,kodi_id,path,is_folder,metadata_json) VALUES (?,?,?,?,?)',
                    (media, mid, action_url, 0,
                     json.dumps(data['metadata'], ensure_ascii=False)))
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'Added to Watch Later',
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def _remove_watch_later(data):
    import sqlite3
    from default import DB_PATH
    mid = int(data.get('local_kodi_id') or 0)
    con = sqlite3.connect(str(DB_PATH), timeout=10)
    try:
        con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                    ('Watch Later', data['media'], mid))
        con.execute('DELETE FROM external_list_items WHERE media_type=? AND kodi_id=? '
                    'AND NOT EXISTS (SELECT 1 FROM entries WHERE media_type=? AND kodi_id=?)',
                    (data['media'], mid, data['media'], mid))
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'Removed from Watch Later',
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def _queue_watch_later(data, mid):
    if data.get('source_list') != 'Watch Later':
        return
    from default import DB_PATH
    from watch_later_playback import queue
    queue(DB_PATH, data['media'], int(data.get('local_kodi_id') or mid),
          data.get('title', ''), data.get('metadata', {}))


def watch_later_payload(media, mid, title, path, metadata_json, saved=None):
    """Build the same compact action item for old and new Watch Later rows."""
    metadata = {}
    try:
        metadata = json.loads(metadata_json or '{}')
    except (ValueError, TypeError):
        pass
    data = None
    if path and path.startswith('plugin://plugin.program.unifiedlists'):
        parsed = parse_qs(urlparse(path).query)
        raw = parsed.get('data', ['{}'])[0]
        try:
            candidate = json.loads(raw)
            if isinstance(candidate, dict) and candidate.get('media') in ('movie', 'episode'):
                data = candidate
        except (ValueError, TypeError):
            pass
    if data is None:
        ids = metadata.get('uniqueid') or metadata.get('ids') or {}
        if not isinstance(ids, dict):
            ids = {}
        season = int(metadata.get('season') or 0)
        episode = int(metadata.get('episode') or 0)
        show = metadata.get('tvshowtitle') or metadata.get('showtitle') or ''
        data = {'media': media, 'title': title, 'label': title, 'show': show,
                'year': metadata.get('year') or '', 'imdb': str(ids.get('imdb') or metadata.get('imdb') or ''),
                'tmdb': str(ids.get('tmdb') or metadata.get('tmdb') or ''),
                'tvdb': str(ids.get('tvdb') or metadata.get('tvdb') or ''),
                'season': season, 'episode': episode, 'percent': 0,
                'position': float(saved[0]) if saved and saved[0] else 0,
                'metadata': metadata}
    data.update({'source_list': 'Watch Later', 'local_kodi_id': int(mid)})
    if saved:
        data['position'] = float(saved[0] or 0)
        data['percent'] = (100.0 * saved[0] / saved[1]) if saved[1] else 0
    data['label'] = ('%s · S%02d E%02d · %s' % (data.get('show') or title,
                    int(data.get('season') or 0), int(data.get('episode') or 0), title)
                    if media == 'episode' else title)
    return data


def run_listing(handle):
    xbmcplugin.setContent(handle, 'videos')
    rows = _read_progress()
    items = []
    # Umbrella's Finish Watching feed is the source for resumable movies.
    # TV next episodes come from its separate Local: In-Progress Episodes
    # logic below; partial episode rows are deliberately not included here.
    for row in rows:
        data = _payload(row)
        if data['media'] != 'movie':
            continue
        if not data['imdb'] and not data['tmdb']:
            continue
        if data['percent'] >= 90:
            continue
        if data['position'] >= 30:
            from umbrella_local import set_resume_bookmark
            set_resume_bookmark(data['media'], data['metadata'], data['position'])
        items.append(data)

    # Mirror Umbrella's local_progress_list: overlay=5 episode history drives
    # one next released, unwatched episode per show.
    try:
        from tmdb_metadata import TMDbMetadata
        tmdb_client = TMDbMetadata()
        for watched in _read_watched_episodes().values():
            tmdb = watched.get('tmdb')
            data = _next_episode_payload(tmdb, watched, tmdb_client)
            if data:
                items.append(data)
    except Exception:
        pass

    items = _dedupe_items(items)

    def _activity_key(data):
        try:
            return int(data.get('last_played') or 0)
        except (TypeError, ValueError):
            return 0

    items.sort(key=_activity_key, reverse=True)
    for data in items:
        target = _umbrella_play_url(data)
        xbmcplugin.addDirectoryItem(handle, target, _listitem(data), False)


def run_action():
    import sys
    from urllib.parse import parse_qs
    from urllib.parse import unquote
    params = parse_qs(sys.argv[2][1:])
    action = params.get('action', ['continue_actions'])[0]
    raw = params.get('data', ['{}'])[0]
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return
    if not isinstance(data, dict) or data.get('media') not in ('movie', 'episode'):
        return
    _run_action(action, data)
