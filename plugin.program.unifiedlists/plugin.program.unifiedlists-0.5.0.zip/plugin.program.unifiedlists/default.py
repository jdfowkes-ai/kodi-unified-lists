import sys
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlencode, parse_qs
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from media_display import MediaDisplay

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PARAMS = {k: v[0] for k, v in parse_qs(sys.argv[2][1:]).items()}
DB_PATH = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))) / 'lists.db'
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
DISPLAY = MediaDisplay()


def db():
    con = sqlite3.connect(str(DB_PATH))
    con.execute('CREATE TABLE IF NOT EXISTS entries (list_name TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, PRIMARY KEY (list_name, media_type, kodi_id))')
    con.execute("CREATE TABLE IF NOT EXISTS playback_progress (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL, completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, source_metadata TEXT NOT NULL DEFAULT '{}', PRIMARY KEY(media_type,kodi_id))")
    columns = {row[1] for row in con.execute('PRAGMA table_info(playback_progress)')}
    if 'source_metadata' not in columns:
        con.execute("ALTER TABLE playback_progress ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
    con.execute('CREATE TABLE IF NOT EXISTS external_list_items (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, path TEXT NOT NULL, is_folder INTEGER NOT NULL DEFAULT 0, metadata_json TEXT NOT NULL DEFAULT \'{}\', PRIMARY KEY(media_type,kodi_id))')
    con.execute("CREATE TABLE IF NOT EXISTS dismissed_continue (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, file_path TEXT NOT NULL DEFAULT '', PRIMARY KEY(media_type,kodi_id))")
    if 'file_path' not in {row[1] for row in con.execute('PRAGMA table_info(dismissed_continue)')}:
        con.execute("ALTER TABLE dismissed_continue ADD COLUMN file_path TEXT NOT NULL DEFAULT ''")
    con.commit()
    return con


def url(**kwargs):
    return BASE + '?' + urlencode(kwargs)


def item(label, target, folder=True, menu=None, media=None, mid=None, progress=None):
    li = DISPLAY.listitem(media, mid, label, progress) if media else xbmcgui.ListItem(label=label)
    if menu is not None:
        li.addContextMenuItems(menu, replaceItems=True)
    elif media in ('movie', 'episode', 'tvshow'):
        li.addContextMenuItems(local_context_menu(), replaceItems=True)
    xbmcplugin.addDirectoryItem(HANDLE, target, li, folder)


def local_context_menu():
    """Keep video rows in this add-on to the user's four approved actions."""
    actions = (
        ('Play / Resume', 'play_resume'),
        ('Info', 'info'),
        ('Add to Watch Later', 'watch_later'),
        ('Add to Favourites', 'favourites'),
    )
    return [(label, 'RunScript(plugin.program.unifiedlists,%s)' % action)
            for label, action in actions]


def progress_context_menu(media, mid, has_progress):
    """Context actions for our locally tracked playback rows."""
    actions = []
    actions.append(('Resume' if has_progress else 'Play', url(
        action='resume_context', media=media, mid=mid)))
    if has_progress:
        actions.append(('Play from Beginning', url(
            action='resume_context', media=media, mid=mid, start=0)))
    actions.extend((('Info', 'Action(Info)'),
                    ('Add to Watch Later', url(action='toggle_saved', list='Watch Later', media=media, mid=mid)),
                    ('Add to Favourites', url(action='toggle_saved', list='Favourites', media=media, mid=mid)),
                    ('Remove from Continue Watching', url(action='remove_continue', media=media, mid=mid))))
    return [(label, 'RunPlugin(%s)' % target if target.startswith('plugin://') else target)
            for label, target in actions]


def next_episode_context_menu(metadata, umbrella_path):
    payload = json.dumps({'metadata': metadata, 'umbrella_path': umbrella_path},
                         ensure_ascii=False, separators=(',', ':'))
    play_target = url(action='play_new', data=payload)
    add_later = url(action='save_metadata', list='Watch Later', data=payload)
    add_favourite = url(action='save_metadata', list='Favourites', data=payload)
    from identity import stable_identity
    mid, _identity = stable_identity('episode', metadata, umbrella_path)
    remove_target = url(action='remove_continue', media='episode', mid=mid)
    return [('Play', 'RunPlugin(%s)' % play_target),
            ('Info', 'Action(Info)'),
            ('Add to Watch Later', 'RunPlugin(%s)' % add_later),
            ('Add to Favourites', 'RunPlugin(%s)' % add_favourite),
            ('Remove from Continue Watching', 'RunPlugin(%s)' % remove_target)]


def saved_item_context_menu(media, mid, has_progress):
    actions = [('Resume' if has_progress else 'Play', url(
        action='play_external', media=media, mid=mid))]
    if has_progress:
        actions.append(('Play from Beginning', url(
            action='play_external', media=media, mid=mid, start=0)))
    actions.extend((('Info', 'Action(Info)'),
                    ('Add to Watch Later', url(action='toggle_saved', list='Watch Later', media=media, mid=mid)),
                    ('Add to Favourites', url(action='toggle_saved', list='Favourites', media=media, mid=mid))))
    return [(label, 'RunPlugin(%s)' % target if target.startswith('plugin://') else target)
            for label, target in actions]


def movie_progress(mid):
    con = db()
    try:
        row = con.execute('SELECT position,duration FROM playback_progress WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30', ('movie', int(mid))).fetchone()
        return row
    finally:
        con.close()


def show_list(name):
    xbmcplugin.setContent(HANDLE, "videos")
    con = db()
    rows = con.execute('SELECT e.media_type,e.kodi_id,e.title,x.path,x.is_folder,x.metadata_json '
                        'FROM entries e LEFT JOIN external_list_items x '
                        'ON x.media_type=e.media_type AND x.kodi_id=e.kodi_id '
                        'WHERE e.list_name=? ORDER BY e.title', (name,)).fetchall()
    for media, mid, title, path, is_folder, metadata_json in rows:
        if path:
            try:
                metadata = json.loads(metadata_json or '{}')
            except (ValueError, TypeError):
                metadata = {}
            if isinstance(metadata, dict):
                DISPLAY.cache[(media, int(mid))] = metadata
            saved = con.execute('SELECT position,duration FROM playback_progress '
                                'WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30',
                                (media, int(mid))).fetchone()
            li = DISPLAY.listitem(media, mid, title, saved)
            if saved and saved[1] > 0:
                li.setProperty('WatchedProgress', str(min(100, max(0, round(100 * saved[0] / saved[1])))))
            if not is_folder:
                li.setProperty('IsPlayable', 'true')
                li.addContextMenuItems(saved_item_context_menu(media, int(mid), bool(saved)), replaceItems=True)
                target = url(action='play_external', media=media, mid=mid)
            else:
                target = path
            xbmcplugin.addDirectoryItem(HANDLE, target, li, bool(is_folder))
            continue
        item(title, url(action='unavailable'), False, media=media, mid=mid)
    con.close()


def change(add):
    name, media, mid = PARAMS.get('list', ''), PARAMS.get('media', ''), PARAMS.get('mid', '')
    if name not in ('Watch Later', 'Favourites') or media not in ('movie', 'tvshow') or not mid.isdigit():
        return
    con = db()
    if add:
        con.execute('INSERT OR REPLACE INTO entries VALUES (?, ?, ?, ?)', (name, media, int(mid), PARAMS.get('title', 'Untitled')))
    else:
        con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?', (name, media, int(mid)))
    con.commit()
    con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'List updated', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def continue_watching():
    xbmcplugin.setContent(HANDLE, 'videos')
    def library_rows(method, result_key, media, properties):
        request = {'jsonrpc': '2.0', 'id': 11, 'method': method, 'params': {
            'properties': properties, 'limits': {'start': 0, 'end': 5000},
            'sort': {'method': 'lastplayed', 'order': 'descending'}}}
        try:
            result = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})
            return [(media, row) for row in result.get(result_key, []) if isinstance(row, dict)]
        except (ValueError, TypeError):
            return []

    library = library_rows('VideoLibrary.GetMovies', 'movies', 'movie', [
        'title', 'year', 'uniqueid', 'art', 'thumbnail', 'fanart', 'plot', 'runtime',
        'mpaa', 'resume', 'playcount', 'lastplayed', 'file'])
    library += library_rows('VideoLibrary.GetEpisodes', 'episodes', 'episode', [
        'title', 'year', 'uniqueid', 'art', 'thumbnail', 'fanart', 'plot', 'runtime',
        'resume', 'playcount', 'lastplayed', 'file', 'season', 'episode',
        'showtitle', 'tvshowid', 'firstaired'])
    for _media, show in library_rows('VideoLibrary.GetTVShows', 'tvshows', 'tvshow', [
            'title', 'year', 'uniqueid', 'art', 'thumbnail', 'fanart', 'plot', 'mpaa']):
        try:
            DISPLAY.cache[('tvshow', int(show.get('tvshowid') or 0))] = show
        except (TypeError, ValueError):
            pass

    con = db()
    try:
        dismissed_rows = con.execute(
            'SELECT media_type,kodi_id,file_path FROM dismissed_continue').fetchall()
        dismissed = {(r[0], r[1]) for r in dismissed_rows}
        dismissed_paths = {r[2] for r in dismissed_rows if r[2]}
    except sqlite3.OperationalError:
        dismissed = set()
        dismissed_paths = set()
    finally:
        con.close()

    resumable = []
    in_progress_shows = set()
    for media, row in library:
        resume = row.get('resume') or {}
        try:
            position, duration = float(resume.get('position') or 0), float(resume.get('total') or 0)
            mid = int(row.get('movieid' if media == 'movie' else 'episodeid') or 0)
        except (TypeError, ValueError):
            continue
        if (mid <= 0 or not row.get('file') or position < 30 or duration <= 0
                or position / duration >= .9 or int(row.get('playcount') or 0) > 0
                or (media, mid) in dismissed or row['file'] in dismissed_paths):
            continue
        resumable.append((str(row.get('lastplayed') or ''), media, mid, row, position, duration))
        if media == 'episode' and row.get('tvshowid') is not None:
            in_progress_shows.add(int(row['tvshowid']))

    # Kodi's library owns resume points and last-played timestamps. Sort by
    # Kodi's own lastplayed value and play the stored STRM path directly.
    for _lastplayed, media, mid, row, position, duration in sorted(resumable, reverse=True):
        metadata = {key: row[key] for key in (
            'title', 'year', 'uniqueid', 'art', 'thumbnail', 'fanart', 'plot',
            'runtime', 'season', 'episode', 'showtitle', 'tvshowid',
            'firstaired') if key in row}
        metadata['showtitle'] = metadata.get('showtitle') or ''
        DISPLAY.cache[(media, mid)] = metadata
        title = row.get('title') or metadata['showtitle'] or 'Continue Watching'
        li = DISPLAY.listitem(media, mid, title, (position, duration), path=row['file'])
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([('Remove from Continue Watching', 'RunPlugin(%s)' % url(
            action='remove_continue', media=media, mid=mid, file_path=row['file']))])
        xbmcplugin.addDirectoryItem(HANDLE, row['file'], li, False)

    # After a watched episode, show the next available unwatched episode for
    # that library show. Do not add it while another episode is in progress.
    episodes = [row for media, row in library if media == 'episode']
    by_show = {}
    for row in episodes:
        try:
            show_id = int(row.get('tvshowid') or 0)
            season, number = int(row.get('season') or 0), int(row.get('episode') or 0)
        except (TypeError, ValueError):
            continue
        if show_id > 0 and number > 0 and row.get('file'):
            by_show.setdefault(show_id, []).append((season, number, row))
    for show_id, entries in by_show.items():
        if show_id in in_progress_shows:
            continue
        watched = [(s, e, r) for s, e, r in entries if int(r.get('playcount') or 0) > 0]
        if not watched:
            continue
        watched.sort(key=lambda entry: (str(entry[2].get('lastplayed') or ''), entry[0], entry[1]))
        last_watched = watched[-1]
        unwatched = sorted((entry for entry in entries
                            if int(entry[2].get('playcount') or 0) == 0
                            and not (entry[2].get('resume') or {}).get('position')),
                           key=lambda entry: (entry[0], entry[1]))
        next_entry = next((entry for entry in unwatched
                           if (entry[0], entry[1]) > (last_watched[0], last_watched[1])), None)
        if next_entry is None:
            continue
        season, number, row = next_entry
        try:
            mid = int(row.get('episodeid') or 0)
        except (TypeError, ValueError):
            continue
        if mid <= 0 or ('episode', mid) in dismissed:
            continue
        metadata = {key: row[key] for key in (
            'title', 'year', 'uniqueid', 'art', 'thumbnail', 'fanart', 'plot',
            'runtime', 'season', 'episode', 'showtitle', 'tvshowid',
            'firstaired') if key in row}
        metadata['showtitle'] = metadata.get('showtitle') or ''
        DISPLAY.cache[('episode', mid)] = metadata
        li = DISPLAY.listitem('episode', mid, row.get('title') or 'Next episode',
                              path=row['file'])
        li.setProperty('IsPlayable', 'true')
        li.setProperty('UnifiedNextUnwatched', 'true')
        xbmcplugin.addDirectoryItem(HANDLE, row['file'], li, False)


def toggle_saved_progress():
    name, media, raw_mid = PARAMS.get('list', ''), PARAMS.get('media', ''), PARAMS.get('mid', '')
    if name not in ('Watch Later', 'Favourites') or media not in ('movie', 'episode'):
        return
    try:
        mid = int(raw_mid)
    except (TypeError, ValueError):
        return
    con = db()
    con.row_factory = sqlite3.Row
    try:
        row = con.execute('SELECT * FROM playback_progress WHERE media_type=? AND kodi_id=?',
                          (media, mid)).fetchone()
        exists = con.execute('SELECT 1 FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                             (name, media, mid)).fetchone()
        if row is None:
            if not exists:
                return
            con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                        (name, media, mid))
            con.execute('DELETE FROM external_list_items WHERE media_type=? AND kodi_id=? '
                        'AND NOT EXISTS (SELECT 1 FROM entries WHERE media_type=? AND kodi_id=?)',
                        (media, mid, media, mid))
            con.commit()
            xbmcgui.Dialog().notification('Unified Lists', 'Removed from ' + name,
                                          xbmcgui.NOTIFICATION_INFO, 2000)
            return
        if exists:
            con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                        (name, media, mid))
        else:
            metadata_json = row['source_metadata'] or '{}'
            try:
                metadata = json.loads(metadata_json)
            except (ValueError, TypeError):
                metadata = {}
            from umbrella_playback import build as umbrella_play_url
            play_path = umbrella_play_url(metadata, row['file_path'])
            con.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?)',
                        (name, media, mid, row['title']))
            con.execute('INSERT OR REPLACE INTO external_list_items '
                        '(media_type,kodi_id,path,is_folder,metadata_json) VALUES (?,?,?,?,?)',
                        (media, mid, play_path, 0, metadata_json))
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'List updated', xbmcgui.NOTIFICATION_INFO, 2000)


def _resume_playback(resolve_item):
    media, mid = PARAMS.get('media',''), PARAMS.get('mid','')
    if media not in ('movie','episode') or not mid.lstrip('-').isdigit():
        if resolve_item:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    mid = int(mid)
    con=db()
    row=con.execute('SELECT file_path,position,source_metadata FROM playback_progress WHERE media_type=? AND kodi_id=?',(media,mid)).fetchone()
    con.close()
    if not row:
        if resolve_item:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    path, position, metadata_json = row
    try:
        metadata = json.loads(metadata_json or '{}')
    except (ValueError, TypeError):
        metadata = {}
    from umbrella_playback import build as umbrella_play_url
    path = umbrella_play_url(metadata, path)
    umbrella_url = path
    if PARAMS.get('start')=='0':
        position=0
        import umbrella_local
        umbrella_local.clear_bookmark(media, metadata)
    from resume_control import queue, clear
    request_id = queue(DB_PATH, media, mid, float(position), path, metadata)
    try:
        # Launch Umbrella through a local STRM file. Kodi's STRM handler then
        # dispatches the plugin URL through its normal player path.
        from strm_playback import create as create_strm
        xbmc.Player().play(create_strm(media, mid, umbrella_url))
        if resolve_item:
            xbmcplugin.endOfDirectory(HANDLE)
    except Exception:
        clear(DB_PATH, request_id)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch movie', xbmcgui.NOTIFICATION_ERROR, 4000)
        if resolve_item:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def resume_playback():
    _resume_playback(True)


def resume_context_action():
    _resume_playback(False)


def remove_continue_item():
    media, raw_mid = PARAMS.get('media', ''), PARAMS.get('mid', '')
    if media not in ('movie', 'episode') or not raw_mid.lstrip('-').isdigit():
        return
    mid = int(raw_mid)
    con = db()
    try:
        con.execute('CREATE TABLE IF NOT EXISTS dismissed_continue '
                    "(media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, file_path TEXT NOT NULL DEFAULT '', "
                    'PRIMARY KEY(media_type,kodi_id))')
        columns = {column[1] for column in con.execute('PRAGMA table_info(dismissed_continue)')}
        if 'file_path' not in columns:
            con.execute("ALTER TABLE dismissed_continue ADD COLUMN file_path TEXT NOT NULL DEFAULT ''")
        con.execute('INSERT OR REPLACE INTO dismissed_continue '
                    '(media_type,kodi_id,file_path) VALUES (?,?,?)',
                    (media, mid, PARAMS.get('file_path', '')))
        con.execute('DELETE FROM playback_progress WHERE media_type=? AND kodi_id=?', (media, mid))
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'Removed from Continue Watching',
                                  xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def play_external_item():
    media, raw_mid = PARAMS.get('media', ''), PARAMS.get('mid', '')
    if media not in ('movie', 'episode'):
        return
    try:
        mid = int(raw_mid)
    except (TypeError, ValueError):
        return
    con = db()
    row = con.execute('SELECT x.path,x.metadata_json,p.position,p.completed FROM external_list_items x '
                      'LEFT JOIN playback_progress p ON p.media_type=x.media_type AND p.kodi_id=x.kodi_id '
                      'WHERE x.media_type=? AND x.kodi_id=?', (media, mid)).fetchone()
    con.close()
    if not row or not row[0]:
        return
    path, metadata_json, saved_position, completed = row
    try:
        metadata = json.loads(metadata_json or '{}')
    except (ValueError, TypeError):
        metadata = {}
    from umbrella_playback import build as umbrella_play_url
    path = umbrella_play_url(metadata, path)
    position = float(saved_position or 0) if saved_position is not None and not completed else 0.0
    if PARAMS.get('start') == '0':
        position = 0.0
        import umbrella_local
        umbrella_local.clear_bookmark(media, metadata)
    from resume_control import queue
    queue(DB_PATH, media, mid, position, path, metadata)
    from strm_playback import create as create_strm
    xbmc.Player().play(create_strm(media, mid, path))


def play_new_item():
    try:
        payload = json.loads(PARAMS.get('data', '{}'))
    except (ValueError, TypeError):
        return
    metadata = payload.get('metadata') if isinstance(payload, dict) else {}
    if not isinstance(metadata, dict):
        return
    from umbrella_playback import build as umbrella_play_url
    path = umbrella_play_url(metadata, payload.get('umbrella_path', ''))
    from identity import stable_identity
    mid, _identity = stable_identity('episode', metadata, path)
    from strm_playback import create as create_strm
    xbmc.Player().play(create_strm('episode', mid, path))


def save_metadata_item():
    name = PARAMS.get('list', '')
    if name not in ('Watch Later', 'Favourites'):
        return
    try:
        payload = json.loads(PARAMS.get('data', '{}'))
    except (ValueError, TypeError):
        return
    metadata = payload.get('metadata') if isinstance(payload, dict) else {}
    if not isinstance(metadata, dict):
        return
    from identity import stable_identity
    media, path = 'episode', payload.get('umbrella_path', '')
    mid, _identity = stable_identity(media, metadata, path)
    title = metadata.get('title') or metadata.get('tvshowtitle') or 'Untitled'
    con = db()
    con.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?)', (name, media, mid, title))
    con.execute('INSERT OR REPLACE INTO external_list_items '
                '(media_type,kodi_id,path,is_folder,metadata_json) VALUES (?,?,?,?,?)',
                (media, mid, path, 0, json.dumps(metadata, ensure_ascii=False)))
    con.commit()
    con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'Added to ' + name, xbmcgui.NOTIFICATION_INFO, 2000)

def main():
    action = PARAMS.get('action', '')
    if action in ('certificate_icons', 'certificate_restore'):
        from certificate_icons import run
        run(ADDON, restore=action == 'certificate_restore')
    elif action == 'settings':
        ADDON.openSettings()
    elif action == 'continue':
        continue_watching()
    elif action == 'resume':
        resume_playback()
        return
    elif action == 'resume_context':
        resume_context_action()
        return
    elif action == 'remove_continue':
        remove_continue_item()
    elif action == 'play_external':
        play_external_item()
    elif action == 'play_new':
        play_new_item()
    elif action == 'save_metadata':
        save_metadata_item()
    elif action == 'toggle_saved':
        toggle_saved_progress()
    elif action == 'unavailable':
        xbmcgui.Dialog().notification('Unified Lists', 'This saved entry needs its Umbrella item link again',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
    elif action == 'list':
        show_list(PARAMS.get('list', ''))
    elif action in ('add', 'remove'):
        change(action == 'add')
    elif action == 'details':
        xbmc.executebuiltin('Action(Info)')
    else:
        item('Settings', url(action='settings'), False)
        item('Continue Watching', url(action='continue'))
        item('Watch Later', url(action='list', list='Watch Later'))
        item('Favourites', url(action='list', list='Favourites'))
    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    main()
