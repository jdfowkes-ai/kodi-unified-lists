"""Four local actions for the currently selected Kodi video item."""
import hashlib
import json
import re
import sqlite3
import sys
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlsplit

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON = xbmcaddon.Addon()
PROFILE = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
DB_PATH = PROFILE / 'lists.db'
ACTION = sys.argv[1] if len(sys.argv) > 1 else ''


def safe_call(obj, name, default='', *args):
    try:
        value = getattr(obj, name)(*args)
        return value if value is not None else default
    except Exception:
        return default


def selected_item():
    item = getattr(sys, 'listitem', None)
    if item is None:
        return None
    path = safe_call(item, 'getPath')
    if not path:
        return None
    tag = safe_call(item, 'getVideoInfoTag', None)
    if tag is None:
        return None

    title = safe_call(tag, 'getTitle') or safe_call(item, 'getLabel') or 'Untitled'
    media = str(safe_call(tag, 'getMediaType') or '').lower()
    # Umbrella plugin directory entries do not always expose Kodi's dbtype.
    # Their URL still carries the metadata used by Umbrella's context actions.
    params = {}
    try:
        params = {key.lower(): values[-1] for key, values in
                  parse_qs(urlsplit(path).query).items() if values}
    except Exception:
        pass
    if media not in ('movie', 'episode', 'tvshow') and path.startswith('plugin://plugin.video.umbrella/'):
        if params.get('episode', '').isdigit() and int(params['episode']) > 0:
            media = 'episode'
        elif params.get('tvshowtitle'):
            media = 'tvshow'
        elif params.get('title') or params.get('name') or params.get('imdb') or params.get('tmdb'):
            media = 'movie'
    if media not in ('movie', 'episode', 'tvshow'):
        show = safe_call(tag, 'getTvShowTitle')
        episode = safe_call(tag, 'getEpisode', 0)
        if show or episode:
            media = 'episode'
        else:
            return None

    tmdb_id = safe_call(tag, 'getUniqueID', '', 'tmdb') or params.get('tmdb', '')
    tvdb_id = safe_call(tag, 'getUniqueID', '', 'tvdb') or params.get('tvdb', '')
    try:
        artwork = item.getArt() or {}
    except Exception:
        artwork = {}
    artwork = artwork if isinstance(artwork, dict) else {}
    metadata = {
        'title': title,
        'showtitle': safe_call(tag, 'getTvShowTitle') or params.get('tvshowtitle', ''),
        'year': safe_call(tag, 'getYear', 0) or params.get('year', 0),
        'season': safe_call(tag, 'getSeason', 0) or params.get('season', 0),
        'episode': safe_call(tag, 'getEpisode', 0) or params.get('episode', 0),
        'plot': safe_call(tag, 'getPlot'),
        'thumbnail': artwork.get('thumb') or artwork.get('poster') or '',
        'art': artwork,
        'fanart': artwork.get('fanart') or artwork.get('landscape') or '',
        'uniqueid': {key: str(value) for key, value in (
                        ('tmdb', tmdb_id), ('tvdb', tvdb_id),
                        ('imdb', safe_call(tag, 'getIMDBNumber') or params.get('imdb', '')))
                     if str(value).isdigit() or (key == 'imdb' and bool(value))},
    }
    try:
        is_playable = item.getProperty('IsPlayable').lower() == 'true'
    except Exception:
        is_playable = False
    is_folder = media == 'tvshow' and not is_playable
    if media == 'episode':
        show = metadata['showtitle']
        show_key = (str(tvdb_id) if str(tvdb_id).isdigit() else
                    str(tmdb_id) if str(tmdb_id).isdigit() else
                    re.sub(r'[^a-z0-9]+', '', show.casefold()))
        if metadata['season'] and metadata['episode'] and show_key:
            identity = 'episode:%s:%s:%s' % (show_key, metadata['season'], metadata['episode'])
        else:
            identity = 'episode:%s:%s:%s:%s' % (
                show_key, metadata['season'], metadata['episode'],
                re.sub(r'[^a-z0-9]+', '', title.casefold()) or path)
    else:
        identity = ('movie:tmdb:' + str(tmdb_id) if str(tmdb_id).isdigit() else
                    'movie:%s:%s' % (re.sub(r'[^a-z0-9]+', '', title.casefold()), metadata['year']))
    digest = int(hashlib.sha256(identity.encode('utf-8')).hexdigest()[:15], 16)
    metadata['local_identity'] = identity
    return item, media, -(digest or 1), title, path, is_folder, metadata


def ensure_schema(con):
    con.execute('CREATE TABLE IF NOT EXISTS entries (list_name TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, PRIMARY KEY (list_name, media_type, kodi_id))')
    con.execute('CREATE TABLE IF NOT EXISTS external_list_items (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, path TEXT NOT NULL, is_folder INTEGER NOT NULL DEFAULT 0, metadata_json TEXT NOT NULL DEFAULT \'{}\', PRIMARY KEY(media_type,kodi_id))')


def toggle_list(list_name):
    selected = selected_item()
    if selected is None:
        xbmcgui.Dialog().notification('Unified Lists', 'This item has no playable Kodi path', xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    _item, media, mid, title, path, is_folder, metadata = selected
    PROFILE.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), timeout=10)
    try:
        ensure_schema(con)
        existing = con.execute('SELECT 1 FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                               (list_name, media, mid)).fetchone()
        if existing:
            con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                        (list_name, media, mid))
            con.execute('DELETE FROM external_list_items WHERE media_type=? AND kodi_id=? '
                        'AND NOT EXISTS (SELECT 1 FROM entries WHERE media_type=? AND kodi_id=?)',
                        (media, mid, media, mid))
            message = 'Removed from ' + list_name
        else:
            con.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?)',
                        (list_name, media, mid, title))
            con.execute('INSERT OR REPLACE INTO external_list_items VALUES (?,?,?,?,?)',
                        (media, mid, path, int(is_folder), json.dumps(metadata, ensure_ascii=False)))
            message = 'Added to ' + list_name
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', message, xbmcgui.NOTIFICATION_INFO, 2500)


def play_resume():
    selected = selected_item()
    if selected is None:
        return
    item, _media, _mid, _title, path, is_folder, _metadata = selected
    if is_folder:
        xbmc.executebuiltin('Container.Update("%s")' % path.replace('"', '\\"'))
        return
    con = sqlite3.connect(str(DB_PATH), timeout=10)
    try:
        row = con.execute('SELECT position FROM playback_progress WHERE media_type=? AND kodi_id=? '
                          'AND completed=0 AND position>=30', (_media, _mid)).fetchone()
    finally:
        con.close()
    from resume_control import queue
    queue(DB_PATH, _media, _mid, float(row[0]) if row else 0.0, path, _metadata)
    xbmc.Player().play(path, item)


def show_actions():
    selected = selected_item()
    if selected is None:
        return
    _item, media, mid, _title, path, is_folder, metadata = selected
    if is_folder:
        labels = ['Add to Watch Later', 'Add to Favourites', 'Add to Kodi Library']
        selected_action = xbmcgui.Dialog().select('Unified Lists', labels)
        if selected_action == 0:
            toggle_list('Watch Later')
        elif selected_action == 1:
            toggle_list('Favourites')
        elif selected_action == 2:
            add_to_kodi_library(media, metadata, _title)
        return
    PROFILE.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), timeout=10)
    try:
        ensure_schema(con)
        row = con.execute('SELECT position FROM playback_progress WHERE media_type=? AND kodi_id=? '
                          'AND completed=0 AND position>=30', (media, mid)).fetchone()
    finally:
        con.close()
    labels = (['Resume', 'Play from Beginning'] if row else ['Play']) + [
        'Info', 'Add to Watch Later', 'Add to Favourites', 'Add to Kodi Library']
    selected_action = xbmcgui.Dialog().select('Unified Lists', labels)
    if selected_action < 0:
        return
    if selected_action == 0:
        play(path, media, mid, float(row[0]) if row else 0.0, metadata)
    elif row and selected_action == 1:
        clear_bookmark(metadata)
        play(path, media, mid, 0.0, metadata)
    elif selected_action == (2 if row else 1):
        xbmc.executebuiltin('Action(Info)')
    elif selected_action == (3 if row else 2):
        toggle_list('Watch Later')
    elif selected_action == (4 if row else 3):
        toggle_list('Favourites')
    elif selected_action == (5 if row else 4):
        add_to_kodi_library(media, metadata, _title)


def add_to_kodi_library(media, metadata, label):
    """Delegate STRM creation to Umbrella's own library manager."""
    ids = metadata.get('uniqueid') or {}
    ids = ids if isinstance(ids, dict) else {}
    if media in ('tvshow', 'episode'):
        params = {
            'action': 'library_tvshowToLibrary',
            'tvshowtitle': metadata.get('showtitle') or metadata.get('title') or label,
            'year': metadata.get('year') or '',
            'imdb': ids.get('imdb') or '',
            'tmdb': ids.get('tmdb') or '',
            'tvdb': ids.get('tvdb') or '',
        }
    elif media == 'movie':
        params = {
            'action': 'library_movieToLibrary',
            'name': label,
            'title': metadata.get('title') or label,
            'year': metadata.get('year') or '',
            'imdb': ids.get('imdb') or '',
            'tmdb': ids.get('tmdb') or '',
        }
    else:
        return
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?%s)' % urlencode(params))


def play(path, media, mid, position, metadata=None):
    from resume_control import queue
    queue(DB_PATH, media, mid, float(position), path, metadata)
    xbmc.Player().play(path)


def clear_bookmark(metadata):
    try:
        import umbrella_local
        umbrella_local.clear_bookmark('episode' if metadata.get('showtitle') else 'movie', metadata)
    except Exception as exc:
        xbmc.log('Unified Lists could not clear Umbrella bookmark: ' + str(exc), xbmc.LOGDEBUG)


def main():
    if not ACTION:
        show_actions()
    elif ACTION == 'play_resume':
        play_resume()
    elif ACTION == 'info':
        xbmc.executebuiltin('Action(Info)')
    elif ACTION == 'watch_later':
        toggle_list('Watch Later')
    elif ACTION == 'favourites':
        toggle_list('Favourites')


if __name__ == '__main__':
    main()
