import json
import sqlite3
from pathlib import Path
import xbmc
import xbmcaddon
import xbmcvfs

PROFILE = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')))
DB = PROFILE / 'lists.db'

def rpc(method, params=None):
    req = {'jsonrpc':'2.0','id':1,'method':method}
    if params is not None: req['params'] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(req))).get('result',{})

def identify():
    active = rpc('Player.GetActivePlayers')
    player = next((p for p in active if p.get('type')=='video'),None)
    if not player: return None
    obj = rpc('Player.GetItem',{'playerid':player['playerid'],'properties':['file','title','showtitle']}).get('item',{})
    media, mid, path = obj.get('type'),obj.get('id'),obj.get('file')
    if media not in ('movie','episode') or not isinstance(mid,int) or not path: return None
    return (media,mid,obj.get('title') or obj.get('label') or 'Untitled',path)

def connect():
    PROFILE.mkdir(parents=True,exist_ok=True)
    con = sqlite3.connect(str(DB),timeout=10)
    con.execute('CREATE TABLE IF NOT EXISTS playback_progress (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL, completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(media_type,kodi_id))')
    con.commit()
    return con

class Tracker(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.reset()
    def reset(self):
        self.item=None
        self.first=None
        self.position=None
        self.duration=0
        self.last_saved=None
    def onAVStarted(self):
        self.reset()
    def onPlayBackStopped(self):
        self.save()
        self.reset()
    def onPlayBackEnded(self):
        self.save(ended=True)
        self.reset()
    def save(self,ended=False):
        if self.item is None or self.position is None: return
        media,mid,title,path=self.item
        complete=bool(ended or (self.duration>0 and self.position/self.duration>=.9))
        if not complete and (self.first is None or self.position-self.first<30): return
        try:
            con=connect()
            con.execute('INSERT INTO playback_progress (media_type,kodi_id,title,file_path,position,duration,completed,updated_at) VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(media_type,kodi_id) DO UPDATE SET title=excluded.title,file_path=excluded.file_path,position=excluded.position,duration=excluded.duration,completed=excluded.completed,updated_at=CURRENT_TIMESTAMP',(media,mid,title,path,self.position,self.duration,int(complete)))
            if complete and media=='movie':
                con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',('Start Watching',media,mid))
            con.commit();con.close()
            self.last_saved=self.position
        except Exception as exc:
            xbmc.log('Unified Lists database error: '+str(exc),xbmc.LOGERROR)
    def tick(self):
        if not self.isPlayingVideo(): return
        if self.item is None:
            self.item=identify()
            if self.item is None: return
        try:
            pos=float(self.getTime())
            duration=float(self.getTotalTime())
        except Exception: return
        if self.first is None: self.first=pos
        self.position=pos
        self.duration=duration
        if self.last_saved is None or pos-self.last_saved>=10: self.save()

monitor=xbmc.Monitor()
tracker=Tracker()
while not monitor.abortRequested():
    try: tracker.tick()
    except Exception as exc: xbmc.log('Unified Lists tracking: '+str(exc),xbmc.LOGERROR)
    monitor.waitForAbort(1)
