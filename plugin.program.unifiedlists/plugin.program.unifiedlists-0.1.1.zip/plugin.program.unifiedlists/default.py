import sys
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlencode, parse_qs
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PARAMS = {k: v[0] for k, v in parse_qs(sys.argv[2][1:]).items()}
DB_PATH = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))) / 'lists.db'
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


def db():
    con = sqlite3.connect(str(DB_PATH))
    con.execute('CREATE TABLE IF NOT EXISTS entries (list_name TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, PRIMARY KEY (list_name, media_type, kodi_id))')
    con.commit()
    return con


def url(**kwargs):
    return BASE + '?' + urlencode(kwargs)


def item(label, target, folder=True, menu=None):
    li = xbmcgui.ListItem(label=label)
    if menu:
        li.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, target, li, folder)


def library(media):
    method = 'VideoLibrary.GetMovies' if media == 'movie' else 'VideoLibrary.GetTVShows'
    key = 'movies' if media == 'movie' else 'tvshows'
    id_key = 'movieid' if media == 'movie' else 'tvshowid'
    import json
    request = {'jsonrpc': '2.0', 'method': method, 'params': {'properties': ['title'], 'sort': {'method': 'title'}}, 'id': 1}
    result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    for entry in result.get('result', {}).get(key, []):
        mid = entry[id_key]
        title = entry.get('title', str(mid))
        menu = [(f'Add to {name}', 'RunPlugin(' + url(action='add', list=name, media=media, mid=mid, title=title) + ')') for name in ('Start Watching', 'Watch Later', 'Favourites')]
        item(title, url(action='play' if media == 'movie' else 'details', media=media, mid=mid), False, menu)


def show_list(name):
    con = db()
    for media, mid, title in con.execute('SELECT media_type, kodi_id, title FROM entries WHERE list_name=? ORDER BY title', (name,)):
        menu = [('Remove from list', 'RunPlugin(' + url(action='remove', list=name, media=media, mid=mid) + ')')]
        item(title, url(action='play' if media == 'movie' else 'details', media=media, mid=mid), False, menu)
    con.close()


def change(add):
    name, media, mid = PARAMS.get('list', ''), PARAMS.get('media', ''), PARAMS.get('mid', '')
    if name not in ('Start Watching', 'Watch Later', 'Favourites') or media not in ('movie', 'tvshow') or not mid.isdigit():
        return
    con = db()
    if add:
        con.execute('INSERT OR REPLACE INTO entries VALUES (?, ?, ?, ?)', (name, media, int(mid), PARAMS.get('title', 'Untitled')))
    else:
        con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?', (name, media, int(mid)))
    con.commit()
    con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'List updated', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def play_library_movie(mid):
    """Play the actual Kodi library file, rather than navigating to its folder."""
    request = {
        'jsonrpc': '2.0', 'id': 1,
        'method': 'VideoLibrary.GetMovieDetails',
        'params': {'movieid': int(mid), 'properties': ['file', 'title']}
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        details = response.get('result', {}).get('moviedetails', {})
        path = details.get('file', '')
        if not path:
            raise ValueError('Movie has no playable library file')
        xbmc.Player().play(path)
    except Exception as exc:
        xbmc.log('Unified Lists: unable to play library movie: ' + str(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch movie', xbmcgui.NOTIFICATION_ERROR, 4000)


def main():
    action = PARAMS.get('action', '')
    if action == 'library':
        library(PARAMS.get('media', 'movie'))
    elif action == 'list':
        show_list(PARAMS.get('list', ''))
    elif action in ('add', 'remove'):
        change(action == 'add')
    elif action == 'play':
        mid = PARAMS.get('mid', '')
        if PARAMS.get('media') == 'movie' and mid.isdigit():
            play_library_movie(mid)
    elif action == 'details':
        media, mid = PARAMS.get('media', ''), PARAMS.get('mid', '')
        if mid.isdigit() and media in ('movie', 'tvshow'):
            xbmc.executebuiltin('ActivateWindow(Videos,videodb://' + ('movies/titles/' if media == 'movie' else 'tvshows/titles/') + str(mid) + ',return)')
    else:
        item('Start Watching', url(action='list', list='Start Watching'))
        item('Watch Later', url(action='list', list='Watch Later'))
        item('Favourites', url(action='list', list='Favourites'))
        item('Browse Kodi Movies', url(action='library', media='movie'))
        item('Browse Kodi TV Shows', url(action='library', media='tvshow'))
    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    main()
