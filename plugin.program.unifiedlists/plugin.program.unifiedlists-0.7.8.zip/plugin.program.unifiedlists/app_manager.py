"""Local app catalogue, management actions and per-app Kodi directories."""
import hashlib
import json
import os
import re
import sqlite3
import time
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin


PACKAGE_RE = re.compile(r'^[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+$')
APP_ID_RE = re.compile(r'[^a-z0-9-]+')


def _connect(db_path):
    con = sqlite3.connect(str(db_path), timeout=10)
    con.execute("""CREATE TABLE IF NOT EXISTS app_entries (
        app_id TEXT PRIMARY KEY,
        label TEXT NOT NULL,
        package TEXT NOT NULL,
        provider_names TEXT NOT NULL DEFAULT '',
        enabled INTEGER NOT NULL DEFAULT 1,
        last_used REAL NOT NULL DEFAULT 0,
        sort_order INTEGER NOT NULL DEFAULT 0,
        is_builtin INTEGER NOT NULL DEFAULT 0,
        spotlight_source TEXT NOT NULL DEFAULT ''
    )""")
    columns = {row[1] for row in con.execute('PRAGMA table_info(app_entries)')}
    if 'spotlight_source' not in columns:
        con.execute("ALTER TABLE app_entries ADD COLUMN spotlight_source TEXT NOT NULL DEFAULT ''")
    con.commit()
    return con


def _defaults(addon_root):
    path = os.path.join(addon_root, 'resources', 'apps.json')
    try:
        with open(path, 'r', encoding='utf-8') as source:
            value = json.load(source)
        return [app for app in value if isinstance(app, dict) and app.get('id')
                and app.get('label') and app.get('package')]
    except (OSError, ValueError, TypeError):
        return []


def ensure(db_path, addon_root):
    """Seed bundled shortcuts once; preserve all existing app state thereafter."""
    con = _connect(db_path)
    try:
        for index, app in enumerate(_defaults(addon_root)):
            names = app.get('provider_names') or [app['label']]
            if isinstance(names, str):
                names = [names]
            con.execute('INSERT OR IGNORE INTO app_entries '
                        '(app_id,label,package,provider_names,enabled,sort_order,is_builtin) '
                        'VALUES (?,?,?,?,1,?,1)',
                        (str(app['id']), str(app['label']), str(app['package']),
                         '|'.join(str(name) for name in names), index))
        con.commit()
    finally:
        con.close()


def list_apps(db_path, addon_root, query=''):
    ensure(db_path, addon_root)
    con = _connect(db_path)
    try:
        rows = con.execute('SELECT app_id,label,package,provider_names,last_used,sort_order,is_builtin,spotlight_source '
                           'FROM app_entries WHERE enabled=1').fetchall()
    finally:
        con.close()
    query = str(query or '').strip().casefold()
    if query:
        rows = [row for row in rows if query in str(row[1]).casefold()]
    # Recently launched apps appear first. Unused apps retain their original order.
    rows.sort(key=lambda row: (-float(row[4] or 0), int(row[5] or 0), str(row[1]).casefold()))
    return [{
        'id': str(row[0]), 'label': str(row[1]), 'package': str(row[2]),
        'provider_names': [part for part in str(row[3] or '').split('|') if part],
        'last_used': float(row[4] or 0), 'sort_order': int(row[5] or 0),
        'is_builtin': bool(row[6]), 'spotlight_source': str(row[7] or ''),
    } for row in rows]


def _slug(label, package):
    value = APP_ID_RE.sub('-', str(label or '').strip().lower()).strip('-') or 'app'
    return '%s-%s' % (value[:42], re.sub(r'[^a-z0-9]', '', package.lower())[-10:])


def add_custom(db_path, addon_root, label, package, provider_name=''):
    label = str(label or '').strip()
    package = str(package or '').strip()
    if not label or not PACKAGE_RE.fullmatch(package):
        return False, 'Enter an app name and a valid Android package ID.'
    names = [part.strip() for part in str(provider_name or label).split('|') if part.strip()]
    app_id = _slug(label, package)
    ensure(db_path, addon_root)
    con = _connect(db_path)
    try:
        duplicate = con.execute('SELECT app_id FROM app_entries WHERE package=?', (package,)).fetchone()
        if duplicate:
            con.execute('UPDATE app_entries SET enabled=1 WHERE app_id=?', (duplicate[0],))
            con.commit()
            return True, 'That app is already in the list; it has been restored.'
        con.execute('INSERT INTO app_entries '
                    '(app_id,label,package,provider_names,enabled,last_used,sort_order,is_builtin) '
                    'VALUES (?,?,?,?,1,0,999,0)',
                    (app_id, label, package, '|'.join(names)))
        con.commit()
        return True, 'App added.'
    except sqlite3.IntegrityError:
        return False, 'An app with that name is already in the list.'
    finally:
        con.close()


def remove_app(db_path, addon_root, app_id):
    ensure(db_path, addon_root)
    con = _connect(db_path)
    try:
        con.execute('UPDATE app_entries SET enabled=0 WHERE app_id=?', (str(app_id),))
        con.commit()
    finally:
        con.close()


def restore_builtins(db_path, addon_root):
    ensure(db_path, addon_root)
    con = _connect(db_path)
    try:
        con.execute('UPDATE app_entries SET enabled=1 WHERE is_builtin=1')
        con.commit()
    finally:
        con.close()


def mark_used(db_path, app_id):
    con = _connect(db_path)
    try:
        con.execute('UPDATE app_entries SET last_used=? WHERE app_id=? AND enabled=1',
                    (time.time(), str(app_id)))
        con.commit()
    finally:
        con.close()


def _url(base, **params):
    return base + '?' + urlencode(params)


def _art(addon_root, app_id, filename, fallback):
    candidate = os.path.join(addon_root, 'resources', 'app_art', str(app_id), filename)
    return candidate if os.path.isfile(candidate) else fallback


def render_apps(handle, base, db_path, addon_root, query=''):
    apps = list_apps(db_path, addon_root, query)
    xbmcplugin.setPluginCategory(handle, 'Apps' + ((' · ' + query) if query else ''))
    xbmcplugin.setContent(handle, 'files')
    fallback = os.path.join(addon_root, 'resources', 'icons', 'navigation',
                            'colour-icon-only', 'apps.png')
    for app in apps:
        icon = _art(addon_root, app['id'], 'icon-v121.png', fallback)
        landscape = _art(addon_root, app['id'], 'landscape-v121.png', icon)
        fanart = _art(addon_root, app['id'], 'fanart-clean-v120.jpg', '')
        li = xbmcgui.ListItem(label=app['label'])
        li.setArt({'icon': icon, 'thumb': landscape, 'poster': icon,
                   'landscape': landscape, 'fanart': fanart})
        li.setProperty('IsPlayable', 'false')
        # Arctic Fuse reads this on focus to show this app's selected video
        # add-on source in its large Home spotlight. Keep the item's launch URL below
        # unchanged so OK still opens the Android app.
        if app.get('spotlight_source'):
            li.setProperty('app_spotlight_path', str(app['spotlight_source']).strip())
            li.setProperty('app_spotlight_label', app['label'])
            source_token = hashlib.sha1(str(app['spotlight_source']).encode('utf-8')).hexdigest()[:12]
            li.setProperty('app_spotlight_reload', source_token)
        li.addContextMenuItems([
            ('Choose %s spotlight source' % app['label'], 'ActivateWindow(Videos,%s)' % _url(base, action='choose_spotlight_source', app=app['id'])),
            ('Preview %s spotlight' % app['label'], 'ActivateWindow(Videos,%s)' % _url(base, action='app_spotlight', app=app['id'])),
            ('Remove app', 'RunPlugin(%s)' % _url(base, action='remove_app', app=app['id'])),
        ])
        xbmcplugin.addDirectoryItem(
            handle, _url(base, action='launch_app', app=app['id']), li, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _management_item(handle, base, label, action, art, folder=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': art, 'thumb': art, 'poster': art})
    xbmcplugin.addDirectoryItem(handle, _url(base, action=action), li, folder)


def render_management(handle, base, addon_root):
    art_root = os.path.join(addon_root, 'resources', 'icons', 'navigation', 'colour-icon-only')
    xbmcplugin.setPluginCategory(handle, 'Manage Apps')
    xbmcplugin.setContent(handle, 'files')
    _management_item(handle, base, 'Add app', 'add_app', os.path.join(art_root, 'apps.png'))
    _management_item(handle, base, 'Remove app', 'choose_remove_app', os.path.join(art_root, 'power.png'))
    _management_item(handle, base, 'Restore built-in apps', 'restore_apps', os.path.join(art_root, 'library.png'))
    _management_item(handle, base, 'Filter apps', 'filter_apps', os.path.join(art_root, 'search.png'))
    _management_item(handle, base, 'Choose spotlight source', 'choose_spotlight_source', os.path.join(art_root, 'new-releases.png'), folder=True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def render_spotlights(handle, base, db_path, addon_root):
    apps = list_apps(db_path, addon_root)
    fallback = os.path.join(addon_root, 'resources', 'icons', 'navigation',
                            'colour-icon-only', 'apps.png')
    xbmcplugin.setPluginCategory(handle, 'App Spotlights')
    xbmcplugin.setContent(handle, 'files')
    for app in apps:
        icon = _art(addon_root, app['id'], 'icon-v121.png', fallback)
        landscape = _art(addon_root, app['id'], 'landscape-v121.png', icon)
        li = xbmcgui.ListItem(label=app['label'])
        li.setArt({'icon': icon, 'thumb': landscape, 'poster': icon, 'landscape': landscape})
        li.addContextMenuItems([
            ('Launch %s' % app['label'], 'RunPlugin(%s)' % _url(base, action='launch_app', app=app['id'])),
        ])
        xbmcplugin.addDirectoryItem(
            handle, _url(base, action='app_spotlight', app=app['id']), li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def set_spotlight_source(db_path, addon_root, app_id, source):
    ensure(db_path, addon_root)
    con = _connect(db_path)
    try:
        con.execute('UPDATE app_entries SET spotlight_source=? WHERE app_id=?',
                    (str(source or ''), str(app_id)))
        con.commit()
    finally:
        con.close()


def render_source_apps(handle, base, db_path, addon_root):
    apps = list_apps(db_path, addon_root)
    xbmcplugin.setPluginCategory(handle, 'Choose app for spotlight source')
    xbmcplugin.setContent(handle, 'files')
    for app in apps:
        li = xbmcgui.ListItem(label=app['label'])
        li.setProperty('IsFolder', 'true')
        xbmcplugin.addDirectoryItem(
            handle, _url(base, action='choose_spotlight_source', app=app['id']), li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def render_source_addons(handle, base, db_path, addon_root, app_id):
    """Open the installed video add-on picker for a specific app."""
    import app_spotlight
    apps = list_apps(db_path, addon_root)
    app = next((entry for entry in apps if entry['id'] == str(app_id)), None)
    if app:
        app_spotlight.render_addon_picker(handle, base, app)
    else:
        xbmcgui.Dialog().notification('Spotlight source', 'App is not in the active app list.',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)


def render_source_browser(addon, handle, base, db_path, addon_root, app_id, path):
    """Open a video add-on folder browser for a specific active app."""
    import app_spotlight
    apps = list_apps(db_path, addon_root)
    app = next((entry for entry in apps if entry['id'] == str(app_id)), None)
    if app:
        app_spotlight.render_source_picker(addon, handle, base, app, path)
    else:
        xbmcgui.Dialog().notification('Spotlight source', 'App is not in the active app list.',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)


def launch(db_path, addon_root, app_id):
    apps = list_apps(db_path, addon_root)
    app = next((item for item in apps if item['id'] == str(app_id)), None)
    if not app:
        xbmcgui.Dialog().notification('Unified Lists', 'App is not in the active app list.',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    if not xbmc.getCondVisibility('System.Platform.Android'):
        xbmcgui.Dialog().ok('Unified Lists', 'App shortcuts need Kodi on Android TV or NVIDIA Shield.')
        return
    if not PACKAGE_RE.fullmatch(app['package']):
        xbmcgui.Dialog().ok('Unified Lists', 'Invalid Android package ID for this app.')
        return
    # Kodi cannot report whether the Android activity opened successfully, so
    # this timestamp records the user's most recent launch request.
    mark_used(db_path, app['id'])
    xbmc.executebuiltin('StartAndroidActivity(%s)' % app['package'])


def run_action(addon, db_path, addon_root, base, params):
    action = params.get('action', '')
    if action == 'launch_app':
        launch(db_path, addon_root, params.get('app', ''))
    elif action == 'add_app':
        dialog = xbmcgui.Dialog()
        label = dialog.input('App name', '', xbmcgui.INPUT_ALPHANUM)
        if not label:
            return
        package = dialog.input('Android package ID', '', xbmcgui.INPUT_ALPHANUM)
        if not package:
            return
        ok, message = add_custom(db_path, addon_root, label, package)
        dialog.notification('Unified Lists', message,
                            xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'choose_remove_app':
        apps = list_apps(db_path, addon_root)
        if not apps:
            xbmcgui.Dialog().notification('Unified Lists', 'There are no active apps to remove.')
            return
        labels = [app['label'] for app in apps]
        choice = xbmcgui.Dialog().select('Remove app', labels)
        if choice < 0:
            return
        app = apps[choice]
        if xbmcgui.Dialog().yesno('Remove app', 'Remove %s from the app list?' % app['label']):
            remove_app(db_path, addon_root, app['id'])
            xbmcgui.Dialog().notification('Unified Lists', 'App removed; you can add it again.')
            xbmc.executebuiltin('Container.Refresh')
    elif action == 'remove_app':
        app_id = params.get('app', '')
        app = next((app for app in list_apps(db_path, addon_root) if app['id'] == app_id), None)
        if app and xbmcgui.Dialog().yesno('Remove app', 'Remove %s from the app list?' % app['label']):
            remove_app(db_path, addon_root, app_id)
            xbmc.executebuiltin('Container.Refresh')
    elif action == 'restore_apps':
        restore_builtins(db_path, addon_root)
        xbmcgui.Dialog().notification('Unified Lists', 'Built-in apps restored.')
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'filter_apps':
        current = params.get('filter', '')
        query = xbmcgui.Dialog().input('Filter apps by name', current,
                                       xbmcgui.INPUT_ALPHANUM)
        target = _url(base, action='apps', filter=query.strip())
        xbmc.executebuiltin('Container.Update(%s)' % target)
    elif action == 'apps':
        render_apps(int(__import__('sys').argv[1]), base, db_path, addon_root,
                    params.get('filter', ''))
    elif action == 'manage_apps':
        render_management(int(__import__('sys').argv[1]), base, addon_root)
    elif action == 'choose_spotlight_source':
        handle = int(__import__('sys').argv[1])
        app_id = params.get('app', '')
        if app_id:
            render_source_addons(handle, base, db_path, addon_root, app_id)
        else:
            render_source_apps(handle, base, db_path, addon_root)
    elif action == 'spotlight_source_browser':
        render_source_browser(addon, int(__import__('sys').argv[1]), base, db_path,
                              addon_root, params.get('app', ''), params.get('path', ''))
    elif action == 'set_spotlight_source':
        import app_spotlight
        apps = list_apps(db_path, addon_root)
        app = next((entry for entry in apps if entry['id'] == params.get('app', '')), None)
        if app:
            set_spotlight_source(db_path, addon_root, app['id'], params.get('path', ''))
            xbmcgui.Dialog().notification('Unified Lists', 'Spotlight source saved for %s.' % app['label'], xbmcgui.NOTIFICATION_INFO, 3000)
            xbmc.executebuiltin('Container.Refresh')
    elif action == 'app_spotlights':
        render_spotlights(int(__import__('sys').argv[1]), base, db_path, addon_root)
