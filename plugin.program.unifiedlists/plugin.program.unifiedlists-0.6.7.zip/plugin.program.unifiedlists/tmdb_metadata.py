"""Optional TMDb artwork and GB certification lookup for Kodi library items."""
import json
import os
import re
import time
from datetime import date
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmcaddon
import xbmcvfs


class TMDbMetadata:
    CACHE_TTL = 30 * 24 * 60 * 60
    IMAGE_BASE = 'https://image.tmdb.org/t/p/'

    def __init__(self, addon=None, opener=None, now=None):
        self.addon = addon or xbmcaddon.Addon()
        self.opener = opener or urlopen
        self.now = now or time.time
        profile = Path(xbmcvfs.translatePath(self.addon.getAddonInfo('profile')))
        profile.mkdir(parents=True, exist_ok=True)
        self.cache_path = profile / 'tmdb_metadata.json'
        self.cache = self._load_cache()

    def _load_cache(self):
        try:
            with self.cache_path.open('r', encoding='utf-8') as source:
                data = json.load(source)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    def _save_cache(self):
        temp = self.cache_path.with_name(self.cache_path.name + '.tmp')
        try:
            with temp.open('w', encoding='utf-8') as output:
                json.dump(self.cache, output, ensure_ascii=False)
                output.flush()
                os.fsync(output.fileno())
            os.replace(str(temp), str(self.cache_path))
        finally:
            if temp.exists():
                temp.unlink()

    @staticmethod
    def tmdb_id(uniqueid):
        if isinstance(uniqueid, dict):
            value = uniqueid.get('tmdb') or uniqueid.get('themoviedb')
        else:
            value = uniqueid
        value = str(value or '').strip()
        return value if value.isdigit() else ''

    @staticmethod
    def clean_movie_title(value, year=None):
        """Remove release filename tags so movie filenames can be searched."""
        title = str(value or '').strip()
        title = re.sub(r'\.[^.]+$', '', title)
        marker = re.search(
            r'(?i)[._\s]+((?:19|20)\d{2})(?=[._\s]+(?:2160p|1080p|720p|480p|blu.?ray|web|hdr|remux|multi))',
            title)
        if marker:
            year = year or int(marker.group(1))
            title = title[:marker.start()]
        title = re.split(
            r'(?i)[._\s]+(?:2160p|1080p|720p|480p|blu.?ray|web.?dl|web.?rip|remux|hdr|multi)\b',
            title, maxsplit=1)[0]
        title = re.sub(r'[._]+', ' ', title)
        return title.strip(' [](){}-'), year

    def _request(self, endpoint, api_key, extra_params=None):
        params = {'api_key': api_key, 'language': 'en-GB'}
        params.update(extra_params or {})
        url = 'https://api.themoviedb.org/3/%s?%s' % (
            endpoint.lstrip('/'), urlencode(params))
        request = Request(url, headers={'Accept': 'application/json', 'User-Agent': 'UnifiedLocalListManager/0.3.2'})
        with self.opener(request, timeout=4) as response:
            raw = response.read(1024 * 1024)
        data = json.loads(raw.decode('utf-8'))
        return data if isinstance(data, dict) else {}

    @staticmethod
    def _gb_certification(media, response):
        if media == 'movie':
            regions = response.get('results', [])
            gb = next((region for region in regions if region.get('iso_3166_1') == 'GB'), {})
            releases = [item for item in gb.get('release_dates', []) if item.get('certification')]
            priority = {3: 0, 4: 1, 5: 2, 6: 3, 2: 4, 1: 5}
            releases.sort(key=lambda item: (priority.get(item.get('type'), 9), item.get('release_date', '')))
            return next((item.get('certification', '').strip() for item in releases
                         if item.get('certification', '').strip()), '')
        ratings = response.get('results', [])
        gb = next((item for item in ratings if item.get('iso_3166_1') == 'GB'), {})
        return (gb.get('rating') or '').strip()

    def lookup(self, media, uniqueid, need_art=False, need_cert=True, title='', year=None):
        """Return TMDb metadata, resolving a missing TMDb ID from title/year."""
        api_key = (self.addon.getSetting('tmdb_api_key') or '').strip()
        if not api_key or media not in ('movie', 'tv'):
            return {}

        tmdb = self.tmdb_id(uniqueid)
        if media == 'movie':
            title, year = self.clean_movie_title(title, year)
        if not tmdb and title:
            alias = 'search:%s:%s:%s' % (media, title.strip().casefold(), year or '')
            alias_row = self.cache.get(alias, {})
            alias_fresh = isinstance(alias_row, dict) and self.now() - alias_row.get('fetched_at', 0) < self.CACHE_TTL
            tmdb = str(alias_row.get('tmdb_id', '')) if alias_fresh else ''
            if not tmdb:
                params = {'query': title}
                if year:
                    params['year' if media == 'movie' else 'first_air_date_year'] = int(year)
                search = self._request('search/%s' % media, api_key, params)
                candidates = search.get('results', [])
                if year and candidates:
                    date_key = 'release_date' if media == 'movie' else 'first_air_date'
                    exact = [entry for entry in candidates if str(entry.get(date_key, '')).startswith(str(year))]
                    if exact:
                        candidates = exact
                tmdb = str(candidates[0].get('id', '')) if candidates else ''
                if tmdb.isdigit():
                    self.cache[alias] = {'tmdb_id': tmdb, 'fetched_at': self.now()}
        if not tmdb.isdigit():
            return {}

        key = '%s:%s' % (media, tmdb)
        cached = self.cache.get(key, {})
        fresh = isinstance(cached, dict) and self.now() - cached.get('fetched_at', 0) < self.CACHE_TTL
        if fresh and 'genres' in cached and 'premiered' in cached and (not need_cert or cached.get('cert_checked')) and \
                (not need_art or cached.get('art_checked')) and cached.get('details_checked'):
            return {k: v for k, v in cached.items() if k != 'fetched_at'}

        result = dict(cached) if isinstance(cached, dict) else {}
        path = 'movie' if media == 'movie' else 'tv'
        try:
            if (not fresh or not result.get('details_checked') or
                    'genres' not in result or 'premiered' not in result):
                details = self._request('%s/%s' % (path, tmdb), api_key)
                result['title'] = details.get('title') or details.get('name') or ''
                result['plot'] = details.get('overview') or ''
                result['genres'] = [genre.get('name', '') for genre in details.get('genres', [])
                                    if isinstance(genre, dict) and genre.get('name')]
                date_value = details.get('release_date') or details.get('first_air_date') or ''
                result['premiered'] = str(date_value or '')[:10]
                result['year'] = int(date_value[:4]) if len(date_value) >= 4 and date_value[:4].isdigit() else 0
                runtimes = details.get('episode_run_time') or []
                runtime_minutes = details.get('runtime') or (runtimes[0] if runtimes else 0) or 0
                result['runtime'] = int(runtime_minutes) * 60 if str(runtime_minutes).isdigit() else 0
                result['details_checked'] = True
            if need_cert and (not fresh or not result.get('cert_checked')):
                endpoint = ('movie/%s/release_dates' if media == 'movie' else
                            'tv/%s/content_ratings') % tmdb
                result['mpaa'] = self._gb_certification(media, self._request(endpoint, api_key))
                result['cert_checked'] = True
            if need_art and (not fresh or not result.get('art_checked')):
                details = self._request('%s/%s' % (path, tmdb), api_key)
                poster = details.get('poster_path') or ''
                backdrop = details.get('backdrop_path') or ''
                if poster:
                    result['poster'] = self.IMAGE_BASE + 'w500' + poster
                if backdrop:
                    result['fanart'] = self.IMAGE_BASE + 'w1280' + backdrop
                result['art_checked'] = True
            result['fetched_at'] = self.now()
            self.cache[key] = result
            self._save_cache()
        except Exception:
            # Keep Kodi's own values available if TMDb is unavailable.
            pass
        return {k: v for k, v in result.items() if k != 'fetched_at'}

    def episode_details(self, tmdb_id, season, episode):
        """Return cached TMDb episode date, runtime, plot and rating details."""
        api_key = (self.addon.getSetting('tmdb_api_key') or '').strip()
        tmdb_id = self.tmdb_id(tmdb_id)
        try:
            season, episode = int(season), int(episode)
        except (TypeError, ValueError):
            return {}
        if not api_key or not tmdb_id or season <= 0 or episode <= 0:
            return {}
        key = 'episode:%s:%s:%s' % (tmdb_id, season, episode)
        cached = self.cache.get(key, {})
        if (isinstance(cached, dict) and cached.get('details_checked') and
                self.now() - cached.get('fetched_at', 0) < self.CACHE_TTL):
            return {name: value for name, value in cached.items()
                    if name not in ('fetched_at', 'details_checked')}
        try:
            details = self._request('tv/%s/season/%s/episode/%s' %
                                    (tmdb_id, season, episode), api_key)
            runtime = details.get('runtime') or 0
            try:
                runtime = int(runtime) * 60 if int(runtime) < 1000 else int(runtime)
            except (TypeError, ValueError):
                runtime = 0
            result = {
                'title': details.get('name') or '',
                'premiered': str(details.get('air_date') or '')[:10],
                'plot': details.get('overview') or '',
                'duration': runtime,
                'rating': details.get('vote_average') or 0,
                'votes': details.get('vote_count') or 0,
                'still_path': details.get('still_path') or '',
                'details_checked': True,
                'fetched_at': self.now(),
            }
            self.cache[key] = result
            self._save_cache()
            return {name: value for name, value in result.items()
                    if name not in ('fetched_at', 'details_checked')}
        except Exception:
            return {}

    @staticmethod
    def select_next_episode(seasons, episodes_by_season, after_season, after_episode,
                            watched, today=None):
        """Choose the first aired, unwatched episode after the latest watch."""
        today = today or date.today().isoformat()
        try:
            after = (int(after_season), int(after_episode))
        except (TypeError, ValueError):
            return None
        watched = set((int(season), int(episode)) for season, episode in watched)
        season_numbers = sorted({
            int(item.get('season_number') or 0) for item in (seasons or [])
            if isinstance(item, dict) and str(item.get('season_number', '')).isdigit()
            and int(item.get('season_number') or 0) > 0
        })
        for season_number in season_numbers:
            if season_number < after[0]:
                continue
            episodes = episodes_by_season.get(season_number) or []
            episodes = sorted((episode for episode in episodes if isinstance(episode, dict)),
                              key=lambda episode: int(episode.get('episode_number') or 0))
            for episode in episodes:
                try:
                    number = int(episode.get('episode_number') or 0)
                except (TypeError, ValueError):
                    continue
                key = (season_number, number)
                if number <= 0 or key <= after or key in watched:
                    continue
                air_date = str(episode.get('air_date') or '')
                # Do not show a future episode or jump over it to a later one.
                if len(air_date) >= 10 and air_date[:10] > today:
                    return None
                if not air_date or len(air_date) < 10:
                    return None
                return episode
        return None

    def next_available_episode(self, tmdb_id, after_season, after_episode, watched):
        """Return the next released unwatched episode for a series, if known."""
        api_key = (self.addon.getSetting('tmdb_api_key') or '').strip()
        tmdb_id = self.tmdb_id(tmdb_id)
        if not api_key or not tmdb_id:
            return {}
        cache_key = 'next_episode:%s' % tmdb_id
        cached = self.cache.get(cache_key, {})
        fresh = (isinstance(cached, dict) and
                 self.now() - cached.get('fetched_at', 0) < 24 * 60 * 60)
        if fresh and cached.get('after') == [int(after_season), int(after_episode)]:
            episode = cached.get('episode')
            if isinstance(episode, dict):
                watched = set((int(s), int(e)) for s, e in watched)
                pair = (int(episode.get('season_number') or 0),
                        int(episode.get('episode_number') or 0))
                if pair not in watched:
                    return dict(episode)
        try:
            show = self._request('tv/%s' % tmdb_id, api_key)
            seasons = show.get('seasons') or []
            numbers = sorted({int(item.get('season_number') or 0) for item in seasons
                              if isinstance(item, dict) and
                              str(item.get('season_number', '')).isdigit() and
                              int(item.get('season_number') or 0) > 0 and
                              int(item.get('season_number') or 0) >= int(after_season)})
            episode = None
            watched_set = set((int(s), int(e)) for s, e in watched)
            after = (int(after_season), int(after_episode))
            for season_number in numbers:
                response = self._request('tv/%s/season/%s' % (tmdb_id, season_number), api_key)
                season_episodes = response.get('episodes') or []
                episode = self.select_next_episode([{'season_number': season_number}],
                    {season_number: season_episodes}, after_season, after_episode, watched_set)
                if episode:
                    break
                has_unwatched = any(
                    (season_number, int(item.get('episode_number') or 0)) > after and
                    (season_number, int(item.get('episode_number') or 0)) not in watched_set
                    for item in season_episodes if isinstance(item, dict) and
                    str(item.get('episode_number', '')).isdigit())
                if has_unwatched:
                    # The first sequential episode is still unaired or has no
                    # confirmed release date; never jump over it to later seasons.
                    break
            self.cache[cache_key] = {
                'after': [int(after_season), int(after_episode)],
                'episode': episode or {}, 'fetched_at': self.now(),
            }
            self._save_cache()
            return dict(episode) if episode else {}
        except Exception:
            return {}
