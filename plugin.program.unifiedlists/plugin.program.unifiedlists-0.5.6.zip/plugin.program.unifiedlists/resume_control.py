"""One pending resume, applied by the service after matching AV playback."""
import sqlite3
import time
import uuid
import json
import re


def connect(path):
    con = sqlite3.connect(str(path), timeout=10)
    con.execute('CREATE TABLE IF NOT EXISTS pending_resume (slot INTEGER PRIMARY KEY, request_id TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, position REAL NOT NULL, expires REAL NOT NULL, file_path TEXT NOT NULL DEFAULT \'\', source_metadata TEXT NOT NULL DEFAULT \'{}\')')
    columns = {row[1] for row in con.execute('PRAGMA table_info(pending_resume)')}
    if 'file_path' not in columns:
        con.execute("ALTER TABLE pending_resume ADD COLUMN file_path TEXT NOT NULL DEFAULT ''")
    if 'source_metadata' not in columns:
        con.execute("ALTER TABLE pending_resume ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
    return con


def queue(path, media, mid, position, file_path='', metadata=None):
    request_id = uuid.uuid4().hex
    with connect(path) as con:
        con.execute('INSERT OR REPLACE INTO pending_resume (slot,request_id,media_type,kodi_id,position,expires,file_path,source_metadata) VALUES (1,?,?,?,?,?,?,?)',
                    (request_id, media, mid, position, time.time() + 600, str(file_path or ''),
                     json.dumps(metadata or {}, ensure_ascii=False)))
    con.close()
    return request_id


def clear(path, request_id):
    with connect(path) as con:
        con.execute('DELETE FROM pending_resume WHERE request_id=?', (request_id,))
    con.close()


class ResumeController:
    def __init__(self, path, notify):
        self.path = path
        self.notify = notify
        self.reset()

    def reset(self):
        self.request_id = None
        self.attempts = 0
        self.last_seek = None
        self.failed = False

    def stop(self):
        if self.request_id:
            clear(self.path, self.request_id)
        self.reset()

    def tick(self, player, item, position, duration):
        """Return True while resume is unsettled: do not overwrite saved progress."""
        if self.failed:
            return True
        con = connect(self.path)
        row = con.execute('SELECT request_id,media_type,kodi_id,position,expires,file_path,source_metadata FROM pending_resume WHERE slot=1').fetchone()
        con.close()
        if not row:
            return False
        request_id, media, mid, target, expires, file_path, source_metadata = row
        if time.time() > expires:
            clear(self.path, request_id)
            return False
        try:
            expected = json.loads(source_metadata or '{}')
        except (ValueError, TypeError):
            expected = {}
        same_identity = (item[0], item[1]) == (media, mid)
        same_metadata = _same_media(media, expected, item[4] if len(item) > 4 else {},
                                    item[2] if len(item) > 2 else '')
        same_path = bool(file_path and len(item) > 3 and str(item[3] or '') == file_path)
        if not same_identity and not same_path and not same_metadata:
            # Kodi can report provisional metadata while Umbrella is resolving
            # a stream. Keep the short-lived request pending until the selected
            # item is identifiable or playback is stopped.
            return True
        if self.request_id != request_id:
            self.reset()
            self.request_id = request_id
        if duration <= 0:
            return True
        if abs(position - target) <= 8:
            clear(self.path, request_id)
            self.reset()
            return False
        now = time.monotonic()
        if self.last_seek is not None and now - self.last_seek < 3:
            return True
        if self.attempts >= 3 or target >= duration:
            clear(self.path, request_id)
            self.failed = True
            self.notify()
            return True
        self.attempts += 1
        self.last_seek = now
        try:
            player.seekTime(float(target))
        except Exception:
            pass  # bounded retry; position must confirm success
        return True


def _norm(value):
    return re.sub(r'[^a-z0-9]+', '', str(value or '').casefold())


def _same_media(media, expected, actual, actual_title=''):
    """Match the queued item after Umbrella resolves it to a stream URL."""
    if not isinstance(expected, dict) or not isinstance(actual, dict):
        return False
    if media == 'episode':
        try:
            eseason, eepisode = int(expected.get('season') or 0), int(expected.get('episode') or 0)
            aseason, aepisode = int(actual.get('season') or 0), int(actual.get('episode') or 0)
        except (TypeError, ValueError):
            return False
        if not eseason or not eepisode or (eseason, eepisode) != (aseason, aepisode):
            return False
    expected_ids = expected.get('uniqueid') or {}
    actual_ids = actual.get('uniqueid') or {}
    if isinstance(expected_ids, dict) and isinstance(actual_ids, dict):
        comparable = set(expected_ids).intersection(actual_ids)
        for key in comparable:
            left, right = str(expected_ids.get(key) or ''), str(actual_ids.get(key) or '')
            if left and right:
                if left == right:
                    return True
    if media == 'episode':
        eshow = _norm(expected.get('showtitle') or expected.get('tvshowtitle'))
        ashow = _norm(actual.get('showtitle') or actual.get('tvshowtitle'))
        return bool(eshow and ashow and eshow == ashow and eseason > 0 and eepisode > 0
                    and (eseason, eepisode) == (aseason, aepisode))
    etitle = _norm(expected.get('title') or expected.get('label'))
    atitle = _norm(actual.get('title') or actual.get('label') or actual_title)
    if not etitle or etitle != atitle:
        return False
    eyear, ayear = str(expected.get('year') or ''), str(actual.get('year') or '')
    return not (eyear and ayear and eyear != ayear)
