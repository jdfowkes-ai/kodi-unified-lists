"""Umbrella playback and context actions used by the local Watch Later list."""
import json
import sqlite3
from urllib.parse import urlencode, urlparse, parse_qs

import xbmc
import xbmcgui


UMBRELLA = 'plugin://plugin.video.umbrella/'

def _umbrella_play_url(data):
    meta = dict(data['metadata'])
    # Umbrella's item links use action=play_Item with its native identifying
    # fields and serialized metadata. This retains its source selection,
    # resume and playback behavior.
    params = {
        'action': 'play_Item', 'title': data['title'], 'year': data['year'],
        'imdb': data['imdb'], 'tmdb': data['tmdb'], 'tvdb': data['tvdb'],
        'meta': json.dumps(meta, ensure_ascii=False, separators=(',', ':')),
    }
    if data['media'] == 'episode':
        params.update({'season': data['season'], 'episode': data['episode'],
                       'tvshowtitle': data['show'],
                       'premiered': meta.get('premiered', '')})
    return UMBRELLA + '?' + urlencode(params)


def _addon_url(action, payload):
    import sys
    encoded = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
    return sys.argv[0] + '?' + urlencode({'action': action, 'data': encoded})




def _listitem(data):
    li = xbmcgui.ListItem(label=data['label'])
    meta = data['metadata']
    art = meta.get('art') if isinstance(meta.get('art'), dict) else {}
    art = dict(art)
    for target, keys in {
        'poster': ('poster', 'thumb'), 'thumb': ('thumb', 'poster'),
        'landscape': ('landscape', 'fanart', 'thumb', 'poster'),
        'fanart': ('fanart', 'landscape'), 'icon': ('icon', 'poster', 'thumb'),
    }.items():
        if not art.get(target):
            art[target] = next((meta.get(k) for k in keys if meta.get(k)), '')
    li.setArt({k: str(v).replace(' ', '%20') for k, v in art.items() if v})
    tag = li.getVideoInfoTag()
    tag.setMediaType(data['media'])
    tag.setTitle(data['title'])
    tag.setPlot(meta.get('plot') or meta.get('overview') or '')
    genres = meta.get('genres') or meta.get('genre') or []
    if isinstance(genres, str):
        genres = [part.strip() for part in genres.replace('|', ',').split(',') if part.strip()]
    elif isinstance(genres, dict):
        genres = [str(value) for value in genres.values() if value]
    elif not isinstance(genres, (list, tuple)):
        genres = []
    else:
        genres = [str(value.get('name') if isinstance(value, dict) else value)
                  for value in genres if value]
    if genres:
        try:
            tag.setGenres(genres)
        except (AttributeError, TypeError, ValueError):
            pass
    certificate = (meta.get('mpaa') or meta.get('certification') or
                   meta.get('content_rating') or meta.get('rating_certification'))
    if certificate:
        try:
            tag.setMpaa(str(certificate))
        except (AttributeError, TypeError, ValueError):
            pass
    try:
        if meta.get('rating'):
            tag.setRating(float(meta['rating']), int(meta.get('votes') or 0), 'imdb')
    except (AttributeError, TypeError, ValueError):
        pass
    ids = {key: value for key, value in {
        'imdb': data.get('imdb'), 'tmdb': data.get('tmdb'),
        'tvdb': data.get('tvdb')}.items() if value}
    try:
        if ids:
            tag.setUniqueIDs(ids)
    except (AttributeError, TypeError, ValueError):
        pass
    try:
        if data['year']:
            tag.setYear(int(data['year']))
    except (TypeError, ValueError):
        pass
    if data['media'] == 'episode':
        tag.setTvShowTitle(data['show'])
        tag.setSeason(data['season'])
        tag.setEpisode(data['episode'])
    premiered = (meta.get('premiered') or meta.get('firstaired') or
                 meta.get('first_aired') or meta.get('release_date') or '')
    premiered = str(premiered)[:10]
    if premiered:
        try:
            tag.setPremiered(premiered)
        except (AttributeError, TypeError, ValueError):
            pass
        if data['media'] == 'episode':
            try:
                tag.setFirstAired(premiered)
            except (AttributeError, TypeError, ValueError):
                pass
    try:
        duration = float(data.get('episode_duration') or meta.get('duration') or
                         meta.get('runtime') or 0)
    except (TypeError, ValueError):
        duration = 0.0
    if duration <= data['position'] and data['percent'] > 0:
        duration = data['position'] * 100.0 / data['percent']
    if duration <= data['position']:
        duration = data['position'] + max(60.0, data['position'] * 0.2)
    try:
        tag.setDuration(float(duration))
    except (AttributeError, TypeError, ValueError):
        pass
    if data['position'] >= 30:
        # Umbrella's own widgets use VideoInfoTag.setResumePoint plus
        # IsPlayable; Kodi then passes resume:true/false to Umbrella.
        try:
            tag.setResumePoint(float(data['position']), float(duration))
        except (AttributeError, TypeError, ValueError):
            pass
    if data['media'] == 'episode':
        li.setProperty('tvshow.tmdb_id', str(data.get('tmdb') or ''))
        li.setProperty('episode_type', str(meta.get('episode_type') or ''))
    li.setProperty('IsPlayable', 'true')
    li.setProperty('WatchedProgress', str(round(data['percent'])))
    li.setProperty('PercentPlayed', str(round(data['percent'])))
    # Do not set isUmbrella_widget: Umbrella gates its extra context commands
    # on that marker. Kodi still gets the native resume point and Umbrella URL.
    return li


def _run_action(action, data):
    play_url = _umbrella_play_url(data)
    if action == 'watch_later_actions':
        xbmc.executebuiltin('Action(ContextMenu)')
    elif action == 'watch_later_resume':
        # Keep Umbrella's native bookmark available, then request a confirmed
        # post-start seek so resume works even if Umbrella's bookmark lookup
        # does not recognize this cached progress record.
        from umbrella_local import set_resume_bookmark
        set_resume_bookmark(data['media'], data['metadata'], data['position'])
        from identity import stable_identity
        from resume_control import queue
        from default import DB_PATH
        mid, _identity = stable_identity(data['media'], data['metadata'], play_url)
        queue(DB_PATH, data['media'], mid, data['position'], play_url, data['metadata'])
        _queue_watch_later(data, mid)
        xbmc.executebuiltin('PlayMedia(%s)' % play_url)
    elif action == 'watch_later_beginning':
        from umbrella_local import clear_bookmark
        clear_bookmark(data['media'], data['metadata'])
        from identity import stable_identity
        from default import DB_PATH
        mid, _identity = stable_identity(data['media'], data['metadata'], play_url)
        _queue_watch_later(data, mid)
        xbmc.executebuiltin('PlayMedia(%s)' % play_url)
    elif action == 'watch_later_trailer':
        # One trailer choice only. Umbrella resolves a trailer if no cached
        # trailer URL is present, using its native selection route.
        if data['metadata'].get('trailer'):
            params = {'action': 'play_Trailer_Context', 'type': 'movie',
                      'name': data['title'], 'year': data['year'],
                      'imdb': data['imdb'], 'url': data['metadata']['trailer']}
        else:
            params = {'action': 'play_Trailer_Select', 'type': 'movie',
                      'name': data['title'], 'year': data['year']}
        xbmc.executebuiltin('RunPlugin(%s?%s)' % (UMBRELLA, urlencode(params)))
    elif action == 'watch_later_information':
        xbmc.executebuiltin('Action(Info)')
    elif action == 'watch_later_watch_later':
        if data.get('source_list') == 'Watch Later':
            _remove_watch_later(data)
        else:
            _save_watch_later(data)
    elif action == 'watch_later_favourite':
        params = {'action': ('add_favorite' if data['media'] == 'movie'
                             else 'add_favorite_episode'),
                  'meta': json.dumps(data['metadata'], ensure_ascii=False,
                                     separators=(',', ':')),
                  'content': ('movies' if data['media'] == 'movie' else 'episode')}
        xbmc.executebuiltin('RunPlugin(%s?%s)' % (UMBRELLA, urlencode(params)))


def _save_watch_later(data):
    from identity import stable_identity
    from default import DB_PATH
    media = data['media']
    play_url = _umbrella_play_url(data)
    mid, _identity = stable_identity(media, data['metadata'], play_url)
    con = sqlite3.connect(str(DB_PATH))
    try:
        con.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?)',
                    ('Watch Later', media, mid, data['title']))
        action_url = _addon_url('watch_later_actions', data)
        con.execute('INSERT OR REPLACE INTO external_list_items '
                    '(media_type,kodi_id,path,is_folder,metadata_json) VALUES (?,?,?,?,?)',
                    (media, mid, action_url, 0,
                     json.dumps(data['metadata'], ensure_ascii=False)))
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'Added to Watch Later',
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def _remove_watch_later(data):
    import sqlite3
    from default import DB_PATH
    mid = int(data.get('local_kodi_id') or 0)
    con = sqlite3.connect(str(DB_PATH), timeout=10)
    try:
        con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                    ('Watch Later', data['media'], mid))
        con.execute('DELETE FROM external_list_items WHERE media_type=? AND kodi_id=? '
                    'AND NOT EXISTS (SELECT 1 FROM entries WHERE media_type=? AND kodi_id=?)',
                    (data['media'], mid, data['media'], mid))
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'Removed from Watch Later',
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def _queue_watch_later(data, mid):
    if data.get('source_list') != 'Watch Later':
        return
    from default import DB_PATH
    from watch_later_playback import queue
    queue(DB_PATH, data['media'], int(data.get('local_kodi_id') or mid),
          data.get('title', ''), data.get('metadata', {}))


def watch_later_payload(media, mid, title, path, metadata_json, saved=None):
    """Build the same compact action item for old and new Watch Later rows."""
    metadata = {}
    try:
        metadata = json.loads(metadata_json or '{}')
    except (ValueError, TypeError):
        pass
    data = None
    if path and path.startswith('plugin://plugin.program.unifiedlists'):
        parsed = parse_qs(urlparse(path).query)
        raw = parsed.get('data', ['{}'])[0]
        try:
            candidate = json.loads(raw)
            if isinstance(candidate, dict) and candidate.get('media') in ('movie', 'episode'):
                data = candidate
        except (ValueError, TypeError):
            pass
    if data is None:
        ids = metadata.get('uniqueid') or metadata.get('ids') or {}
        if not isinstance(ids, dict):
            ids = {}
        season = int(metadata.get('season') or 0)
        episode = int(metadata.get('episode') or 0)
        show = metadata.get('tvshowtitle') or metadata.get('showtitle') or ''
        data = {'media': media, 'title': title, 'label': title, 'show': show,
                'year': metadata.get('year') or '', 'imdb': str(ids.get('imdb') or metadata.get('imdb') or ''),
                'tmdb': str(ids.get('tmdb') or metadata.get('tmdb') or ''),
                'tvdb': str(ids.get('tvdb') or metadata.get('tvdb') or ''),
                'season': season, 'episode': episode, 'percent': 0,
                'position': float(saved[0]) if saved and saved[0] else 0,
                'metadata': metadata}
    data.update({'source_list': 'Watch Later', 'local_kodi_id': int(mid)})
    if saved:
        data['position'] = float(saved[0] or 0)
        data['percent'] = (100.0 * saved[0] / saved[1]) if saved[1] else 0
    data['label'] = ('%s · S%02d E%02d · %s' % (data.get('show') or title,
                    int(data.get('season') or 0), int(data.get('episode') or 0), title)
                    if media == 'episode' else title)
    return data




def run_action():
    import sys
    from urllib.parse import parse_qs
    from urllib.parse import unquote
    params = parse_qs(sys.argv[2][1:])
    action = params.get('action', ['watch_later_actions'])[0]
    raw = params.get('data', ['{}'])[0]
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return
    if not isinstance(data, dict) or data.get('media') not in ('movie', 'episode'):
        return
    _run_action(action, data)
