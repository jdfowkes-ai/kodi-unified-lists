# App spotlight widgets

Unified Lists exposes a separate widget source for each app. In Arctic Fuse 3,
assign the matching source as the widget for that app menu/submenu item. The
skin uses the widget items for its spotlight artwork and timed cycling.

Example Disney+ widget source:

`plugin://plugin.program.unifiedlists/?action=app_spotlight&app=disney-plus`

Choose the content source from either the app's context menu in **Apps** or
Unified Lists → **Manage Apps** → **Choose spotlight source**. Pick the app,
browse Umbrella to the folder whose titles should feed its spotlight, then
select **Use this Umbrella folder**. Each app saves its own folder. The widget
reads that Umbrella directory through Kodi's `Files.GetDirectory` API, so the
items, artwork, metadata, and playback links come from Umbrella. Set the widget
cycling interval in Arctic Fuse 3; the skin rotates through the returned items.

Apps and IDs:

| App | ID |
| --- | --- |
| BBC iPlayer | `bbc-iplayer` |
| ITVX | `itvx` |
| Channel 4 | `channel-4` |
| Netflix | `netflix` |
| Prime Video | `prime-video` |
| Apple TV | `apple-tv` |
| Disney+ | `disney-plus` |
| YouTube | `youtube` |
| Paramount+ | `paramount-plus` |
| HBO Max | `hbo-max` |

Spotlight directory URLs use `action=app_spotlight` with the corresponding app
ID. For example:

- `plugin://plugin.program.unifiedlists/?action=app_spotlight&app=netflix`
- `plugin://plugin.program.unifiedlists/?action=app_spotlight&app=disney-plus`

The Apps directory remains the app launcher and supports add/remove, filtering,
and most-recently-used ordering. The Watch Later list remains available.
