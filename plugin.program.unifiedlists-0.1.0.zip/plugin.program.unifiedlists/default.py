# -*- coding: utf-8 -*-
"""Unified Local List Manager v0.1: Kodi-library-backed personal lists."""
import json
import os
import sqlite3
import sys
from urllib.parse import parse_qs, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PARAMS = {key: values[0] for key, values in parse_qs(sys.argv[2][1:]).items()}
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
os.makedirs(PROFILE, exist_ok=True)
DB_PATH = os.path.join(PROFILE, 'lists.db')
LISTS = [('start', 'Start Watching'), ('later', 'Watch Later'), ('favourites', 'Favourites')]


def db():
    connection = sqlite3.connect(DB_PATH)
    connection.execute('CREATE TABLE IF NOT EXISTS entries (list_id TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, added_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (list_id, media_type, kodi_id))')
    connection.commit()
    return connection


def rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}}
    result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if 'error' in result:
        raise RuntimeError(str(result['error']))
    return result.get('result', {})


def url(**kwargs):
    return BASE + '?' + urlencode(kwargs)


def folder(label, **kwargs):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(HANDLE, url(**kwargs), li, isFolder=True)


def notification(message):
    xbmcgui.Dialog().notification('Unified Lists', message, xbmcgui.NOTIFICATION_INFO, 2500)


def media_rows(media_type):
    if media_type == 'movie':
        result = rpc('VideoLibrary.GetMovies', {'properties': ['title', 'art', 'file', 'year'], 'sort': {'method': 'title', 'order': 'ascending'}})
        return [(x['movieid'], x['title'], x.get('art', {})) for x in result.get('movies', [])]
    result = rpc('VideoLibrary.GetTVShows', {'properties': ['title', 'art', 'year'], 'sort': {'method': 'title', 'order': 'ascending'}})
    return [(x['tvshowid'], x['title'], x.get('art', {})) for x in result.get('tvshows', [])]


def item_art(li, art):
    li.setArt({key: value for key, value in art.items() if isinstance(value, str)})


def list_entries(list_id):
    connection = db()
    try:
        return connection.execute('SELECT media_type, kodi_id, title FROM entries WHERE list_id=? ORDER BY added_at DESC, rowid DESC', (list_id,)).fetchall()
    finally:
        connection.close()


def add_entry(list_id, media_type, kodi_id, title):
    connection = db()
    try:
        # Start Watching and Watch Later are mutually exclusive.
        if list_id in ('start', 'later'):
            other = 'later' if list_id == 'start' else 'start'
            connection.execute('DELETE FROM entries WHERE list_id=? AND media_type=? AND kodi_id=?', (other, media_type, kodi_id))
        connection.execute('INSERT OR IGNORE INTO entries(list_id,media_type,kodi_id,title) VALUES (?,?,?,?)', (list_id, media_type, kodi_id, title))
        connection.commit()
    finally:
        connection.close()


def remove_entry(list_id, media_type, kodi_id):
    connection = db()
    try:
        connection.execute('DELETE FROM entries WHERE list_id=? AND media_type=? AND kodi_id=?', (list_id, media_type, kodi_id))
        connection.commit()
    finally:
        connection.close()


def context_action(label, **kwargs):
    return (label, 'RunPlugin(' + url(**kwargs) + ')')


def show_library(media_type):
    for kodi_id, title, art in media_rows(media_type):
        li = xbmcgui.ListItem(label=title)
        item_art(li, art)
        li.setProperty('IsPlayable', 'false')
        li.addContextMenuItems([context_action('Add to ' + display, action='add', list_id=lid, media_type=media_type, kodi_id=kodi_id, title=title) for lid, display in LISTS])
        xbmcplugin.addDirectoryItem(HANDLE, url(action='detail', media_type=media_type, kodi_id=kodi_id), li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_list(list_id):
    for media_type, kodi_id, title in list_entries(list_id):
        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': 'DefaultVideo.png'})
        li.addContextMenuItems([context_action('Remove from list', action='remove', list_id=list_id, media_type=media_type, kodi_id=kodi_id)])
        xbmcplugin.addDirectoryItem(HANDLE, url(action='detail', media_type=media_type, kodi_id=kodi_id), li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_detail(media_type, kodi_id):
    # Kodi's native video-library windows retain their usual playback controls.
    if media_type == 'movie':
        xbmc.executebuiltin('ActivateWindow(Videos,videodb://movies/titles/%s,return)' % kodi_id)
    else:
        xbmc.executebuiltin('ActivateWindow(Videos,videodb://tvshows/titles/%s/,return)' % kodi_id)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def main():
    action = PARAMS.get('action', 'home')
    if action == 'home':
        folder('Start Watching', action='list', list_id='start')
        folder('Watch Later', action='list', list_id='later')
        folder('Favourites', action='list', list_id='favourites')
        folder('Browse Library Movies', action='library', media_type='movie')
        folder('Browse Library TV Shows', action='library', media_type='tvshow')
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == 'library':
        show_library(PARAMS['media_type'])
    elif action == 'list':
        show_list(PARAMS['list_id'])
    elif action == 'detail':
        show_detail(PARAMS['media_type'], int(PARAMS['kodi_id']))
    elif action in ('add', 'remove'):
        list_id = PARAMS['list_id']
        media_type = PARAMS['media_type']
        kodi_id = int(PARAMS['kodi_id'])
        if action == 'add':
            add_entry(list_id, media_type, kodi_id, PARAMS['title'])
            notification('Added to ' + dict(LISTS)[list_id])
        else:
            remove_entry(list_id, media_type, kodi_id)
            notification('Removed from ' + dict(LISTS)[list_id])
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        xbmc.log('[Unified Lists] ' + str(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Unified Lists', 'Error: check Kodi log', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
