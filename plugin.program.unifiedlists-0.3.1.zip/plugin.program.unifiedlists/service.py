import json
import hashlib
import re
import sqlite3
import time
from pathlib import Path
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
from resume_control import ResumeController

PROFILE = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')))
DB = PROFILE / 'lists.db'

def rpc(method, params=None):
    req = {'jsonrpc':'2.0','id':1,'method':method}
    if params is not None: req['params'] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(req))).get('result',{})

def normalise(value):
    return re.sub(r'[^a-z0-9]+', '', str(value or '').casefold())

def positive_int(value):
    try:
        value = int(value)
        return value if value > 0 else None
    except (TypeError, ValueError):
        return None

def match_library_episode(item):
    """Resolve an add-on stream to one unambiguous Kodi library episode.

    Streams can expose incomplete or differently typed Kodi metadata. Narrow
    by series first, then by episode number and title, and only accept a unique
    result so identical episode titles cannot cross-link between shows.
    """
    showtitle = item.get('showtitle') or item.get('tvshowtitle') or ''
    title = item.get('title') or item.get('label') or ''
    if not title:
        return None
    try:
        season, episode = int(item.get('season') or 0), int(item.get('episode') or 0)
    except (TypeError, ValueError):
        season, episode = 0, 0
    properties = ['title','showtitle','season','episode','tvshowid','file','playcount',
                  'firstaired','plot','art','thumbnail','fanart','runtime','mpaa','year','uniqueid']
    show_id = positive_int(item.get('tvshowid'))
    if showtitle and not show_id:
        shows = rpc('VideoLibrary.GetTVShows', {'properties':['title']}).get('tvshows', [])
        matches = [show for show in shows if normalise(show.get('title')) == normalise(showtitle)]
        show_id = positive_int(matches[0].get('tvshowid')) if len(matches) == 1 else None
    if show_id:
        entries = rpc('VideoLibrary.GetEpisodes', {'tvshowid':int(show_id),'properties':properties}).get('episodes', [])
    else:
        # Some add-on streams omit the series title. Search Kodi's episode
        # index and only link when exact title/number identifies one episode.
        entries = rpc('VideoLibrary.GetEpisodes', {'properties':properties}).get('episodes', [])
    # If Kodi supplied a series title but its ID could not be resolved, keep
    # the search constrained to that title instead of risking another show.
    if showtitle:
        titled_entries = [entry for entry in entries
                          if normalise(entry.get('showtitle')) == normalise(showtitle)]
        if titled_entries:
            entries = titled_entries
        elif not show_id:
            return None

    candidates = []
    if season > 0 and episode > 0:
        candidates = [entry for entry in entries
                      if int(entry.get('season') or 0) == season and int(entry.get('episode') or 0) == episode]
    exact_number_and_title = [entry for entry in candidates
                              if normalise(entry.get('title')) == normalise(title)]
    if len(exact_number_and_title) == 1:
        return exact_number_and_title[0]
    if len(candidates) == 1:
        return candidates[0]
    exact_title = [entry for entry in entries
                   if normalise(entry.get('title')) == normalise(title)]
    return exact_title[0] if len(exact_title) == 1 else None

def reconcile_stream_progress(episode_id, path, title, metadata):
    """Attach an older synthetic stream row to its newly resolved library episode."""
    try:
        con = connect()
        exists = con.execute(
            'SELECT 1 FROM playback_progress WHERE media_type=? AND kodi_id=?',
            ('episode', int(episode_id))
        ).fetchone()
        if exists:
            con.execute(
                'DELETE FROM playback_progress WHERE media_type=? AND kodi_id<0 AND file_path=?',
                ('episode', path)
            )
        else:
            con.execute(
                'UPDATE playback_progress SET kodi_id=?,title=?,source_metadata=?,updated_at=CURRENT_TIMESTAMP '
                'WHERE media_type=? AND kodi_id<0 AND file_path=?',
                (int(episode_id), title, json.dumps(metadata, ensure_ascii=False), 'episode', path)
            )
        con.commit()
        con.close()
    except Exception as exc:
        xbmc.log('Unified Lists could not reconcile episode progress: '+str(exc), xbmc.LOGWARNING)

def identify():
    active = rpc('Player.GetActivePlayers')
    player = next((p for p in active if p.get('type')=='video'),None)
    if not player: return None
    props = ['file','title','showtitle','uniqueid','art','thumbnail','fanart','mpaa','year','runtime','plot','season','episode']
    obj = rpc('Player.GetItem',{'playerid':player['playerid'],'properties':props}).get('item',{})
    media, mid, path = obj.get('type'),obj.get('id'),obj.get('file')
    if media not in ('movie','episode'):
        # Some video add-on streams are reported as `unknown` by Kodi. Episode
        # fields still identify TV playback; otherwise treat a video stream as
        # a movie so add-on films can be tracked.
        media = 'episode' if obj.get('showtitle') or ('season' in obj and 'episode' in obj) else 'movie'
    if not path: return None
    if media == 'episode':
        library_episode = match_library_episode(obj)
        if library_episode:
            # Keep Umbrella's playable stream path while using the matching
            # library identity and metadata for stable progress and artwork.
            obj.update(library_episode)
            mid = library_episode.get('episodeid', obj.get('id'))
            obj['id'] = mid
            obj['file'] = path
            metadata = {key: obj[key] for key in ('title','showtitle','uniqueid','art','thumbnail','fanart','mpaa','year','runtime','plot','season','episode','tvshowid') if key in obj}
            reconcile_stream_progress(mid, path, obj.get('title') or '', metadata)
    # Library items keep their real Kodi ID. Add-on streams often have no
    # VideoLibrary ID, so key them by TMDb ID, falling back to their file URL.
    if not isinstance(mid, int) or mid <= 0:
        uniqueid = obj.get('uniqueid') or {}
        tmdb = uniqueid.get('tmdb') or uniqueid.get('themoviedb') if isinstance(uniqueid, dict) else uniqueid
        identity = 'tmdb:' + str(tmdb) if str(tmdb or '').isdigit() else 'path:' + str(path)
        digest = int(hashlib.sha256((media + ':' + identity).encode('utf-8')).hexdigest()[:15], 16)
        mid = -(digest or 1)
    metadata = {key: obj[key] for key in ('title','showtitle','uniqueid','art','thumbnail','fanart','mpaa','year','runtime','plot','season','episode','tvshowid') if key in obj}
    return (media,mid,obj.get('title') or obj.get('label') or 'Untitled',path,metadata)

def connect():
    PROFILE.mkdir(parents=True,exist_ok=True)
    con = sqlite3.connect(str(DB),timeout=10)
    con.execute('CREATE TABLE IF NOT EXISTS playback_progress (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL, completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, source_metadata TEXT NOT NULL DEFAULT \'{}\', PRIMARY KEY(media_type,kodi_id))')
    columns = {row[1] for row in con.execute('PRAGMA table_info(playback_progress)')}
    if 'source_metadata' not in columns:
        con.execute("ALTER TABLE playback_progress ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
    con.commit()
    return con

class Tracker(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.resume = ResumeController(DB, lambda: xbmcgui.Dialog().notification('Unified Lists', 'Resume failed; your saved position has been kept', xbmcgui.NOTIFICATION_WARNING, 5000))
        self.av_ready = False
        self.last_identify = 0
        self.identity_started = 0
        self.reset()
    def reset(self):
        self.item=None
        self.first=None
        self.position=None
        self.duration=0
        self.last_saved=None
        self.watched_marked=False
    def onAVStarted(self):
        self.reset()
        self.resume.reset()
        self.av_ready = True
        self.last_identify = 0
        self.identity_started = time.monotonic()
    def onPlayBackStopped(self):
        self.save()
        self.resume.stop()
        self.av_ready = False
        self.reset()
    def onPlayBackEnded(self):
        self.save(ended=True)
        self.resume.stop()
        self.av_ready = False
        self.reset()
    def save(self,ended=False):
        if self.resume.failed: return
        if self.item is None or self.position is None: return
        media,mid,title,path,metadata=self.item
        complete=bool(ended or (self.duration>0 and self.position/self.duration>=.9))
        if not complete and (self.first is None or self.position-self.first<30): return
        try:
            con=connect()
            con.execute('INSERT INTO playback_progress (media_type,kodi_id,title,file_path,position,duration,completed,updated_at,source_metadata) VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?) ON CONFLICT(media_type,kodi_id) DO UPDATE SET title=excluded.title,file_path=excluded.file_path,position=excluded.position,duration=excluded.duration,completed=excluded.completed,updated_at=CURRENT_TIMESTAMP,source_metadata=excluded.source_metadata',(media,mid,title,path,self.position,self.duration,int(complete),json.dumps(metadata, ensure_ascii=False)))
            if complete and media=='movie':
                con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',('Start Watching',media,mid))
            con.commit();con.close()
            self.last_saved=self.position
            if complete and media == 'episode' and mid > 0 and not self.watched_marked:
                self.watched_marked = self.mark_episode_watched(mid)
        except Exception as exc:
            xbmc.log('Unified Lists database error: '+str(exc),xbmc.LOGERROR)

    @staticmethod
    def mark_episode_watched(episode_id):
        """Preserve Kodi library watched state after confirmed full playback."""
        try:
            current = rpc('VideoLibrary.GetEpisodeDetails', {
                'episodeid': int(episode_id), 'properties': ['playcount']
            }).get('episodedetails', {})
            if int(current.get('playcount') or 0) > 0:
                return True
            request = {'jsonrpc':'2.0','id':1,'method':'VideoLibrary.SetEpisodeDetails',
                       'params':{'episodeid':int(episode_id),'playcount':1}}
            response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            return not bool(response.get('error'))
        except Exception as exc:
            xbmc.log('Unified Lists could not update episode watched state: '+str(exc),xbmc.LOGWARNING)
            return False
    def tick(self):
        if not self.av_ready or not self.isPlayingVideo(): return
        try:
            pos=float(self.getTime())
            duration=float(self.getTotalTime())
        except Exception: return
        # Some add-ons publish only the stream title on the first AVStarted
        # event. Retry briefly while playback metadata settles, then keep the
        # later Kodi library match (and its artwork) instead of a synthetic ID.
        now = time.monotonic()
        retry_identity = self.item is None or (
            self.item[1] < 0 and now - self.identity_started < 35
        )
        if retry_identity and now - self.last_identify >= 5:
            candidate = identify()
            self.last_identify = now
            if candidate is not None:
                if (self.item is None or candidate[1] > 0 or
                        candidate[0] == 'episode' and self.item[0] != 'episode'):
                    self.item = candidate
                elif candidate[0] == self.item[0] and self.item[1] < 0:
                    old_meta = self.item[4]
                    new_meta = candidate[4]
                    merged = dict(old_meta)
                    merged.update({key: value for key, value in new_meta.items()
                                   if value not in (None, '', {}, [])})
                    self.item = (candidate[0], candidate[1],
                                 candidate[2] or self.item[2], candidate[3], merged)
        if self.item is None: return
        if self.resume.tick(self, self.item, pos, duration):
            self.first = None
            self.position = None
            return
        if self.first is None: self.first=pos
        self.position=pos
        self.duration=duration
        if self.last_saved is None or pos-self.last_saved>=10: self.save()

monitor=xbmc.Monitor()
tracker=Tracker()
while not monitor.abortRequested():
    try: tracker.tick()
    except Exception as exc: xbmc.log('Unified Lists tracking: '+str(exc),xbmc.LOGERROR)
    monitor.waitForAbort(1)
