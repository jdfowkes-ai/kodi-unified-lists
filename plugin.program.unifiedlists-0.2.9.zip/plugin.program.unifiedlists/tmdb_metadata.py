"""Optional TMDb artwork and GB certification lookup for Kodi library items."""
import json
import os
import time
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmcaddon
import xbmcvfs


class TMDbMetadata:
    CACHE_TTL = 30 * 24 * 60 * 60
    IMAGE_BASE = 'https://image.tmdb.org/t/p/'

    def __init__(self, addon=None, opener=None, now=None):
        self.addon = addon or xbmcaddon.Addon()
        self.opener = opener or urlopen
        self.now = now or time.time
        profile = Path(xbmcvfs.translatePath(self.addon.getAddonInfo('profile')))
        profile.mkdir(parents=True, exist_ok=True)
        self.cache_path = profile / 'tmdb_metadata.json'
        self.cache = self._load_cache()

    def _load_cache(self):
        try:
            with self.cache_path.open('r', encoding='utf-8') as source:
                data = json.load(source)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    def _save_cache(self):
        temp = self.cache_path.with_name(self.cache_path.name + '.tmp')
        try:
            with temp.open('w', encoding='utf-8') as output:
                json.dump(self.cache, output, ensure_ascii=False)
                output.flush()
                os.fsync(output.fileno())
            os.replace(str(temp), str(self.cache_path))
        finally:
            if temp.exists():
                temp.unlink()

    @staticmethod
    def tmdb_id(uniqueid):
        if isinstance(uniqueid, dict):
            value = uniqueid.get('tmdb') or uniqueid.get('themoviedb')
        else:
            value = uniqueid
        value = str(value or '').strip()
        return value if value.isdigit() else ''

    def _request(self, endpoint, api_key):
        url = 'https://api.themoviedb.org/3/%s?%s' % (
            endpoint.lstrip('/'), urlencode({'api_key': api_key, 'language': 'en-GB'}))
        request = Request(url, headers={'Accept': 'application/json', 'User-Agent': 'UnifiedLocalListManager/0.2.9'})
        with self.opener(request, timeout=4) as response:
            raw = response.read(1024 * 1024)
        data = json.loads(raw.decode('utf-8'))
        return data if isinstance(data, dict) else {}

    @staticmethod
    def _gb_certification(media, response):
        if media == 'movie':
            regions = response.get('results', [])
            gb = next((region for region in regions if region.get('iso_3166_1') == 'GB'), {})
            releases = [item for item in gb.get('release_dates', []) if item.get('certification')]
            priority = {3: 0, 4: 1, 5: 2, 6: 3, 2: 4, 1: 5}
            releases.sort(key=lambda item: (priority.get(item.get('type'), 9), item.get('release_date', '')))
            return next((item.get('certification', '').strip() for item in releases
                         if item.get('certification', '').strip()), '')
        ratings = response.get('results', [])
        gb = next((item for item in ratings if item.get('iso_3166_1') == 'GB'), {})
        return (gb.get('rating') or '').strip()

    def lookup(self, media, uniqueid, need_art=False, need_cert=True):
        """Return only provider-confirmed GB certification and optional artwork."""
        tmdb = self.tmdb_id(uniqueid)
        api_key = (self.addon.getSetting('tmdb_api_key') or '').strip()
        if not tmdb or not api_key or media not in ('movie', 'tv') or not (need_art or need_cert):
            return {}

        key = '%s:%s' % (media, tmdb)
        cached = self.cache.get(key, {})
        fresh = isinstance(cached, dict) and self.now() - cached.get('fetched_at', 0) < self.CACHE_TTL
        if fresh and (not need_cert or cached.get('cert_checked')) and \
                (not need_art or cached.get('art_checked')):
            return {k: v for k, v in cached.items() if k != 'fetched_at'}

        result = dict(cached) if isinstance(cached, dict) else {}
        path = 'movie' if media == 'movie' else 'tv'
        try:
            if need_cert and (not fresh or not result.get('cert_checked')):
                endpoint = ('movie/%s/release_dates' if media == 'movie' else
                            'tv/%s/content_ratings') % tmdb
                result['mpaa'] = self._gb_certification(media, self._request(endpoint, api_key))
                result['cert_checked'] = True
            if need_art and (not fresh or not result.get('art_checked')):
                details = self._request('%s/%s' % (path, tmdb), api_key)
                poster = details.get('poster_path') or ''
                backdrop = details.get('backdrop_path') or ''
                if poster:
                    result['poster'] = self.IMAGE_BASE + 'w500' + poster
                if backdrop:
                    result['fanart'] = self.IMAGE_BASE + 'w1280' + backdrop
                result['art_checked'] = True
            result['fetched_at'] = self.now()
            self.cache[key] = result
            self._save_cache()
        except Exception:
            # Keep Kodi's own values available if TMDb is unavailable.
            pass
        return {k: v for k, v in result.items() if k != 'fetched_at'}
