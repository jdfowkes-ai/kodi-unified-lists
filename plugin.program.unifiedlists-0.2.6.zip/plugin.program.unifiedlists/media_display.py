"""Library artwork and metadata for normal Kodi directory items."""
import json
import xbmc
import xbmcgui

SPECS = {
    'movie': ('VideoLibrary.GetMovieDetails', 'movieid', 'moviedetails'),
    'tvshow': ('VideoLibrary.GetTVShowDetails', 'tvshowid', 'tvshowdetails'),
    'episode': ('VideoLibrary.GetEpisodeDetails', 'episodeid', 'episodedetails'),
}


class MediaDisplay:
    def __init__(self):
        self.cache = {}

    def details(self, media, mid):
        key = (media, int(mid))
        if key in self.cache:
            return self.cache[key]
        method, id_key, result_key = SPECS[media]
        props = ['title', 'plot', 'art', 'thumbnail', 'fanart']
        props += ['showtitle', 'season', 'episode', 'tvshowid', 'runtime'] if media == 'episode' else ['year']
        if media == 'movie':
            props.append('runtime')
        request = {'jsonrpc': '2.0', 'id': 1, 'method': method,
                   'params': {id_key: int(mid), 'properties': props}}
        try:
            data = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {}).get(result_key, {})
        except (ValueError, TypeError):
            data = {}
        self.cache[key] = data
        return data

    def listitem(self, media, mid, title, progress=None):
        details = self.details(media, mid)
        art = {k: v for k, v in details.get('art', {}).items() if v}
        if media == 'episode' and details.get('tvshowid', -1) >= 0:
            parent = self.details('tvshow', details['tvshowid'])
            parent_art = parent.get('art', {})
            for key in ('poster', 'fanart', 'banner', 'clearlogo', 'landscape'):
                art.setdefault(key, art.get('tvshow.' + key) or parent_art.get(key) or '')
        art['poster'] = art.get('poster') or details.get('thumbnail') or 'DefaultVideo.png'
        art['thumb'] = art.get('thumb') or details.get('thumbnail') or art['poster']
        art['icon'] = art['poster']
        art['fanart'] = art.get('fanart') or details.get('fanart') or ''
        label = title
        if media == 'episode' and details.get('showtitle'):
            label = '%s · S%02d E%02d · %s' % (details['showtitle'], details.get('season', 0), details.get('episode', 0), title)
        if progress:
            pos, duration = progress
            if duration > 0:
                label += ' (%s%%)' % min(100, max(0, round(100 * pos / duration)))
        li = xbmcgui.ListItem(label=label)
        li.setArt({k: v for k, v in art.items() if v})
        tag = li.getVideoInfoTag()
        tag.setMediaType(media)
        tag.setDbId(int(mid))
        tag.setTitle(details.get('title') or title)
        tag.setPlot(details.get('plot') or '')
        if details.get('year'):
            tag.setYear(int(details['year']))
        if details.get('runtime'):
            tag.setDuration(int(details['runtime']))
        if media == 'episode':
            tag.setTvShowTitle(details.get('showtitle') or '')
            tag.setSeason(int(details.get('season', 0)))
            tag.setEpisode(int(details.get('episode', 0)))
        if progress:
            pos, duration = progress
            tag.setResumePoint(float(pos), float(duration))
            li.setProperty('ResumeTime', str(pos))
            li.setProperty('TotalTime', str(duration))
            if duration > 0:
                li.setProperty('PercentPlayed', str(min(100, max(0, round(100 * pos / duration)))))
        return li
