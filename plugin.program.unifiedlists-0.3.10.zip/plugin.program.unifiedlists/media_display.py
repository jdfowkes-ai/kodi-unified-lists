"""Library artwork and metadata for normal Kodi directory items."""
import json
import re
import xbmc
import xbmcgui
from tmdb_metadata import TMDbMetadata

SPECS = {
    'movie': ('VideoLibrary.GetMovieDetails', 'movieid', 'moviedetails'),
    'tvshow': ('VideoLibrary.GetTVShowDetails', 'tvshowid', 'tvshowdetails'),
    'episode': ('VideoLibrary.GetEpisodeDetails', 'episodeid', 'episodedetails'),
}

UK_CERTIFICATES = {'u', 'pg', '12', '12a', '15', '18', 'r18', 'uc', 'a', 'aa', 'x'}


def is_uk_certificate(value):
    value = (value or '').strip().lower()
    value = re.sub(r'^(?:united kingdom|bbfc|uk|gb)\s*:?\s*', '', value)
    value = re.sub(r'^rated\s+', '', value)
    return value in UK_CERTIFICATES


class MediaDisplay:
    def __init__(self):
        self.cache = {}
        self.tmdb = TMDbMetadata()

    def details(self, media, mid):
        key = (media, int(mid))
        if key in self.cache:
            return self.cache[key]
        method, id_key, result_key = SPECS[media]
        props = ['title', 'plot', 'art', 'thumbnail', 'fanart', 'mpaa', 'uniqueid']
        props += ['showtitle', 'season', 'episode', 'tvshowid', 'runtime'] if media == 'episode' else ['year']
        if media == 'movie':
            props.append('runtime')
        request = {'jsonrpc': '2.0', 'id': 1, 'method': method,
                   'params': {id_key: int(mid), 'properties': props}}
        try:
            data = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {}).get(result_key, {})
        except (ValueError, TypeError):
            data = {}
        self.cache[key] = data
        return data

    def listitem(self, media, mid, title, progress=None, enrich=False):
        details = self.details(media, mid)
        details_art = details.get('art') if isinstance(details.get('art'), dict) else {}
        art = {k: v for k, v in details_art.items() if v}
        certificate_source = details
        if media == 'episode' and details.get('tvshowid', -1) >= 0:
            parent = self.details('tvshow', details['tvshowid'])
            certificate_source = parent
            parent_art = parent.get('art') if isinstance(parent.get('art'), dict) else {}
            for key in ('poster', 'fanart', 'banner', 'clearlogo', 'landscape'):
                art.setdefault(key, art.get('tvshow.' + key) or parent_art.get(key) or '')
            # Some Kodi libraries have no episode thumbnail. Carry the series
            # artwork down as the episode thumb so skins that display `thumb`
            # (instead of `poster`) still have an image to render.
            parent_thumb = (parent_art.get('thumb') or parent_art.get('poster') or
                            parent_art.get('tvshow.poster') or parent.get('thumbnail') or '')
            if not art.get('thumb'):
                art['thumb'] = (art.get('tvshow.thumb') or details.get('thumbnail') or
                                parent_thumb)
            if not art.get('poster') and parent_thumb:
                art['poster'] = parent_thumb
        lookup_type = 'tv' if media in ('tvshow', 'episode') else 'movie'
        item_certificate = details.get('mpaa') or ''
        parent_certificate = certificate_source.get('mpaa') or ''
        local_certificate = (item_certificate if is_uk_certificate(item_certificate) else
                             parent_certificate if is_uk_certificate(parent_certificate) else
                             item_certificate or parent_certificate)
        remote = {}
        if enrich:
            # An episode title is not a TV-series title. Searching TMDb for an
            # unmatched episode can return an unrelated series with the same
            # name (for example, "The Evidence"). Only enrich episodes when
            # Kodi has supplied the actual parent series title.
            lookup_title = ((details.get('showtitle') or '') if media == 'episode'
                            else details.get('title') or title)
            remote = self.tmdb.lookup(
                lookup_type, certificate_source.get('uniqueid'),
                need_art=not bool(art.get('poster')),
                need_cert=not is_uk_certificate(local_certificate),
                title=lookup_title, year=certificate_source.get('year') or details.get('year'))
        art['poster'] = art.get('poster') or remote.get('poster') or details.get('thumbnail') or 'DefaultVideo.png'
        art['thumb'] = (art.get('thumb') or remote.get('poster') or
                        details.get('thumbnail') or art['poster'])
        art['icon'] = art['poster']
        art['fanart'] = art.get('fanart') or details.get('fanart') or remote.get('fanart') or ''
        # Arctic Fuse uses the wide `landscape` art slot for Continue
        # Watching widgets. Synthetic add-on items often have no Kodi library
        # art, so providing only poster/thumb leaves an empty card even when
        # TMDb successfully returned artwork.
        art['landscape'] = (art.get('landscape') or art.get('fanart') or
                            remote.get('fanart') or art.get('thumb') or art['poster'])
        display_title = title
        if media == 'movie':
            if int(mid) < 0:
                display_title = (remote.get('title') or
                                 self.tmdb.clean_movie_title(details.get('title') or title)[0])
            else:
                display_title = details.get('title') or title
        label = display_title
        if media == 'episode' and details.get('showtitle'):
            label = '%s · S%02d E%02d · %s' % (details['showtitle'], details.get('season', 0), details.get('episode', 0), title)
        if progress:
            pos, duration = progress
            if duration > 0:
                label += ' (%s%%)' % min(100, max(0, round(100 * pos / duration)))
        li = xbmcgui.ListItem(label=label)
        li.setArt({k: v for k, v in art.items() if v})
        tag = li.getVideoInfoTag()
        tag.setMediaType(media)
        if int(mid) > 0:
            tag.setDbId(int(mid))
        tag.setTitle(display_title)
        tag.setPlot(details.get('plot') or remote.get('plot') or '')
        certificate = remote.get('mpaa') or (local_certificate if is_uk_certificate(local_certificate) else '')
        tag.setMpaa(certificate)
        if details.get('year') or remote.get('year'):
            tag.setYear(int(details.get('year') or remote.get('year')))
        if details.get('runtime') or remote.get('runtime'):
            tag.setDuration(int(details.get('runtime') or remote.get('runtime')))
        if media == 'episode':
            tag.setTvShowTitle(details.get('showtitle') or '')
            tag.setSeason(int(details.get('season', 0)))
            tag.setEpisode(int(details.get('episode', 0)))
        if progress:
            pos, duration = progress
            tag.setResumePoint(float(pos), float(duration))
            li.setProperty('ResumeTime', str(pos))
            li.setProperty('TotalTime', str(duration))
            if duration > 0:
                li.setProperty('PercentPlayed', str(min(100, max(0, round(100 * pos / duration)))))
        return li
