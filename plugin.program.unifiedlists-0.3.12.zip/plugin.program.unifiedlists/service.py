import json
import hashlib
import re
import sqlite3
from pathlib import Path
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
from resume_control import ResumeController

PROFILE = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')))
DB = PROFILE / 'lists.db'

def rpc(method, params=None):
    req = {'jsonrpc':'2.0','id':1,'method':method}
    if params is not None: req['params'] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(req))).get('result',{})

def normalise(value):
    return re.sub(r'[^a-z0-9]+', '', str(value or '').casefold())

def normalise_episode_title(value):
    # Kodi add-on streams sometimes prepend an unknown season number, e.g.
    # "0xThe Evidence". Remove only that leading episode marker for matching.
    value = re.sub(r'^\s*(?:\d+|o)\s*[x×]\s*', '', str(value or ''), flags=re.IGNORECASE)
    return normalise(value)

def match_library_episode(item):
    """Resolve an add-on stream to one unambiguous Kodi library episode."""
    showtitle = item.get('showtitle') or item.get('tvshowtitle') or ''
    title = item.get('title') or item.get('label') or ''
    if not title:
        return None
    try:
        season, episode = int(item.get('season') or 0), int(item.get('episode') or 0)
    except (TypeError, ValueError):
        season, episode = 0, 0
    properties = ['title','showtitle','season','episode','tvshowid','file','playcount',
                  'firstaired','plot','art','thumbnail','fanart','runtime','mpaa','year','uniqueid']
    show_id = item.get('tvshowid')
    if showtitle and (not isinstance(show_id, int) or show_id <= 0):
        shows = rpc('VideoLibrary.GetTVShows', {'properties':['title']}).get('tvshows', [])
        matches = [show for show in shows if normalise(show.get('title')) == normalise(showtitle)]
        show_id = matches[0].get('tvshowid') if len(matches) == 1 else None
    if show_id:
        entries = rpc('VideoLibrary.GetEpisodes', {'tvshowid':int(show_id),'properties':properties}).get('episodes', [])
    else:
        # Some add-on streams omit the series title. In that case only search
        # episodes belonging to the user's Start Watching shows. A globally
        # unique episode title can still belong to an unrelated show.
        entries = rpc('VideoLibrary.GetEpisodes', {'properties':properties}).get('episodes', [])
        try:
            con = connect()
            watch_ids = {int(row[0]) for row in con.execute(
                'SELECT kodi_id FROM entries WHERE list_name=? AND media_type=?',
                ('Start Watching', 'tvshow'))}
            con.close()
            entries = [entry for entry in entries
                       if int(entry.get('tvshowid') or -1) in watch_ids]
        except (sqlite3.Error, TypeError, ValueError):
            entries = []
    candidates = []
    if season > 0 and episode > 0:
        candidates = [entry for entry in entries
                      if int(entry.get('season') or 0) == season and int(entry.get('episode') or 0) == episode]
    if not candidates:
        candidates = [entry for entry in entries if normalise_episode_title(entry.get('title')) == normalise_episode_title(title)]
    return candidates[0] if len(candidates) == 1 else None

def reconcile_stream_progress(episode_id, path, title, metadata):
    """Attach synthetic stream rows to a library episode without losing resume."""
    try:
        con = connect()
        existing = con.execute(
            'SELECT title,file_path,position,duration,completed,updated_at '
            'FROM playback_progress WHERE media_type=? AND kodi_id=?',
            ('episode', int(episode_id))
        ).fetchone()
        stale_rows = con.execute(
            "SELECT media_type,kodi_id,title,file_path,position,duration,completed,updated_at "
            "FROM playback_progress WHERE media_type IN ('episode','movie') "
            'AND file_path=? AND NOT (media_type=? AND kodi_id=?) ORDER BY updated_at DESC',
            (path, 'episode', int(episode_id))
        ).fetchall()
        if stale_rows:
            # Keep the furthest confirmed resume position across duplicate
            # identities; use the newest row for its completion state/time.
            candidates = list(stale_rows)
            if existing:
                candidates.append(('episode', int(episode_id), *existing))
            furthest = max(candidates, key=lambda row: (float(row[4] or 0), str(row[7] or '')))
            newest = max(candidates, key=lambda row: str(row[7] or ''))
            if existing:
                con.execute(
                    'UPDATE playback_progress SET title=?,file_path=?,position=?,duration=?,completed=?,updated_at=?,source_metadata=? '
                    'WHERE media_type=? AND kodi_id=?',
                    (title or furthest[2], path, furthest[4], furthest[5], newest[6],
                     newest[7], json.dumps(metadata, ensure_ascii=False), 'episode', int(episode_id))
                )
            else:
                chosen = stale_rows[0]
                con.execute(
                    'UPDATE playback_progress SET media_type=?,kodi_id=?,title=?,file_path=?,position=?,duration=?,completed=?,updated_at=?,source_metadata=? '
                    'WHERE media_type=? AND kodi_id=?',
                    ('episode', int(episode_id), title or furthest[2], path, furthest[4], furthest[5],
                     newest[6], newest[7], json.dumps(metadata, ensure_ascii=False), chosen[0], chosen[1])
                )
            con.execute(
                "DELETE FROM playback_progress WHERE media_type IN ('episode','movie') "
                'AND file_path=? AND NOT (media_type=? AND kodi_id=?)',
                (path, 'episode', int(episode_id))
            )
        con.commit()
        con.close()
    except Exception as exc:
        xbmc.log('Unified Lists could not reconcile episode progress: '+str(exc), xbmc.LOGWARNING)

def identify():
    active = rpc('Player.GetActivePlayers')
    player = next((p for p in active if p.get('type')=='video'),None)
    if not player: return None
    props = ['file','title','showtitle','uniqueid','art','thumbnail','fanart','mpaa','year','runtime','plot','season','episode']
    obj = rpc('Player.GetItem',{'playerid':player['playerid'],'properties':props}).get('item',{})
    media, mid, path = obj.get('type'),obj.get('id'),obj.get('file')
    episode_marker = re.match(r'^\s*(?:\d+|o)\s*[x×]\s*', str(obj.get('title') or obj.get('label') or ''), re.IGNORECASE)
    try:
        has_episode_number = int(obj.get('episode') or 0) > 0
    except (TypeError, ValueError):
        has_episode_number = False
    episode_metadata = bool(obj.get('showtitle') or obj.get('tvshowtitle') or has_episode_number)
    matched_stream_episode = None
    # Some providers mark an episode stream as a movie. Explicit episode
    # fields or Kodi's `0xTitle` convention are stronger evidence than that
    # generic media type, so still resolve it to the Kodi episode library.
    if media == 'movie' and (episode_marker or episode_metadata):
        media = 'episode'
    elif media == 'movie' and str(path or '').lower().startswith('plugin://'):
        # Some add-ons report an episode stream as a movie and give it a
        # positive Kodi ID. Only change its type when its title resolves to one
        # unambiguous episode in a Start Watching series.
        matched_stream_episode = match_library_episode(obj)
        if matched_stream_episode:
            media = 'episode'
    if media not in ('movie','episode'):
        # Some video add-on streams are reported as `unknown` by Kodi. Episode
        # fields still identify TV playback; otherwise treat a video stream as
        # a movie so add-on films can be tracked.
        media = 'episode' if (episode_metadata or episode_marker) else 'movie'
    if not path: return None
    if media == 'episode':
        library_episode = matched_stream_episode or match_library_episode(obj)
        if library_episode:
            # Keep Umbrella's playable stream path while using the matching
            # library identity and metadata for stable progress and artwork.
            obj.update(library_episode)
            mid = library_episode.get('episodeid', obj.get('id'))
            obj['id'] = mid
            obj['file'] = path
            metadata = {key: obj[key] for key in ('title','showtitle','tvshowtitle','uniqueid','art','thumbnail','fanart','mpaa','year','runtime','plot','season','episode','tvshowid') if key in obj}
            reconcile_stream_progress(mid, path, obj.get('title') or '', metadata)
    # Library items keep their real Kodi ID. Add-on streams often have no
    # VideoLibrary ID, so key them by TMDb ID, falling back to their file URL.
    if not isinstance(mid, int) or mid <= 0:
        uniqueid = obj.get('uniqueid') or {}
        tmdb = uniqueid.get('tmdb') or uniqueid.get('themoviedb') if isinstance(uniqueid, dict) else uniqueid
        identity = 'tmdb:' + str(tmdb) if str(tmdb or '').isdigit() else 'path:' + str(path)
        digest = int(hashlib.sha256((media + ':' + identity).encode('utf-8')).hexdigest()[:15], 16)
        mid = -(digest or 1)
    metadata = {key: obj[key] for key in ('title','showtitle','tvshowtitle','uniqueid','art','thumbnail','fanart','mpaa','year','runtime','plot','season','episode','tvshowid') if key in obj}
    return (media,mid,obj.get('title') or obj.get('label') or 'Untitled',path,metadata)

def connect():
    PROFILE.mkdir(parents=True,exist_ok=True)
    con = sqlite3.connect(str(DB),timeout=10)
    con.execute('CREATE TABLE IF NOT EXISTS playback_progress (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL, completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, source_metadata TEXT NOT NULL DEFAULT \'{}\', PRIMARY KEY(media_type,kodi_id))')
    columns = {row[1] for row in con.execute('PRAGMA table_info(playback_progress)')}
    if 'source_metadata' not in columns:
        con.execute("ALTER TABLE playback_progress ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
    con.commit()
    return con

class Tracker(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.resume = ResumeController(DB, lambda: xbmcgui.Dialog().notification('Unified Lists', 'Resume failed; your saved position has been kept', xbmcgui.NOTIFICATION_WARNING, 5000))
        self.av_ready = False
        self.reset()
    def reset(self):
        self.item=None
        self.first=None
        self.position=None
        self.duration=0
        self.last_saved=None
        self.watched_marked=False
    def onAVStarted(self):
        self.reset()
        self.resume.reset()
        self.av_ready = True
    def onPlayBackStopped(self):
        self.save()
        self.resume.stop()
        self.av_ready = False
        self.reset()
    def onPlayBackEnded(self):
        self.save(ended=True)
        self.resume.stop()
        self.av_ready = False
        self.reset()
    def save(self,ended=False):
        if self.resume.failed: return
        if self.item is None or self.position is None: return
        media,mid,title,path,metadata=self.item
        complete=bool(ended or (self.duration>0 and self.position/self.duration>=.9))
        if not complete and (self.first is None or self.position-self.first<30): return
        try:
            con=connect()
            con.execute('INSERT INTO playback_progress (media_type,kodi_id,title,file_path,position,duration,completed,updated_at,source_metadata) VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?) ON CONFLICT(media_type,kodi_id) DO UPDATE SET title=excluded.title,file_path=excluded.file_path,position=excluded.position,duration=excluded.duration,completed=excluded.completed,updated_at=CURRENT_TIMESTAMP,source_metadata=excluded.source_metadata',(media,mid,title,path,self.position,self.duration,int(complete),json.dumps(metadata, ensure_ascii=False)))
            if complete and media=='movie':
                con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',('Start Watching',media,mid))
            con.commit();con.close()
            self.last_saved=self.position
            if complete and media == 'episode' and mid > 0 and not self.watched_marked:
                self.watched_marked = self.mark_episode_watched(mid)
        except Exception as exc:
            xbmc.log('Unified Lists database error: '+str(exc),xbmc.LOGERROR)

    @staticmethod
    def mark_episode_watched(episode_id):
        """Preserve Kodi library watched state after confirmed full playback."""
        try:
            current = rpc('VideoLibrary.GetEpisodeDetails', {
                'episodeid': int(episode_id), 'properties': ['playcount']
            }).get('episodedetails', {})
            if int(current.get('playcount') or 0) > 0:
                return True
            request = {'jsonrpc':'2.0','id':1,'method':'VideoLibrary.SetEpisodeDetails',
                       'params':{'episodeid':int(episode_id),'playcount':1}}
            response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            return not bool(response.get('error'))
        except Exception as exc:
            xbmc.log('Unified Lists could not update episode watched state: '+str(exc),xbmc.LOGWARNING)
            return False
    def tick(self):
        if not self.av_ready or not self.isPlayingVideo(): return
        if self.item is None:
            self.item=identify()
            if self.item is None: return
        try:
            pos=float(self.getTime())
            duration=float(self.getTotalTime())
        except Exception: return
        if self.resume.tick(self, self.item, pos, duration):
            self.first = None
            self.position = None
            return
        if self.first is None: self.first=pos
        self.position=pos
        self.duration=duration
        if self.last_saved is None or pos-self.last_saved>=10: self.save()

monitor=xbmc.Monitor()
tracker=Tracker()
while not monitor.abortRequested():
    try: tracker.tick()
    except Exception as exc: xbmc.log('Unified Lists tracking: '+str(exc),xbmc.LOGERROR)
    monitor.waitForAbort(1)
