import sys
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlencode, parse_qs
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PARAMS = {k: v[0] for k, v in parse_qs(sys.argv[2][1:]).items()}
DB_PATH = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))) / 'lists.db'
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


def db():
    con = sqlite3.connect(str(DB_PATH))
    con.execute('CREATE TABLE IF NOT EXISTS entries (list_name TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, PRIMARY KEY (list_name, media_type, kodi_id))')
    con.commit()
    return con


def url(**kwargs):
    return BASE + '?' + urlencode(kwargs)


def item(label, target, folder=True, menu=None):
    li = xbmcgui.ListItem(label=label)
    if menu:
        li.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, target, li, folder)


def library(media):
    method = 'VideoLibrary.GetMovies' if media == 'movie' else 'VideoLibrary.GetTVShows'
    key = 'movies' if media == 'movie' else 'tvshows'
    id_key = 'movieid' if media == 'movie' else 'tvshowid'
    import json
    request = {'jsonrpc': '2.0', 'method': method, 'params': {'properties': ['title'], 'sort': {'method': 'title'}}, 'id': 1}
    result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    for entry in result.get('result', {}).get(key, []):
        mid = entry[id_key]
        title = entry.get('title', str(mid))
        menu = [(f'Add to {name}', 'RunPlugin(' + url(action='add', list=name, media=media, mid=mid, title=title) + ')') for name in ('Start Watching', 'Watch Later', 'Favourites')]
        item(title, url(action='play' if media == 'movie' else 'details', media=media, mid=mid), False, menu)


def show_list(name):
    con = db()
    for media, mid, title in con.execute('SELECT media_type, kodi_id, title FROM entries WHERE list_name=? ORDER BY title', (name,)):
        menu = [('Remove from list', 'RunPlugin(' + url(action='remove', list=name, media=media, mid=mid) + ')')]
        item(title, url(action='play' if media == 'movie' else 'details', media=media, mid=mid), False, menu)
    con.close()


def change(add):
    name, media, mid = PARAMS.get('list', ''), PARAMS.get('media', ''), PARAMS.get('mid', '')
    if name not in ('Start Watching', 'Watch Later', 'Favourites') or media not in ('movie', 'tvshow') or not mid.isdigit():
        return
    con = db()
    if add:
        con.execute('INSERT OR REPLACE INTO entries VALUES (?, ?, ?, ?)', (name, media, int(mid), PARAMS.get('title', 'Untitled')))
    else:
        con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?', (name, media, int(mid)))
    con.commit()
    con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'List updated', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def play_library_movie(mid):
    """Play the actual Kodi library file, rather than navigating to its folder."""
    request = {
        'jsonrpc': '2.0', 'id': 1,
        'method': 'VideoLibrary.GetMovieDetails',
        'params': {'movieid': int(mid), 'properties': ['file', 'title']}
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        details = response.get('result', {}).get('moviedetails', {})
        path = details.get('file', '')
        if not path:
            raise ValueError('Movie has no playable library file')
        xbmc.Player().play(path)
    except Exception as exc:
        xbmc.log('Unified Lists: unable to play library movie: ' + str(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch movie', xbmcgui.NOTIFICATION_ERROR, 4000)



def continue_watching():
    con = db()
    con.execute("CREATE TABLE IF NOT EXISTS playback_progress (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL, completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(media_type,kodi_id))")
    for media, mid, title, path, pos, dur in con.execute("SELECT media_type,kodi_id,title,file_path,position,duration FROM playback_progress WHERE completed=0 AND position>=30 ORDER BY updated_at DESC").fetchall():
        pct = round(100*pos/dur) if dur else 0
        li = xbmcgui.ListItem(label=f'{title} ({pct}%)')
        li.setProperty('ResumeTime', str(pos))
        li.setProperty('TotalTime', str(dur))
        li.addContextMenuItems([('Play from beginning', 'RunPlugin('+url(action='resume',media=media,mid=mid,start='0')+')')])
        xbmcplugin.addDirectoryItem(HANDLE,url(action='resume',media=media,mid=mid),li,False)
    con.close()


def resume_playback():
    """Start the saved stream and seek only after its playback clock is advancing."""
    media, mid = PARAMS.get('media', ''), PARAMS.get('mid', '')
    if media not in ('movie', 'episode') or not mid.isdigit():
        return
    con = db()
    try:
        row = con.execute(
            'SELECT file_path,position FROM playback_progress WHERE media_type=? AND kodi_id=?',
            (media, int(mid))
        ).fetchone()
    finally:
        con.close()
    if not row:
        return
    path, position = row
    if not path:
        return
    if PARAMS.get('start') == '0':
        position = 0

    player = xbmc.Player()
    monitor = xbmc.Monitor()
    try:
        player.play(path)
    except Exception as exc:
        xbmc.log('Unified Lists: playback launch failed: ' + str(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to start stream', xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    # Streams may report isPlayingVideo() before they can safely accept a seek.
    # Wait for a moving playback clock, then allow additional time for buffering.
    previous_time = None
    moving_ticks = 0
    ready_ticks = 0
    for attempt in range(120):
        if monitor.abortRequested():
            return
        if not player.isPlayingVideo():
            previous_time = None
            moving_ticks = 0
            ready_ticks = 0
        else:
            try:
                current_time = float(player.getTime())
            except Exception:
                current_time = None
            if current_time is not None and previous_time is not None and current_time > previous_time + 0.1:
                moving_ticks += 1
            elif current_time is not None and previous_time is not None and current_time < previous_time - 1:
                moving_ticks = 0
            previous_time = current_time
            if moving_ticks >= 3:
                ready_ticks += 1
                if ready_ticks >= 4:
                    if position > 0:
                        try:
                            player.seekTime(float(position))
                            xbmc.log('Unified Lists: requested resume seek to ' + str(position), xbmc.LOGINFO)
                        except Exception as exc:
                            xbmc.log('Unified Lists: resume seek failed: ' + str(exc), xbmc.LOGWARNING)
                            xbmcgui.Dialog().notification('Unified Lists', 'Resume seek failed', xbmcgui.NOTIFICATION_WARNING, 3000)
                    return
        if monitor.waitForAbort(0.5):
            return
    xbmc.log('Unified Lists: stream did not become ready for resume seek', xbmc.LOGWARNING)
    xbmcgui.Dialog().notification('Unified Lists', 'Resume not available for this stream', xbmcgui.NOTIFICATION_WARNING, 3500)

def main():
    action = PARAMS.get('action', '')
    if action == 'continue':
        continue_watching()
    elif action == 'resume':
        resume_playback()
    elif action == 'library':
        library(PARAMS.get('media', 'movie'))
    elif action == 'list':
        show_list(PARAMS.get('list', ''))
    elif action in ('add', 'remove'):
        change(action == 'add')
    elif action == 'play':
        mid = PARAMS.get('mid', '')
        if PARAMS.get('media') == 'movie' and mid.isdigit():
            play_library_movie(mid)
    elif action == 'details':
        media, mid = PARAMS.get('media', ''), PARAMS.get('mid', '')
        if mid.isdigit() and media in ('movie', 'tvshow'):
            xbmc.executebuiltin('ActivateWindow(Videos,videodb://' + ('movies/titles/' if media == 'movie' else 'tvshows/titles/') + str(mid) + ',return)')
    else:
        item('Continue Watching', url(action='continue'))
        item('Start Watching', url(action='list', list='Start Watching'))
        item('Watch Later', url(action='list', list='Watch Later'))
        item('Favourites', url(action='list', list='Favourites'))
        item('Browse Kodi Movies', url(action='library', media='movie'))
        item('Browse Kodi TV Shows', url(action='library', media='tvshow'))
    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    main()
