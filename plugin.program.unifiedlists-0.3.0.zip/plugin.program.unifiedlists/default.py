import sys
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlencode, parse_qs
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from media_display import MediaDisplay

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PARAMS = {k: v[0] for k, v in parse_qs(sys.argv[2][1:]).items()}
DB_PATH = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))) / 'lists.db'
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
DISPLAY = MediaDisplay()


def db():
    con = sqlite3.connect(str(DB_PATH))
    con.execute('CREATE TABLE IF NOT EXISTS entries (list_name TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, PRIMARY KEY (list_name, media_type, kodi_id))')
    con.execute("CREATE TABLE IF NOT EXISTS playback_progress (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL, completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, source_metadata TEXT NOT NULL DEFAULT '{}', PRIMARY KEY(media_type,kodi_id))")
    columns = {row[1] for row in con.execute('PRAGMA table_info(playback_progress)')}
    if 'source_metadata' not in columns:
        con.execute("ALTER TABLE playback_progress ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
    con.commit()
    return con


def url(**kwargs):
    return BASE + '?' + urlencode(kwargs)


def item(label, target, folder=True, menu=None, media=None, mid=None, progress=None):
    li = DISPLAY.listitem(media, mid, label, progress) if media else xbmcgui.ListItem(label=label)
    if menu:
        li.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, target, li, folder)


def movie_progress(mid):
    con = db()
    try:
        row = con.execute('SELECT position,duration FROM playback_progress WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30', ('movie', int(mid))).fetchone()
        return row
    finally:
        con.close()


def library(media):
    xbmcplugin.setContent(HANDLE, 'movies' if media == 'movie' else 'tvshows')
    method = 'VideoLibrary.GetMovies' if media == 'movie' else 'VideoLibrary.GetTVShows'
    key = 'movies' if media == 'movie' else 'tvshows'
    id_key = 'movieid' if media == 'movie' else 'tvshowid'
    import json
    request = {'jsonrpc': '2.0', 'method': method, 'params': {'properties': ['title', 'plot', 'year', 'art', 'thumbnail', 'fanart', 'mpaa', 'runtime'], 'sort': {'method': 'title'}}, 'id': 1}
    result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    for entry in result.get('result', {}).get(key, []):
        mid = entry[id_key]
        DISPLAY.cache[(media, int(mid))] = entry
        title = entry.get('title', str(mid))
        menu = [(f'Add to {name}', 'RunPlugin(' + url(action='add', list=name, media=media, mid=mid, title=title) + ')') for name in ('Start Watching', 'Watch Later', 'Favourites')]
        item(title, url(action='play', media=media, mid=mid) if media == 'movie' else 'videodb://tvshows/titles/%s/' % mid, media == 'tvshow', menu, media=media, mid=mid, progress=movie_progress(mid) if media == 'movie' else None)


def show_list(name):
    xbmcplugin.setContent(HANDLE, "videos")
    con = db()
    for media, mid, title in con.execute('SELECT media_type, kodi_id, title FROM entries WHERE list_name=? ORDER BY title', (name,)):
        menu = [('Remove from list', 'RunPlugin(' + url(action='remove', list=name, media=media, mid=mid) + ')')]
        if media == 'movie':
            menu.append(('Play from beginning', 'RunPlugin(' + url(action='play', media=media, mid=mid, start='0') + ')'))
        item(title, url(action='play', media=media, mid=mid) if media == 'movie' else 'videodb://tvshows/titles/%s/' % mid, media == 'tvshow', menu, media=media, mid=mid, progress=movie_progress(mid) if media == 'movie' else None)
    con.close()


def change(add):
    name, media, mid = PARAMS.get('list', ''), PARAMS.get('media', ''), PARAMS.get('mid', '')
    if name not in ('Start Watching', 'Watch Later', 'Favourites') or media not in ('movie', 'tvshow') or not mid.isdigit():
        return
    con = db()
    if add:
        con.execute('INSERT OR REPLACE INTO entries VALUES (?, ?, ?, ?)', (name, media, int(mid), PARAMS.get('title', 'Untitled')))
    else:
        con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?', (name, media, int(mid)))
    con.commit()
    con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'List updated', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def play_library_movie(mid):
    """Launch the library file and apply local resume through the service."""
    request_id = None
    from resume_control import queue, clear
    request = {
        'jsonrpc': '2.0', 'id': 1,
        'method': 'VideoLibrary.GetMovieDetails',
        'params': {'movieid': int(mid), 'properties': ['file', 'title']}
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        details = response.get('result', {}).get('moviedetails', {})
        path = details.get('file', '')
        if not path:
            raise ValueError('Movie has no playable library file')
        con = db()
        try:
            row = con.execute('SELECT position FROM playback_progress WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30', ('movie', int(mid))).fetchone()
        finally:
            con.close()
        position = float(row[0]) if row and PARAMS.get('start') != '0' else 0.0
        request_id = queue(DB_PATH, 'movie', int(mid), position)
        xbmc.Player().play(path)
    except Exception as exc:
        if request_id:
            clear(DB_PATH, request_id)
        xbmc.log('Unified Lists: unable to play library movie: ' + str(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch movie', xbmcgui.NOTIFICATION_ERROR, 4000)



def continue_watching():
    from next_episode import directory_rows
    xbmcplugin.setContent(HANDLE, 'videos')
    con = db()
    con.row_factory = sqlite3.Row
    try:
        rows = [dict(row) for row in con.execute('SELECT * FROM playback_progress ORDER BY updated_at DESC').fetchall()]
    finally:
        con.close()
    for row in rows:
        try:
            metadata = json.loads(row.get('source_metadata') or '{}')
        except (ValueError, TypeError):
            metadata = {}
        # Non-library playback uses a negative synthetic ID. Seed the display
        # cache with metadata Kodi reports for the playing add-on stream.
        if row['kodi_id'] < 0 and isinstance(metadata, dict):
            DISPLAY.cache[(row['media_type'], row['kodi_id'])] = metadata
    for row in directory_rows(rows, DISPLAY):
        media, mid, title = row['media_type'], row['kodi_id'], row['title']
        pos, dur = row['position'], row['duration']
        progress = (pos, dur) if pos >= 30 else None
        li = DISPLAY.listitem(media, mid, title, progress, enrich=True)
        if row['next_episode'] and not progress:
            li.setLabel(li.getLabel() + ' · Next episode')
        action = 'episode_play' if row['next_episode'] else 'resume'
        menu = [('Play from beginning', 'RunPlugin('+url(action=action,media=media,mid=mid,start='0')+')')]
        if media == 'episode':
            menu.append(('Choose season / episode', 'RunPlugin('+url(action='choose_episode',mid=mid)+')'))
        li.addContextMenuItems(menu)
        xbmcplugin.addDirectoryItem(HANDLE, url(action=action,media=media,mid=mid), li, False)


def choose_episode(mid):
    from episode_picker import choose
    from next_episode import episodes
    show_id = DISPLAY.details('episode', int(mid)).get('tvshowid', -1)
    if show_id < 0:
        xbmcgui.Dialog().ok('Choose season / episode', 'This episode could not be matched to a Kodi library show.')
        return
    con = db()
    con.row_factory = sqlite3.Row
    try:
        progress = {r['kodi_id']: dict(r) for r in con.execute("SELECT * FROM playback_progress WHERE media_type='episode'").fetchall()}
    finally:
        con.close()
    selected = choose(xbmcgui.Dialog(), episodes(show_id), progress)
    if selected is not None:
        play_library_episode(selected)


def play_library_episode(mid):
    request_id = None
    from resume_control import queue, clear
    try:
        request = {'jsonrpc': '2.0', 'id': 1, 'method': 'VideoLibrary.GetEpisodeDetails',
                   'params': {'episodeid': int(mid), 'properties': ['file']}}
        details = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {}).get('episodedetails', {})
        path = details.get('file')
        if not path:
            raise ValueError('Episode has no playable library file')
        con = db()
        try:
            row = con.execute('SELECT position FROM playback_progress WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30', ('episode', int(mid))).fetchone()
        finally:
            con.close()
        position = float(row[0]) if row and PARAMS.get('start') != '0' else 0.0
        request_id = queue(DB_PATH, 'episode', int(mid), position)
        xbmc.Player().play(path)
    except Exception:
        if request_id:
            clear(DB_PATH, request_id)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch episode', xbmcgui.NOTIFICATION_ERROR, 4000)


def resume_playback():
    media, mid = PARAMS.get('media',''), PARAMS.get('mid','')
    if media not in ('movie','episode') or not mid.lstrip('-').isdigit(): return
    mid = int(mid)
    con=db()
    row=con.execute('SELECT file_path,position FROM playback_progress WHERE media_type=? AND kodi_id=?',(media,mid)).fetchone()
    con.close()
    if not row: return
    path, position = row
    if PARAMS.get('start')=='0': position=0
    from resume_control import queue, clear
    request_id = queue(DB_PATH, media, mid, float(position))
    try:
        xbmc.Player().play(path)
    except Exception:
        clear(DB_PATH, request_id)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch movie', xbmcgui.NOTIFICATION_ERROR, 4000)

def main():
    action = PARAMS.get('action', '')
    if action == 'trakt_authorise':
        from trakt_auth import authorise
        authorise(ADDON)
    elif action == 'trakt_disconnect':
        from trakt_auth import disconnect
        disconnect(ADDON)
    elif action in ('certificate_icons', 'certificate_restore'):
        from certificate_icons import run
        run(ADDON, restore=action == 'certificate_restore')
    elif action == 'settings':
        ADDON.openSettings()
    elif action == 'continue':
        continue_watching()
    elif action == 'choose_episode':
        mid = PARAMS.get('mid', '')
        if mid.isdigit():
            choose_episode(mid)
    elif action == 'episode_play':
        mid = PARAMS.get('mid', '')
        if mid.isdigit():
            play_library_episode(mid)
    elif action == 'resume':
        resume_playback()
    elif action == 'library':
        library(PARAMS.get('media', 'movie'))
    elif action == 'list':
        show_list(PARAMS.get('list', ''))
    elif action in ('add', 'remove'):
        change(action == 'add')
    elif action == 'play':
        mid = PARAMS.get('mid', '')
        if PARAMS.get('media') == 'movie' and mid.isdigit():
            play_library_movie(mid)
    elif action == 'details':
        media, mid = PARAMS.get('media', ''), PARAMS.get('mid', '')
        if mid.isdigit() and media in ('movie', 'tvshow'):
            xbmc.executebuiltin('ActivateWindow(Videos,videodb://' + ('movies/titles/' if media == 'movie' else 'tvshows/titles/') + str(mid) + '/,return)')
    else:
        from trakt_auth import connected
        item('Authorise Trakt' + (' (connected)' if connected(ADDON) else ''), url(action='trakt_authorise'), False)
        if connected(ADDON):
            item('Disconnect Trakt', url(action='trakt_disconnect'), False)
        item('Settings', url(action='settings'), False)
        item('Enable UK certificate icons', url(action='certificate_icons'), False)
        item('Restore original certificate display', url(action='certificate_restore'), False)
        item('Continue Watching', url(action='continue'))
        item('Start Watching', url(action='list', list='Start Watching'))
        item('Watch Later', url(action='list', list='Watch Later'))
        item('Favourites', url(action='list', list='Favourites'))
        item('Browse Kodi Movies', url(action='library', media='movie'))
        item('Browse Kodi TV Shows', url(action='library', media='tvshow'))
    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    main()
