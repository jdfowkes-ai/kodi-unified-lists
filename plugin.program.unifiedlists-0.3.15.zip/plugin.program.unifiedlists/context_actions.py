"""Four local actions for the currently selected Kodi video item."""
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON = xbmcaddon.Addon()
PROFILE = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
DB_PATH = PROFILE / 'lists.db'
ACTION = sys.argv[1] if len(sys.argv) > 1 else ''


def safe_call(obj, name, default='', *args):
    try:
        value = getattr(obj, name)(*args)
        return value if value is not None else default
    except Exception:
        return default


def selected_item():
    item = getattr(sys, 'listitem', None)
    if item is None:
        return None
    path = safe_call(item, 'getPath')
    if not path:
        return None
    tag = safe_call(item, 'getVideoInfoTag', None)
    if tag is None:
        return None

    title = safe_call(tag, 'getTitle') or safe_call(item, 'getLabel') or 'Untitled'
    media = str(safe_call(tag, 'getMediaType') or '').lower()
    if media not in ('movie', 'episode', 'tvshow'):
        show = safe_call(tag, 'getTvShowTitle')
        episode = safe_call(tag, 'getEpisode', 0)
        media = 'episode' if show or episode else 'movie'

    tmdb_id = safe_call(tag, 'getUniqueID', '', 'tmdb')
    try:
        artwork = item.getArt() or {}
    except Exception:
        artwork = {}
    artwork = artwork if isinstance(artwork, dict) else {}
    metadata = {
        'title': title,
        'showtitle': safe_call(tag, 'getTvShowTitle'),
        'year': safe_call(tag, 'getYear', 0),
        'season': safe_call(tag, 'getSeason', 0),
        'episode': safe_call(tag, 'getEpisode', 0),
        'plot': safe_call(tag, 'getPlot'),
        'thumbnail': artwork.get('thumb') or artwork.get('poster') or '',
        'art': artwork,
        'fanart': artwork.get('fanart') or artwork.get('landscape') or '',
        'uniqueid': {'tmdb': str(tmdb_id)} if str(tmdb_id).isdigit() else {},
    }
    try:
        is_playable = item.getProperty('IsPlayable').lower() == 'true'
    except Exception:
        is_playable = False
    is_folder = media == 'tvshow' and not is_playable
    identity = 'tmdb:' + str(tmdb_id) if str(tmdb_id).isdigit() else 'path:' + path
    digest = int(hashlib.sha256((media + ':' + identity).encode('utf-8')).hexdigest()[:15], 16)
    return item, media, -(digest or 1), title, path, is_folder, metadata


def ensure_schema(con):
    con.execute('CREATE TABLE IF NOT EXISTS entries (list_name TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, PRIMARY KEY (list_name, media_type, kodi_id))')
    con.execute('CREATE TABLE IF NOT EXISTS external_list_items (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, path TEXT NOT NULL, is_folder INTEGER NOT NULL DEFAULT 0, metadata_json TEXT NOT NULL DEFAULT \'{}\', PRIMARY KEY(media_type,kodi_id))')


def toggle_list(list_name):
    selected = selected_item()
    if selected is None:
        xbmcgui.Dialog().notification('Unified Lists', 'This item has no playable Kodi path', xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    _item, media, mid, title, path, is_folder, metadata = selected
    PROFILE.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), timeout=10)
    try:
        ensure_schema(con)
        existing = con.execute('SELECT 1 FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                               (list_name, media, mid)).fetchone()
        if existing:
            con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                        (list_name, media, mid))
            con.execute('DELETE FROM external_list_items WHERE media_type=? AND kodi_id=? '
                        'AND NOT EXISTS (SELECT 1 FROM entries WHERE media_type=? AND kodi_id=?)',
                        (media, mid, media, mid))
            message = 'Removed from ' + list_name
        else:
            con.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?)',
                        (list_name, media, mid, title))
            con.execute('INSERT OR REPLACE INTO external_list_items VALUES (?,?,?,?,?)',
                        (media, mid, path, int(is_folder), json.dumps(metadata, ensure_ascii=False)))
            message = 'Added to ' + list_name
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', message, xbmcgui.NOTIFICATION_INFO, 2500)


def play_resume():
    selected = selected_item()
    if selected is None:
        return
    item, _media, _mid, _title, path, is_folder, _metadata = selected
    if is_folder:
        xbmc.executebuiltin('Container.Update("%s")' % path.replace('"', '\\"'))
        return
    xbmc.Player().play(path, item)


def main():
    if ACTION == 'play_resume':
        play_resume()
    elif ACTION == 'info':
        xbmc.executebuiltin('Action(Info)')
    elif ACTION == 'watch_later':
        toggle_list('Watch Later')
    elif ACTION == 'favourites':
        toggle_list('Favourites')


if __name__ == '__main__':
    main()
