import sys
import json
import re
import sqlite3
from pathlib import Path
from urllib.parse import urlencode, parse_qs
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from media_display import MediaDisplay

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PARAMS = {k: v[0] for k, v in parse_qs(sys.argv[2][1:]).items()}
DB_PATH = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))) / 'lists.db'
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
DISPLAY = MediaDisplay()


def db():
    con = sqlite3.connect(str(DB_PATH))
    con.execute('CREATE TABLE IF NOT EXISTS entries (list_name TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, PRIMARY KEY (list_name, media_type, kodi_id))')
    con.execute("CREATE TABLE IF NOT EXISTS playback_progress (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL, completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, source_metadata TEXT NOT NULL DEFAULT '{}', PRIMARY KEY(media_type,kodi_id))")
    columns = {row[1] for row in con.execute('PRAGMA table_info(playback_progress)')}
    if 'source_metadata' not in columns:
        con.execute("ALTER TABLE playback_progress ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
    con.execute('CREATE TABLE IF NOT EXISTS external_list_items (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, path TEXT NOT NULL, is_folder INTEGER NOT NULL DEFAULT 0, metadata_json TEXT NOT NULL DEFAULT \'{}\', PRIMARY KEY(media_type,kodi_id))')
    con.commit()
    return con


def url(**kwargs):
    return BASE + '?' + urlencode(kwargs)


def item(label, target, folder=True, menu=None, media=None, mid=None, progress=None):
    li = DISPLAY.listitem(media, mid, label, progress) if media else xbmcgui.ListItem(label=label)
    if menu:
        li.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, target, li, folder)


def movie_progress(mid):
    con = db()
    try:
        row = con.execute('SELECT position,duration FROM playback_progress WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30', ('movie', int(mid))).fetchone()
        return row
    finally:
        con.close()


def repair_saved_episode_matches(rows):
    """Repair saved add-on episode rows using the user's Start Watching shows."""
    relevant = []
    for row in rows:
        if row.get('media_type') not in ('episode', 'movie'):
            continue
        try:
            meta = json.loads(row.get('source_metadata') or '{}')
        except (ValueError, TypeError):
            meta = {}
        # Kodi sometimes classifies the stream as a movie and stores its
        # `0xEpisode title` only in the source metadata, not the row label.
        marker_titles = [row.get('title') or '']
        if isinstance(meta, dict):
            marker_titles.append(meta.get('title') or '')
        marker = any(re.match(r'^\s*(?:\d+|o)\s*[x×]\s*', str(value), re.IGNORECASE)
                     for value in marker_titles)
        synthetic_movie = row.get('media_type') == 'movie' and int(row.get('kodi_id') or 0) < 0
        umbrella_movie = (row.get('media_type') == 'movie' and
                          str(row.get('file_path') or '').lower().startswith('plugin://'))
        if row.get('media_type') == 'episode' or marker or synthetic_movie or (isinstance(meta, dict) and
                ('season' in meta or 'episode' in meta or meta.get('showtitle') or meta.get('tvshowtitle'))) or umbrella_movie:
            relevant.append((row, meta if isinstance(meta, dict) else {}))
    if not relevant:
        return rows

    con = db()
    con.row_factory = sqlite3.Row
    try:
        watch_ids = {int(r[0]) for r in con.execute(
            'SELECT kodi_id FROM entries WHERE list_name=? AND media_type=?',
            ('Start Watching', 'tvshow'))}
        if not watch_ids:
            return rows
        request = {'jsonrpc':'2.0', 'id':1, 'method':'VideoLibrary.GetEpisodes',
                   'params':{'properties':['title','showtitle','season','episode','tvshowid',
                                          'playcount','firstaired','plot',
                                          'art','thumbnail','fanart','runtime','uniqueid']}}
        try:
            episodes = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {}).get('episodes', [])
        except (ValueError, TypeError):
            episodes = []
        episodes = [e for e in episodes if int(e.get('tvshowid') or -1) in watch_ids]

        def norm(value):
            value = re.sub(r'^\s*(?:\d+|o)\s*[x×]\s*', '', str(value or ''), flags=re.IGNORECASE)
            return re.sub(r'[^a-z0-9]+', '', value.casefold())

        changed = False
        for row, meta in relevant:
            title = meta.get('title') or row.get('title') or ''
            series_title = meta.get('showtitle') or meta.get('tvshowtitle') or ''
            episode_pool = episodes
            if series_title:
                series_key = norm(series_title)
                episode_pool = [e for e in episodes if norm(e.get('showtitle')) == series_key]
                # If Kodi supplied a series name, never attach its episode to
                # another Start Watching show just because the episode title or
                # season/episode numbers happen to match.
            try:
                season, number = int(meta.get('season') or 0), int(meta.get('episode') or 0)
            except (TypeError, ValueError):
                season, number = 0, 0
            candidates = ([e for e in episode_pool if int(e.get('season') or 0) == season and
                           int(e.get('episode') or 0) == number] if season > 0 and number > 0 else [])
            if not candidates:
                keys = {norm(value) for value in (meta.get('title'), row.get('title')) if value}
                candidates = [e for e in episode_pool if norm(e.get('title')) in keys]
            if len(candidates) != 1:
                continue

            episode = candidates[0]
            correct_id = int(episode.get('episodeid') or -1)
            old_id = int(row['kodi_id'])
            if correct_id <= 0 or (row['media_type'] == 'episode' and old_id == correct_id):
                continue
            new_metadata = {k: episode[k] for k in (
                'title','showtitle','tvshowtitle','uniqueid','art','thumbnail','fanart','mpaa','year',
                'runtime','plot','season','episode','tvshowid') if k in episode}
            existing = con.execute(
                'SELECT position,duration,completed,updated_at FROM playback_progress '
                'WHERE media_type=? AND kodi_id=?', ('episode', correct_id)).fetchone()
            if existing:
                farther = (row if float(row['position'] or 0) >= float(existing['position'] or 0)
                           else existing)
                newest = (row if str(row['updated_at']) >= str(existing['updated_at'])
                          else existing)
                con.execute(
                    'UPDATE playback_progress SET title=?,file_path=?,position=?,duration=?,completed=?,updated_at=?,source_metadata=? '
                    'WHERE media_type=? AND kodi_id=?',
                    (episode.get('title') or title, row['file_path'], farther['position'], farther['duration'],
                     newest['completed'], newest['updated_at'], json.dumps(new_metadata, ensure_ascii=False),
                     'episode', correct_id))
                con.execute('DELETE FROM playback_progress WHERE media_type=? AND kodi_id=?',
                            (row['media_type'], old_id))
            else:
                con.execute(
                    'UPDATE playback_progress SET media_type=?,kodi_id=?,title=?,source_metadata=? '
                    'WHERE media_type=? AND kodi_id=?',
                    ('episode', correct_id, episode.get('title') or title,
                     json.dumps(new_metadata, ensure_ascii=False), row['media_type'], old_id))
            row['media_type'] = 'episode'
            row['kodi_id'] = correct_id
            row['title'] = episode.get('title') or title
            row['source_metadata'] = json.dumps(new_metadata, ensure_ascii=False)
            changed = True
        if changed:
            con.commit()
    finally:
        con.close()
    return rows


def repair_saved_movie_matches(rows):
    """Replace unambiguous filename-based movie rows with Kodi movie IDs."""
    candidates = [r for r in rows if r.get('media_type') == 'movie' and int(r.get('kodi_id') or 0) < 0]
    if not candidates:
        return rows
    request = {'jsonrpc':'2.0','id':1,'method':'VideoLibrary.GetMovies',
               'params':{'properties':['title','year','uniqueid','art','thumbnail','fanart',
                                       'plot','mpaa','runtime']}}
    try:
        movies = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {}).get('movies', [])
    except (ValueError, TypeError):
        movies = []
    if not movies:
        return rows

    def normalise(value):
        return re.sub(r'[^a-z0-9]+', '', str(value or '').casefold())

    changed = False
    con = db()
    con.row_factory = sqlite3.Row
    try:
        for row in candidates:
            try:
                meta = json.loads(row.get('source_metadata') or '{}')
            except (ValueError, TypeError):
                meta = {}
            meta = meta if isinstance(meta, dict) else {}
            uniqueid = meta.get('uniqueid') or {}
            tmdb = (uniqueid.get('tmdb') or uniqueid.get('themoviedb')) if isinstance(uniqueid, dict) else ''
            matches = []
            if str(tmdb or '').isdigit():
                matches = [m for m in movies if str((m.get('uniqueid') or {}).get('tmdb') or
                           (m.get('uniqueid') or {}).get('themoviedb') or '') == str(tmdb)]
            if not matches:
                raw = str(meta.get('title') or row.get('title') or '')
                raw = re.sub(r'\.[^.]+$', '', raw)
                # Strip common release suffixes while retaining the movie year
                # for disambiguation (for example, Supergirl.2026.1080p...).
                year_match = re.search(r'(?i)[._\s]+((?:19|20)\d{2})(?=[._\s]+(?:2160p|1080p|720p|480p|blu.?ray|web|hdr|remux|multi))', raw)
                year = int(year_match.group(1)) if year_match else int(meta.get('year') or 0)
                title_part = raw[:year_match.start()] if year_match else raw
                title_part = re.split(r'(?i)[._\s]+(?:2160p|1080p|720p|480p|blu.?ray|web.?dl|web.?rip|remux|hdr|multi)\b', title_part, maxsplit=1)[0]
                key = normalise(title_part)
                matches = [m for m in movies if key and normalise(m.get('title')) == key]
                if year and len(matches) > 1:
                    by_year = [m for m in matches if int(m.get('year') or 0) == year]
                    if by_year:
                        matches = by_year
            if len(matches) != 1:
                continue

            movie = matches[0]
            correct_id = int(movie.get('movieid') or -1)
            old_id = int(row['kodi_id'])
            if correct_id <= 0:
                continue
            metadata = {k: movie[k] for k in (
                'title','uniqueid','art','thumbnail','fanart','plot','mpaa','year','runtime') if k in movie}
            existing = con.execute(
                'SELECT title,file_path,position,duration,completed,updated_at FROM playback_progress '
                'WHERE media_type=? AND kodi_id=?', ('movie', correct_id)).fetchone()
            current = con.execute(
                'SELECT position,duration,completed,updated_at FROM playback_progress '
                'WHERE media_type=? AND kodi_id=?', ('movie', old_id)).fetchone()
            if current is None:
                continue
            if existing:
                progress = current if (float(current['position'] or 0), str(current['updated_at'])) >= \
                                     (float(existing['position'] or 0), str(existing['updated_at'])) else existing
                newest = current if str(current['updated_at']) >= str(existing['updated_at']) else existing
                con.execute(
                    'UPDATE playback_progress SET title=?,file_path=?,position=?,duration=?,completed=?,updated_at=?,source_metadata=? '
                    'WHERE media_type=? AND kodi_id=?',
                    (movie.get('title') or row['title'], row['file_path'], progress['position'],
                     progress['duration'], newest['completed'], newest['updated_at'],
                     json.dumps(metadata, ensure_ascii=False), 'movie', correct_id))
                con.execute('DELETE FROM playback_progress WHERE media_type=? AND kodi_id=?', ('movie', old_id))
            else:
                con.execute(
                    'UPDATE playback_progress SET kodi_id=?,title=?,source_metadata=? WHERE media_type=? AND kodi_id=?',
                    (correct_id, movie.get('title') or row['title'], json.dumps(metadata, ensure_ascii=False), 'movie', old_id))
            row['kodi_id'] = correct_id
            row['title'] = movie.get('title') or row['title']
            row['source_metadata'] = json.dumps(metadata, ensure_ascii=False)
            changed = True
        if changed:
            con.commit()
    finally:
        con.close()
    return rows


def deduplicate_progress_rows(rows):
    """Keep one local resume row per resolved Kodi item."""
    unique = {}
    for row in rows:
        key = (row.get('media_type'), int(row.get('kodi_id') or 0))
        if row.get('media_type') == 'movie':
            try:
                meta = json.loads(row.get('source_metadata') or '{}')
            except (ValueError, TypeError):
                meta = {}
            meta = meta if isinstance(meta, dict) else {}
            movie_title, movie_year = DISPLAY.tmdb.clean_movie_title(
                meta.get('title') or row.get('title'), meta.get('year'))
            movie_key = re.sub(r'[^a-z0-9]+', '', movie_title.casefold())
            # Only collapse separate movie identities when both the cleaned
            # title and year agree; keep same-title remakes distinct.
            if movie_key and movie_year:
                key = ('movie-title-year', movie_key, int(movie_year))
        current = unique.get(key)
        if current is None:
            unique[key] = row
            continue
        newer = row if str(row.get('updated_at') or '') >= str(current.get('updated_at') or '') else current
        farther = row if float(row.get('position') or 0) > float(current.get('position') or 0) else current
        keep = dict(farther)
        keep['completed'] = newer.get('completed', keep.get('completed'))
        keep['updated_at'] = newer.get('updated_at', keep.get('updated_at'))
        unique[key] = keep
    return list(unique.values())


def show_list(name):
    xbmcplugin.setContent(HANDLE, "videos")
    con = db()
    rows = con.execute('SELECT e.media_type,e.kodi_id,e.title,x.path,x.is_folder,x.metadata_json '
                        'FROM entries e LEFT JOIN external_list_items x '
                        'ON x.media_type=e.media_type AND x.kodi_id=e.kodi_id '
                        'WHERE e.list_name=? ORDER BY e.title', (name,)).fetchall()
    for media, mid, title, path, is_folder, metadata_json in rows:
        if path:
            try:
                metadata = json.loads(metadata_json or '{}')
            except (ValueError, TypeError):
                metadata = {}
            if isinstance(metadata, dict):
                DISPLAY.cache[(media, int(mid))] = metadata
            li = DISPLAY.listitem(media, mid, title)
            if not is_folder:
                li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, path, li, bool(is_folder))
            continue
        if media == 'movie':
            target = url(action='play', media=media, mid=mid)
        else:
            target = 'videodb://tvshows/titles/%s/' % mid
        item(title, target, media == 'tvshow', media=media, mid=mid, progress=movie_progress(mid) if media == 'movie' else None)
    con.close()


def change(add):
    name, media, mid = PARAMS.get('list', ''), PARAMS.get('media', ''), PARAMS.get('mid', '')
    if name not in ('Watch Later', 'Favourites') or media not in ('movie', 'tvshow') or not mid.isdigit():
        return
    con = db()
    if add:
        con.execute('INSERT OR REPLACE INTO entries VALUES (?, ?, ?, ?)', (name, media, int(mid), PARAMS.get('title', 'Untitled')))
    else:
        con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?', (name, media, int(mid)))
    con.commit()
    con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'List updated', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def play_library_movie(mid):
    """Launch the library file and apply local resume through the service."""
    request_id = None
    from resume_control import queue, clear
    request = {
        'jsonrpc': '2.0', 'id': 1,
        'method': 'VideoLibrary.GetMovieDetails',
        'params': {'movieid': int(mid), 'properties': ['file', 'title']}
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        details = response.get('result', {}).get('moviedetails', {})
        path = details.get('file', '')
        if not path:
            raise ValueError('Movie has no playable library file')
        con = db()
        try:
            row = con.execute('SELECT position FROM playback_progress WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30', ('movie', int(mid))).fetchone()
        finally:
            con.close()
        position = float(row[0]) if row and PARAMS.get('start') != '0' else 0.0
        request_id = queue(DB_PATH, 'movie', int(mid), position, path)
        xbmc.Player().play(path)
    except Exception as exc:
        if request_id:
            clear(DB_PATH, request_id)
        xbmc.log('Unified Lists: unable to play library movie: ' + str(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch movie', xbmcgui.NOTIFICATION_ERROR, 4000)



def continue_watching():
    from next_episode import directory_rows
    xbmcplugin.setContent(HANDLE, 'videos')
    con = db()
    con.row_factory = sqlite3.Row
    try:
        rows = [dict(row) for row in con.execute('SELECT * FROM playback_progress ORDER BY updated_at DESC').fetchall()]
    finally:
        con.close()
    rows = repair_saved_episode_matches(rows)
    rows = repair_saved_movie_matches(rows)
    rows = deduplicate_progress_rows(rows)
    for row in rows:
        try:
            metadata = json.loads(row.get('source_metadata') or '{}')
        except (ValueError, TypeError):
            metadata = {}
        # Non-library playback uses a negative synthetic ID. Seed the display
        # cache with metadata Kodi reports for the playing add-on stream.
        if row['kodi_id'] < 0 and isinstance(metadata, dict):
            DISPLAY.cache[(row['media_type'], row['kodi_id'])] = metadata
    for row in directory_rows(rows, DISPLAY):
        media, mid, title = row['media_type'], row['kodi_id'], row['title']
        pos, dur = row['position'], row['duration']
        progress = (pos, dur) if pos >= 30 else None
        li = DISPLAY.listitem(media, mid, title, progress, enrich=True)
        if row['next_episode'] and not progress:
            li.setLabel(li.getLabel() + ' · Next episode')
        action = 'episode_play' if row['next_episode'] else 'resume'
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(HANDLE, url(action=action,media=media,mid=mid), li, False)


def choose_episode(mid):
    from episode_picker import choose
    from next_episode import episodes
    show_id = DISPLAY.details('episode', int(mid)).get('tvshowid', -1)
    if show_id < 0:
        xbmcgui.Dialog().ok('Choose season / episode', 'This episode could not be matched to a Kodi library show.')
        return
    con = db()
    con.row_factory = sqlite3.Row
    try:
        progress = {r['kodi_id']: dict(r) for r in con.execute("SELECT * FROM playback_progress WHERE media_type='episode'").fetchall()}
    finally:
        con.close()
    selected = choose(xbmcgui.Dialog(), episodes(show_id), progress)
    if selected is not None:
        play_library_episode(selected)


def play_library_episode(mid):
    request_id = None
    from resume_control import queue, clear
    try:
        request = {'jsonrpc': '2.0', 'id': 1, 'method': 'VideoLibrary.GetEpisodeDetails',
                   'params': {'episodeid': int(mid), 'properties': ['file']}}
        details = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {}).get('episodedetails', {})
        path = details.get('file')
        if not path:
            raise ValueError('Episode has no playable library file')
        con = db()
        try:
            row = con.execute('SELECT position FROM playback_progress WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30', ('episode', int(mid))).fetchone()
        finally:
            con.close()
        position = float(row[0]) if row and PARAMS.get('start') != '0' else 0.0
        request_id = queue(DB_PATH, 'episode', int(mid), position, path)
        xbmc.Player().play(path)
    except Exception:
        if request_id:
            clear(DB_PATH, request_id)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch episode', xbmcgui.NOTIFICATION_ERROR, 4000)


def resume_playback():
    media, mid = PARAMS.get('media',''), PARAMS.get('mid','')
    if media not in ('movie','episode') or not mid.lstrip('-').isdigit(): return
    mid = int(mid)
    con=db()
    row=con.execute('SELECT file_path,position FROM playback_progress WHERE media_type=? AND kodi_id=?',(media,mid)).fetchone()
    con.close()
    if not row: return
    path, position = row
    if PARAMS.get('start')=='0': position=0
    from resume_control import queue, clear
    request_id = queue(DB_PATH, media, mid, float(position), path)
    try:
        xbmc.Player().play(path)
    except Exception:
        clear(DB_PATH, request_id)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch movie', xbmcgui.NOTIFICATION_ERROR, 4000)

def main():
    action = PARAMS.get('action', '')
    if action in ('certificate_icons', 'certificate_restore'):
        from certificate_icons import run
        run(ADDON, restore=action == 'certificate_restore')
    elif action == 'settings':
        ADDON.openSettings()
    elif action == 'continue':
        continue_watching()
    elif action == 'choose_episode':
        mid = PARAMS.get('mid', '')
        if mid.isdigit():
            choose_episode(mid)
    elif action == 'episode_play':
        mid = PARAMS.get('mid', '')
        if mid.isdigit():
            play_library_episode(mid)
    elif action == 'resume':
        resume_playback()
    elif action == 'list':
        show_list(PARAMS.get('list', ''))
    elif action in ('add', 'remove'):
        change(action == 'add')
    elif action == 'play':
        mid = PARAMS.get('mid', '')
        if PARAMS.get('media') == 'movie' and mid.isdigit():
            play_library_movie(mid)
    elif action == 'details':
        media, mid = PARAMS.get('media', ''), PARAMS.get('mid', '')
        if mid.isdigit() and media in ('movie', 'tvshow'):
            xbmc.executebuiltin('ActivateWindow(Videos,videodb://' + ('movies/titles/' if media == 'movie' else 'tvshows/titles/') + str(mid) + '/,return)')
    else:
        item('Settings', url(action='settings'), False)
        item('Enable UK certificate icons', url(action='certificate_icons'), False)
        item('Restore original certificate display', url(action='certificate_restore'), False)
        item('Continue Watching', url(action='continue'))
        item('Watch Later', url(action='list', list='Watch Later'))
        item('Favourites', url(action='list', list='Favourites'))
    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    main()
