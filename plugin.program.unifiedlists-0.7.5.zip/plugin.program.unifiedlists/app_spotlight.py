"""Per-app Arctic Fuse spotlight feeds backed by user-selected Umbrella folders."""
import json
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin


def _umbrella_directory(path):
    """Read a video directory through Kodi so Umbrella owns its list logic."""
    request = {
        'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
        'params': {
            'directory': str(path or 'plugin://plugin.video.umbrella/'),
            'media': 'video',
            # These are valid List.Fields.Files properties in Kodi Omega's
            # JSON-RPC API. Requesting an unsupported field makes the entire
            # Files.GetDirectory call fail with Invalid params.
            'properties': ['title', 'plot', 'year', 'season', 'episode',
                           'showtitle', 'genre', 'runtime', 'duration', 'mpaa',
                           'premiered', 'thumbnail', 'fanart', 'art', 'uniqueid',
                           'file'],
        },
    }
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if response.get('error'):
        raise RuntimeError(response['error'].get('message', 'Umbrella could not open this folder.'))
    files = response.get('result', {}).get('files', [])
    if not isinstance(files, list):
        raise RuntimeError('Umbrella did not return a folder listing.')
    return files


def _path_url(base, action, app_id, path):
    return base + '?' + urlencode({'action': action, 'app': app_id, 'path': path})


def render_source_picker(addon, handle, base, app, path):
    """Browse Umbrella folders and save one as this app's spotlight feed."""
    path = str(path or 'plugin://plugin.video.umbrella/')
    xbmcplugin.setPluginCategory(handle, 'Choose Umbrella source · %s' % app['label'])
    xbmcplugin.setContent(handle, 'files')
    choose = xbmcgui.ListItem(label='Use this Umbrella folder for %s' % app['label'])
    choose.setProperty('IsPlayable', 'false')
    target = base + '?' + urlencode({'action': 'set_spotlight_source',
                                     'app': app['id'], 'path': path})
    xbmcplugin.addDirectoryItem(handle, target, choose, False)
    try:
        entries = _umbrella_directory(path)
    except Exception as exc:
        xbmcgui.Dialog().notification('Spotlight source', 'Could not browse Umbrella: %s' % exc,
                                      xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    for entry in entries:
        file_path = str(entry.get('file') or '')
        is_folder = (entry.get('filetype') == 'directory' or
                     str(entry.get('filetype') or '').lower() == 'directory')
        label = str(entry.get('label') or entry.get('title') or 'Untitled')
        if is_folder and file_path:
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': entry.get('thumbnail', ''), 'thumb': entry.get('thumbnail', ''),
                       'fanart': entry.get('fanart', ''), 'landscape': entry.get('fanart', '')})
            xbmcplugin.addDirectoryItem(
                handle, _path_url(base, 'spotlight_source_browser', app['id'], file_path), li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _render_selected_source(handle, app):
    source = str(app.get('spotlight_source') or '').strip()
    if not source:
        _info_item(handle, 'Choose an Umbrella folder from Manage Apps → Choose spotlight source.')
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    for entry in _umbrella_directory(source):
        file_path = str(entry.get('file') or '')
        if not file_path:
            continue
        label = str(entry.get('label') or entry.get('title') or 'Untitled')
        is_folder = str(entry.get('filetype') or '').lower() == 'directory'
        media = str(entry.get('mediatype') or '')
        if not media:
            if entry.get('showtitle'):
                media = 'episode'
            elif is_folder:
                media = 'tvshow'
            else:
                media = 'movie'

        li = xbmcgui.ListItem(label=label)
        art = entry.get('art') if isinstance(entry.get('art'), dict) else {}
        thumb = entry.get('thumbnail') or art.get('thumb') or ''
        fanart = entry.get('fanart') or art.get('fanart') or ''
        li.setArt({key: value for key, value in {
            'thumb': thumb, 'poster': art.get('poster') or thumb,
            'landscape': art.get('landscape') or fanart or thumb,
            'fanart': fanart or thumb, 'icon': art.get('icon') or thumb,
        }.items() if value})
        tag = li.getVideoInfoTag()
        tag.setTitle(str(entry.get('title') or label))
        plot = entry.get('plot') or entry.get('overview') or ''
        if plot:
            tag.setPlot(str(plot))
        try:
            tag.setMediaType(media)
        except (AttributeError, TypeError, ValueError):
            pass
        if entry.get('year'):
            try:
                tag.setYear(int(entry['year']))
            except (TypeError, ValueError):
                pass
        if entry.get('showtitle'):
            tag.setTvShowTitle(str(entry['showtitle']))
        for key, setter in (('season', 'setSeason'), ('episode', 'setEpisode')):
            if entry.get(key) is not None:
                try:
                    getattr(tag, setter)(int(entry[key]))
                except (AttributeError, TypeError, ValueError):
                    pass
        premiered = entry.get('premiered') or entry.get('firstaired') or ''
        if premiered:
            try:
                tag.setPremiered(str(premiered))
            except (AttributeError, TypeError, ValueError):
                pass
        certificate = entry.get('mpaa') or ''
        if certificate:
            try:
                tag.setMpaa(str(certificate))
            except (AttributeError, TypeError, ValueError):
                pass
        runtime = entry.get('runtime') or entry.get('duration')
        if runtime:
            try:
                runtime = int(float(runtime))
                # Kodi's VideoInfoTag duration and JSON-RPC runtime are seconds.
                tag.setDuration(runtime)
            except (AttributeError, TypeError, ValueError):
                pass
        genres = entry.get('genre') or entry.get('genreid') or []
        if isinstance(genres, str):
            genres = [genres]
        if isinstance(genres, list) and genres:
            try:
                tag.setGenres([str(value) for value in genres])
            except (AttributeError, TypeError, ValueError):
                pass
        unique_ids = entry.get('uniqueid') or {}
        if isinstance(unique_ids, dict):
            for key, value in unique_ids.items():
                try:
                    tag.setUniqueID(str(value), str(key))
                except (AttributeError, TypeError, ValueError):
                    pass
        li.setProperty('IsPlayable', 'false' if is_folder else 'true')
        xbmcplugin.addDirectoryItem(handle, file_path, li, is_folder)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def render_spotlight(addon, handle, base, addon_root, app):
    """Render the Umbrella folder selected for this app's Arctic Fuse widget."""
    xbmcplugin.setPluginCategory(handle, '%s · Spotlight' % app['label'])
    xbmcplugin.setContent(handle, 'videos')
    try:
        _render_selected_source(handle, app)
    except Exception as exc:
        xbmcgui.Dialog().notification('App spotlight', 'Could not load Umbrella source: %s' % exc,
                                      xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


