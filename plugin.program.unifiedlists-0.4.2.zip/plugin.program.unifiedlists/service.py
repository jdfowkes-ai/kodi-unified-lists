"""Track confirmed Kodi playback without consulting VideoLibrary or Trakt."""
import json
import re
import sqlite3
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resume_control import ResumeController
from identity import stable_identity

PROFILE = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')))
DB = PROFILE / 'lists.db'


def rpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        req['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req))).get('result', {})
    except (ValueError, TypeError):
        return {}


def _uniqueid(item):
    value = item.get('uniqueid') or {}
    if not isinstance(value, dict):
        return {'tmdb': str(value)} if str(value).isdigit() else {}
    return value


def identify():
    active = rpc('Player.GetActivePlayers')
    player = next((p for p in active if p.get('type') == 'video'), None)
    if not player:
        return None
    props = ['file', 'type', 'title', 'showtitle', 'uniqueid', 'art', 'thumbnail', 'fanart',
             'year', 'runtime', 'plot', 'season', 'episode', 'premiered', 'firstaired', 'imdbnumber']
    item = rpc('Player.GetItem', {'playerid': player['playerid'], 'properties': props}).get('item', {})
    path = item.get('file') or ''
    if not path:
        return None
    title = item.get('title') or item.get('label') or 'Untitled'
    explicit_episode = item.get('type') == 'episode' or bool(item.get('showtitle') or item.get('tvshowtitle'))
    try:
        explicit_episode = explicit_episode or int(item.get('episode') or 0) > 0
    except (TypeError, ValueError):
        pass
    explicit_episode = explicit_episode or bool(re.match(r'^\s*\d+\s*[x×]', title, re.IGNORECASE))
    media = 'episode' if explicit_episode else 'movie'
    mid, identity = stable_identity(media, item, path)
    metadata = {key: item[key] for key in (
        'title', 'showtitle', 'tvshowtitle', 'uniqueid', 'art', 'thumbnail', 'fanart',
        'year', 'runtime', 'plot', 'season', 'episode', 'premiered', 'firstaired',
        'imdbnumber', 'type') if key in item}
    metadata['local_identity'] = identity
    return media, mid, title, path, metadata


def connect():
    PROFILE.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB), timeout=10)
    con.execute('CREATE TABLE IF NOT EXISTS playback_progress ('
                'media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, '
                'file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL, '
                'completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, '
                "source_metadata TEXT NOT NULL DEFAULT '{}', PRIMARY KEY(media_type,kodi_id))")
    columns = {row[1] for row in con.execute('PRAGMA table_info(playback_progress)')}
    if 'source_metadata' not in columns:
        con.execute("ALTER TABLE playback_progress ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
    con.commit()
    return con


class Tracker(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.resume = ResumeController(
            DB, lambda: xbmcgui.Dialog().notification(
                'Unified Lists', 'Resume failed; your saved position has been kept',
                xbmcgui.NOTIFICATION_WARNING, 5000))
        self.av_ready = False
        self.reset()

    def reset(self):
        self.item = None
        self.first = None
        self.position = None
        self.duration = 0
        self.last_saved = None

    def onAVStarted(self):
        self.reset()
        self.resume.reset()
        self.av_ready = True

    def onPlayBackStopped(self):
        self.save()
        self.resume.stop()
        self.av_ready = False
        self.reset()

    def onPlayBackEnded(self):
        self.save(ended=True)
        self.resume.stop()
        self.av_ready = False
        self.reset()

    def save(self, ended=False):
        if self.resume.failed or self.item is None or self.position is None:
            return
        media, mid, title, path, metadata = self.item
        complete = bool(ended or (self.duration > 0 and self.position / self.duration >= .9))
        # A picked source, a plugin handoff, and buffering never create a row.
        if not complete and (self.first is None or self.position - self.first < 30):
            return
        try:
            with connect() as con:
                con.execute(
                    'INSERT INTO playback_progress '
                    '(media_type,kodi_id,title,file_path,position,duration,completed,updated_at,source_metadata) '
                    'VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?) '
                    'ON CONFLICT(media_type,kodi_id) DO UPDATE SET '
                    'title=excluded.title,file_path=excluded.file_path,position=excluded.position,'
                    'duration=excluded.duration,completed=excluded.completed,'
                    'updated_at=CURRENT_TIMESTAMP,source_metadata=excluded.source_metadata',
                    (media, mid, title, path, self.position, self.duration, int(complete),
                     json.dumps(metadata, ensure_ascii=False)))
                con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                            ('Start Watching', media, mid))
            self.last_saved = self.position
            # Umbrella's own folders read their local bookmarks/watched stores
            # to render progress. Mirror this confirmed state there while the
            # custom Continue Watching table remains authoritative.
            try:
                import umbrella_local
                umbrella_local.sync(media, metadata, self.position, complete)
            except Exception as exc:
                xbmc.log('Unified Lists Umbrella progress mirror: ' + str(exc), xbmc.LOGDEBUG)
        except Exception as exc:
            xbmc.log('Unified Lists database error: ' + str(exc), xbmc.LOGERROR)

    def tick(self):
        if not self.av_ready or not self.isPlayingVideo():
            return
        if self.item is None:
            self.item = identify()
            if self.item is None:
                return
        try:
            pos, duration = float(self.getTime()), float(self.getTotalTime())
        except Exception:
            return
        if self.resume.tick(self, self.item, pos, duration):
            self.first = None
            self.position = None
            return
        if self.first is None:
            self.first = pos
        self.position, self.duration = pos, duration
        if self.last_saved is None or abs(pos - self.last_saved) >= 10:
            self.save()


monitor = xbmc.Monitor()
tracker = Tracker()
while not monitor.abortRequested():
    try:
        tracker.tick()
    except Exception as exc:
        xbmc.log('Unified Lists tracking: ' + str(exc), xbmc.LOGERROR)
    monitor.waitForAbort(1)
