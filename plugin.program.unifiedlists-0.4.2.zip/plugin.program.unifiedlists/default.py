import sys
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlencode, parse_qs
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from media_display import MediaDisplay

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PARAMS = {k: v[0] for k, v in parse_qs(sys.argv[2][1:]).items()}
DB_PATH = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))) / 'lists.db'
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
DISPLAY = MediaDisplay()


def db():
    con = sqlite3.connect(str(DB_PATH))
    con.execute('CREATE TABLE IF NOT EXISTS entries (list_name TEXT NOT NULL, media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, PRIMARY KEY (list_name, media_type, kodi_id))')
    con.execute("CREATE TABLE IF NOT EXISTS playback_progress (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, title TEXT NOT NULL, file_path TEXT NOT NULL, position REAL NOT NULL, duration REAL NOT NULL, completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, source_metadata TEXT NOT NULL DEFAULT '{}', PRIMARY KEY(media_type,kodi_id))")
    columns = {row[1] for row in con.execute('PRAGMA table_info(playback_progress)')}
    if 'source_metadata' not in columns:
        con.execute("ALTER TABLE playback_progress ADD COLUMN source_metadata TEXT NOT NULL DEFAULT '{}'")
    con.execute('CREATE TABLE IF NOT EXISTS external_list_items (media_type TEXT NOT NULL, kodi_id INTEGER NOT NULL, path TEXT NOT NULL, is_folder INTEGER NOT NULL DEFAULT 0, metadata_json TEXT NOT NULL DEFAULT \'{}\', PRIMARY KEY(media_type,kodi_id))')
    con.commit()
    return con


def url(**kwargs):
    return BASE + '?' + urlencode(kwargs)


def item(label, target, folder=True, menu=None, media=None, mid=None, progress=None):
    li = DISPLAY.listitem(media, mid, label, progress) if media else xbmcgui.ListItem(label=label)
    if menu is not None:
        li.addContextMenuItems(menu, replaceItems=True)
    elif media in ('movie', 'episode', 'tvshow'):
        li.addContextMenuItems(local_context_menu(), replaceItems=True)
    xbmcplugin.addDirectoryItem(HANDLE, target, li, folder)


def local_context_menu():
    """Keep video rows in this add-on to the user's four approved actions."""
    actions = (
        ('Play / Resume', 'play_resume'),
        ('Info', 'info'),
        ('Add to Watch Later', 'watch_later'),
        ('Add to Favourites', 'favourites'),
    )
    return [(label, 'RunScript(plugin.program.unifiedlists,%s)' % action)
            for label, action in actions]


def progress_context_menu(media, mid, has_progress):
    """Context actions for our locally tracked playback rows."""
    actions = []
    actions.append(('Resume' if has_progress else 'Play', url(
        action='resume', media=media, mid=mid)))
    if has_progress:
        actions.append(('Play from Beginning', url(
            action='resume', media=media, mid=mid, start=0)))
    actions.extend((('Info', 'Action(Info)'),
                    ('Add to Watch Later', url(action='toggle_saved', list='Watch Later', media=media, mid=mid)),
                    ('Add to Favourites', url(action='toggle_saved', list='Favourites', media=media, mid=mid))))
    return [(label, 'RunPlugin(%s)' % target if target.startswith('plugin://') else target)
            for label, target in actions]


def next_episode_context_menu(metadata, umbrella_path):
    payload = json.dumps({'metadata': metadata, 'umbrella_path': umbrella_path},
                         ensure_ascii=False, separators=(',', ':'))
    play_target = url(action='play_new', data=payload)
    add_later = url(action='save_metadata', list='Watch Later', data=payload)
    add_favourite = url(action='save_metadata', list='Favourites', data=payload)
    return [('Play', 'RunPlugin(%s)' % play_target),
            ('Info', 'Action(Info)'),
            ('Add to Watch Later', 'RunPlugin(%s)' % add_later),
            ('Add to Favourites', 'RunPlugin(%s)' % add_favourite)]


def saved_item_context_menu(media, mid, has_progress):
    actions = [('Resume' if has_progress else 'Play', url(
        action='play_external', media=media, mid=mid))]
    if has_progress:
        actions.append(('Play from Beginning', url(
            action='play_external', media=media, mid=mid, start=0)))
    actions.extend((('Info', 'Action(Info)'),
                    ('Add to Watch Later', url(action='toggle_saved', list='Watch Later', media=media, mid=mid)),
                    ('Add to Favourites', url(action='toggle_saved', list='Favourites', media=media, mid=mid))))
    return [(label, 'RunPlugin(%s)' % target if target.startswith('plugin://') else target)
            for label, target in actions]


def movie_progress(mid):
    con = db()
    try:
        row = con.execute('SELECT position,duration FROM playback_progress WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30', ('movie', int(mid))).fetchone()
        return row
    finally:
        con.close()


def show_list(name):
    xbmcplugin.setContent(HANDLE, "videos")
    con = db()
    rows = con.execute('SELECT e.media_type,e.kodi_id,e.title,x.path,x.is_folder,x.metadata_json '
                        'FROM entries e LEFT JOIN external_list_items x '
                        'ON x.media_type=e.media_type AND x.kodi_id=e.kodi_id '
                        'WHERE e.list_name=? ORDER BY e.title', (name,)).fetchall()
    for media, mid, title, path, is_folder, metadata_json in rows:
        if path:
            try:
                metadata = json.loads(metadata_json or '{}')
            except (ValueError, TypeError):
                metadata = {}
            if isinstance(metadata, dict):
                DISPLAY.cache[(media, int(mid))] = metadata
            saved = con.execute('SELECT position,duration FROM playback_progress '
                                'WHERE media_type=? AND kodi_id=? AND completed=0 AND position>=30',
                                (media, int(mid))).fetchone()
            li = DISPLAY.listitem(media, mid, title, saved)
            if saved and saved[1] > 0:
                li.setProperty('WatchedProgress', str(min(100, max(0, round(100 * saved[0] / saved[1])))))
            if not is_folder:
                li.setProperty('IsPlayable', 'true')
                li.addContextMenuItems(saved_item_context_menu(media, int(mid), bool(saved)), replaceItems=True)
                target = url(action='play_external', media=media, mid=mid)
            else:
                target = path
            xbmcplugin.addDirectoryItem(HANDLE, target, li, bool(is_folder))
            continue
        item(title, url(action='unavailable'), False, media=media, mid=mid)
    con.close()


def change(add):
    name, media, mid = PARAMS.get('list', ''), PARAMS.get('media', ''), PARAMS.get('mid', '')
    if name not in ('Watch Later', 'Favourites') or media not in ('movie', 'tvshow') or not mid.isdigit():
        return
    con = db()
    if add:
        con.execute('INSERT OR REPLACE INTO entries VALUES (?, ?, ?, ?)', (name, media, int(mid), PARAMS.get('title', 'Untitled')))
    else:
        con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?', (name, media, int(mid)))
    con.commit()
    con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'List updated', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def continue_watching():
    xbmcplugin.setContent(HANDLE, 'videos')
    con = db()
    con.row_factory = sqlite3.Row
    try:
        rows = [dict(row) for row in con.execute('SELECT * FROM playback_progress ORDER BY updated_at DESC').fetchall()]
    finally:
        con.close()
    for row in rows:
        try:
            metadata = json.loads(row.get('source_metadata') or '{}')
        except (ValueError, TypeError):
            metadata = {}
        # Non-library playback uses a negative synthetic ID. Seed the display
        # cache with metadata Kodi reports for the playing add-on stream.
        if row['kodi_id'] < 0 and isinstance(metadata, dict):
            DISPLAY.cache[(row['media_type'], row['kodi_id'])] = metadata
    # One local progress row is shown per movie or episode. Completed entries
    # remain in storage so history and future episode handoff can use them.
    for row in sorted((r for r in rows if not r['completed'] and r['position'] >= 30),
                      key=lambda r: (r['updated_at'], r['kodi_id']), reverse=True):
        media, mid, title = row['media_type'], row['kodi_id'], row['title']
        pos, dur = row['position'], row['duration']
        progress = (pos, dur)
        li = DISPLAY.listitem(media, mid, title, progress, enrich=True)
        if dur > 0:
            li.setProperty('WatchedProgress', str(min(100, max(0, round(100 * pos / dur)))))
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems(progress_context_menu(media, mid, True), replaceItems=True)
        xbmcplugin.addDirectoryItem(HANDLE, url(action='resume', media=media, mid=mid), li, False)

    # Ask Umbrella for its locally derived next-unwatched episode rows. This
    # uses Umbrella's native metadata and watched history, with no Trakt or
    # Kodi VideoLibrary query. Only shows already completed through this local
    # tracker are added to this custom Continue Watching view.
    completed_shows = set()
    for row in rows:
        if row['media_type'] != 'episode' or not row['completed']:
            continue
        try:
            metadata = json.loads(row.get('source_metadata') or '{}')
        except (ValueError, TypeError):
            metadata = {}
        ids = metadata.get('uniqueid') or {}
        show_id = (ids.get('tmdb') or ids.get('tvdb') or
                   metadata.get('showtitle') or metadata.get('tvshowtitle')) if isinstance(ids, dict) else ''
        if show_id:
            completed_shows.add(str(show_id).casefold())
        show_name = metadata.get('showtitle') or metadata.get('tvshowtitle')
        if show_name:
            completed_shows.add('show:' + str(show_name).strip().casefold())
    if completed_shows:
        request = {'jsonrpc': '2.0', 'id': 7, 'method': 'Files.GetDirectory', 'params': {
            'directory': 'plugin://plugin.video.umbrella/?action=local_calendar&url=localprogress',
            'media': 'video', 'properties': ['title', 'year', 'uniqueid', 'art', 'thumbnail',
                'fanart', 'plot', 'season', 'episode', 'tvshowtitle', 'premiered', 'runtime']}}
        try:
            result = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {})
            next_rows = result.get('files', []) if isinstance(result, dict) else []
        except (ValueError, TypeError):
            next_rows = []
        from identity import stable_identity
        seen = set()
        for current in rows:
            if current['media_type'] != 'episode' or current['completed']:
                continue
            try:
                current_metadata = json.loads(current.get('source_metadata') or '{}')
            except (ValueError, TypeError):
                current_metadata = {}
            _mid, current_identity = stable_identity('episode', current_metadata, current.get('file_path') or '')
            seen.add(current_identity)
        for next_row in next_rows:
            if not isinstance(next_row, dict):
                continue
            metadata = {key: next_row[key] for key in (
                'title', 'year', 'uniqueid', 'art', 'thumbnail', 'fanart', 'plot',
                'season', 'episode', 'tvshowtitle', 'premiered', 'runtime') if key in next_row}
            metadata['showtitle'] = metadata.get('tvshowtitle') or ''
            ids = metadata.get('uniqueid') or {}
            show_keys = set()
            if isinstance(ids, dict):
                show_keys.update(str(ids[key]).casefold() for key in ('tmdb', 'tvdb') if ids.get(key))
            if metadata.get('showtitle'):
                show_keys.add('show:' + str(metadata['showtitle']).strip().casefold())
            if not show_keys.intersection(completed_shows):
                continue
            umbrella_path = next_row.get('file', '')
            if not umbrella_path.startswith('plugin://plugin.video.umbrella/'):
                continue
            mid, identity = stable_identity('episode', metadata, umbrella_path)
            if identity in seen:
                continue
            seen.add(identity)
            title = metadata.get('title') or metadata.get('tvshowtitle') or 'Next episode'
            DISPLAY.cache[('episode', mid)] = metadata
            li = DISPLAY.listitem('episode', mid, title, None, enrich=True)
            li.setProperty('IsPlayable', 'true')
            li.addContextMenuItems(next_episode_context_menu(metadata, umbrella_path), replaceItems=True)
            payload = json.dumps({'metadata': metadata, 'umbrella_path': umbrella_path},
                                 ensure_ascii=False, separators=(',', ':'))
            xbmcplugin.addDirectoryItem(HANDLE, url(action='play_new', data=payload), li, False)


def toggle_saved_progress():
    name, media, raw_mid = PARAMS.get('list', ''), PARAMS.get('media', ''), PARAMS.get('mid', '')
    if name not in ('Watch Later', 'Favourites') or media not in ('movie', 'episode'):
        return
    try:
        mid = int(raw_mid)
    except (TypeError, ValueError):
        return
    con = db()
    con.row_factory = sqlite3.Row
    try:
        row = con.execute('SELECT * FROM playback_progress WHERE media_type=? AND kodi_id=?',
                          (media, mid)).fetchone()
        exists = con.execute('SELECT 1 FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                             (name, media, mid)).fetchone()
        if row is None:
            if not exists:
                return
            con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                        (name, media, mid))
            con.execute('DELETE FROM external_list_items WHERE media_type=? AND kodi_id=? '
                        'AND NOT EXISTS (SELECT 1 FROM entries WHERE media_type=? AND kodi_id=?)',
                        (media, mid, media, mid))
            con.commit()
            xbmcgui.Dialog().notification('Unified Lists', 'Removed from ' + name,
                                          xbmcgui.NOTIFICATION_INFO, 2000)
            return
        if exists:
            con.execute('DELETE FROM entries WHERE list_name=? AND media_type=? AND kodi_id=?',
                        (name, media, mid))
        else:
            metadata_json = row['source_metadata'] or '{}'
            try:
                metadata = json.loads(metadata_json)
            except (ValueError, TypeError):
                metadata = {}
            from umbrella_playback import build as umbrella_play_url
            play_path = umbrella_play_url(metadata, row['file_path'])
            con.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?)',
                        (name, media, mid, row['title']))
            con.execute('INSERT OR REPLACE INTO external_list_items '
                        '(media_type,kodi_id,path,is_folder,metadata_json) VALUES (?,?,?,?,?)',
                        (media, mid, play_path, 0, metadata_json))
        con.commit()
    finally:
        con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'List updated', xbmcgui.NOTIFICATION_INFO, 2000)


def resume_playback():
    media, mid = PARAMS.get('media',''), PARAMS.get('mid','')
    if media not in ('movie','episode') or not mid.lstrip('-').isdigit(): return
    mid = int(mid)
    con=db()
    row=con.execute('SELECT file_path,position,source_metadata FROM playback_progress WHERE media_type=? AND kodi_id=?',(media,mid)).fetchone()
    con.close()
    if not row: return
    path, position, metadata_json = row
    try:
        metadata = json.loads(metadata_json or '{}')
    except (ValueError, TypeError):
        metadata = {}
    from umbrella_playback import build as umbrella_play_url
    path = umbrella_play_url(metadata, path)
    if PARAMS.get('start')=='0':
        position=0
        import umbrella_local
        umbrella_local.clear_bookmark(media, metadata)
    from resume_control import queue, clear
    request_id = queue(DB_PATH, media, mid, float(position), path)
    try:
        xbmc.Player().play(path)
    except Exception:
        clear(DB_PATH, request_id)
        xbmcgui.Dialog().notification('Unified Lists', 'Unable to launch movie', xbmcgui.NOTIFICATION_ERROR, 4000)


def play_external_item():
    media, raw_mid = PARAMS.get('media', ''), PARAMS.get('mid', '')
    if media not in ('movie', 'episode'):
        return
    try:
        mid = int(raw_mid)
    except (TypeError, ValueError):
        return
    con = db()
    row = con.execute('SELECT x.path,x.metadata_json,p.position,p.completed FROM external_list_items x '
                      'LEFT JOIN playback_progress p ON p.media_type=x.media_type AND p.kodi_id=x.kodi_id '
                      'WHERE x.media_type=? AND x.kodi_id=?', (media, mid)).fetchone()
    con.close()
    if not row or not row[0]:
        return
    path, metadata_json, saved_position, completed = row
    try:
        metadata = json.loads(metadata_json or '{}')
    except (ValueError, TypeError):
        metadata = {}
    from umbrella_playback import build as umbrella_play_url
    path = umbrella_play_url(metadata, path)
    position = float(saved_position or 0) if saved_position is not None and not completed else 0.0
    if PARAMS.get('start') == '0':
        position = 0.0
        import umbrella_local
        umbrella_local.clear_bookmark(media, metadata)
    from resume_control import queue
    queue(DB_PATH, media, mid, position, path)
    xbmc.Player().play(path)


def play_new_item():
    try:
        payload = json.loads(PARAMS.get('data', '{}'))
    except (ValueError, TypeError):
        return
    metadata = payload.get('metadata') if isinstance(payload, dict) else {}
    if not isinstance(metadata, dict):
        return
    from umbrella_playback import build as umbrella_play_url
    path = umbrella_play_url(metadata, payload.get('umbrella_path', ''))
    xbmc.Player().play(path)


def save_metadata_item():
    name = PARAMS.get('list', '')
    if name not in ('Watch Later', 'Favourites'):
        return
    try:
        payload = json.loads(PARAMS.get('data', '{}'))
    except (ValueError, TypeError):
        return
    metadata = payload.get('metadata') if isinstance(payload, dict) else {}
    if not isinstance(metadata, dict):
        return
    from identity import stable_identity
    media, path = 'episode', payload.get('umbrella_path', '')
    mid, _identity = stable_identity(media, metadata, path)
    title = metadata.get('title') or metadata.get('tvshowtitle') or 'Untitled'
    con = db()
    con.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?)', (name, media, mid, title))
    con.execute('INSERT OR REPLACE INTO external_list_items '
                '(media_type,kodi_id,path,is_folder,metadata_json) VALUES (?,?,?,?,?)',
                (media, mid, path, 0, json.dumps(metadata, ensure_ascii=False)))
    con.commit()
    con.close()
    xbmcgui.Dialog().notification('Unified Lists', 'Added to ' + name, xbmcgui.NOTIFICATION_INFO, 2000)

def main():
    action = PARAMS.get('action', '')
    if action in ('certificate_icons', 'certificate_restore'):
        from certificate_icons import run
        run(ADDON, restore=action == 'certificate_restore')
    elif action == 'settings':
        ADDON.openSettings()
    elif action == 'continue':
        continue_watching()
    elif action == 'resume':
        resume_playback()
    elif action == 'play_external':
        play_external_item()
    elif action == 'play_new':
        play_new_item()
    elif action == 'save_metadata':
        save_metadata_item()
    elif action == 'toggle_saved':
        toggle_saved_progress()
    elif action == 'unavailable':
        xbmcgui.Dialog().notification('Unified Lists', 'This saved entry needs its Umbrella item link again',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
    elif action == 'list':
        show_list(PARAMS.get('list', ''))
    elif action in ('add', 'remove'):
        change(action == 'add')
    elif action == 'details':
        xbmc.executebuiltin('Action(Info)')
    else:
        item('Settings', url(action='settings'), False)
        item('Continue Watching', url(action='continue'))
        item('Watch Later', url(action='list', list='Watch Later'))
        item('Favourites', url(action='list', list='Favourites'))
    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    main()
