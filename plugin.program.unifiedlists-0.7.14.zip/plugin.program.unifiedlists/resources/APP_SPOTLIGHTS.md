# App spotlights

The Apps row owns the large Home hero. Highlight an app and the hero follows its saved video folder while focus stays on the Apps row, so you can scroll across apps without opening them. Pressing OK on an app still launches it.

Choose the content source from Unified Lists → **Manage Apps** → **Choose spotlight source**. Pick the app, pick an enabled video add-on, browse to the folder whose titles should feed its spotlight, then select **Use this folder**. Each app saves its own folder. The feed reads that directory through Kodi's `Files.GetDirectory` API, so the selected add-on supplies the items, artwork, metadata, and paths. Genre, UK certification, poster art and the item's normal information/play path remain attached to the returned video item. Arctic Fuse's existing spotlight interval cycles through the results.

The picker discovers enabled, installed Kodi video plugin add-ons. Folder contents and spotlight playback depend on the selected add-on returning video items through Kodi.

The Apps directory remains the app launcher and supports add/remove, filtering, and most-recently-used ordering. The Watch Later list remains available.
