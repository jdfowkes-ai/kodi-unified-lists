"""A reversible, narrowly checked Arctic Fuse 3 certificate display patch."""
import hashlib
import json
import os
import re
import xml.etree.ElementTree as ET
from pathlib import Path
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

MARKER = '<!-- Unified Lists UK certificate icons v1 -->'
CODES = ('U', 'PG', '12', '12A', '15', '18', 'R18', 'UC', 'A', 'AA', 'X')
LABEL = '$PARAM[container]$PARAM[listitem].MPAA'


def matches(code):
    values = [code, 'UK ' + code, 'UK: ' + code, 'UK:' + code,
              'GB ' + code, 'GB: ' + code, 'GB:' + code,
              'United Kingdom ' + code, 'United Kingdom: ' + code,
              'BBFC ' + code, 'BBFC: ' + code]
    return '[' + ' | '.join('String.IsEqual(%s,%s)' % (LABEL, value) for value in values) + ']'


def patch_xml(original):
    ET.fromstring(original)
    if MARKER in original:
        return original
    pattern = r'<!-- MPAA -->\s*<include content="Info_Line_Label">.*?</include>'
    blocks = list(re.finditer(pattern, original, re.DOTALL))
    if len(blocks) != 1:
        raise ValueError('Unsupported skin layout')
    old = blocks[0].group(0)
    if '$INFO[' + LABEL + ']' not in old:
        raise ValueError('Unsupported certificate field')
    visible_match = re.search(r'<param name="visible">(.*?)</param>', old, re.DOTALL)
    if not visible_match:
        raise ValueError('Missing certificate visibility')
    original_visible = visible_match.group(1)
    recognised = '[' + ' | '.join(matches(code) for code in CODES) + ']'
    replacement = [MARKER, '<include content="Info_Line_Divider">',
                   '<param name="visible">[%s] + %s</param>' % (original_visible, recognised), '</include>']
    for code in CODES:
        replacement.append('''<control type="image">
            <width>48</width><height>48</height><top>4</top>
            <aspectratio>keep</aspectratio>
            <texture>flags/color/mpaa/UK %s.png</texture>
            <visible>[%s] + %s</visible>
        </control>''' % (code, original_visible, matches(code)))
    # Preserve the skin's original text for unknown or non-UK certificates.
    fallback = old.replace('<param name="visible">' + original_visible + '</param>',
                           '<param name="visible">[%s] + !%s</param>' % (original_visible, recognised))
    replacement.append(fallback)
    result = original[:blocks[0].start()] + '\n'.join(replacement) + original[blocks[0].end():]
    ET.fromstring(result)
    return result


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_write(path, data):
    temp = path.with_name(path.name + '.unifiedlists-tmp')
    try:
        with temp.open('wb') as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        os.replace(str(temp), str(path))
    finally:
        if temp.exists():
            temp.unlink()


def apply_to(path, profile):
    data = path.read_bytes()
    original = data.decode('utf-8')
    if MARKER in original:
        return False
    patched = patch_xml(original).encode('utf-8')
    profile.mkdir(parents=True, exist_ok=True)
    backup = profile / ('Includes_Info-' + digest(data) + '.xml')
    atomic_write(backup, data)
    manifest = {'path': str(path), 'backup': str(backup), 'patched_sha256': digest(patched), 'original_sha256': digest(data)}
    # Persist recovery information before touching the skin file.
    atomic_write(profile / 'certificate_patch.json', json.dumps(manifest).encode('utf-8'))
    atomic_write(path, patched)
    return True


def restore_from(profile):
    manifest = json.loads((profile / 'certificate_patch.json').read_text(encoding='utf-8'))
    path = Path(manifest['path'])
    backup = Path(manifest['backup'])
    data = backup.read_bytes()
    if digest(data) != manifest['original_sha256'] or digest(path.read_bytes()) != manifest['patched_sha256']:
        raise ValueError('Skin changed since installation')
    atomic_write(path, data)


def run(addon, restore=False):
    dialog = xbmcgui.Dialog()
    profile = Path(xbmcvfs.translatePath(addon.getAddonInfo('profile'))) / 'certificate-icons-backups'
    try:
        if xbmc.getSkinDir() != 'skin.arctic.fuse.3':
            dialog.ok('UK certificate icons', 'Select Arctic Fuse 3 before using this option.')
            return
        skin = xbmcaddon.Addon('skin.arctic.fuse.3')
        path = Path(xbmcvfs.translatePath(skin.getAddonInfo('path'))) / '1080i' / 'Includes_Info.xml'
        if restore:
            restore_from(profile)
            dialog.ok('UK certificate icons', 'Original certificate display restored. Reloading the skin.')
        else:
            apply_to(path, profile)
            dialog.ok('UK certificate icons', 'UK certificate icons enabled. A backup of the original display is saved.\nSkin updates may require applying this option again. Reloading the skin.')
        xbmc.executebuiltin('ReloadSkin()')
    except Exception:
        dialog.ok('UK certificate icons', 'Unable to apply this change safely to the installed skin. The backup, if created, has been kept. Your local lists are unaffected.')
